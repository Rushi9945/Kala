export interface CategoryProduct {
  id: string;
  title: string;
  price: number;
  image: string;
  category: string; // slug, e.g. "mens-bracelet", "earrings", "bracelets"
  isNew?: boolean;
}

export interface CategoryInfo {
  id: string;
  slug: string;
  displayName: string;
  pluralName: string;
  videoUrl?: string;
}

export const CATEGORIES_DATA: Record<string, CategoryInfo> = {
  "mens-bracelet": {
    id: "mens-bracelet",
    slug: "mens-bracelet",
    displayName: "Man's Bracelet",
    pluralName: "Man's Bracelet",
  },
  "bracelets": {
    id: "bracelets",
    slug: "bracelets",
    displayName: "Man's Bracelet",
    pluralName: "Bracelets",
  },
  "earrings": {
    id: "earrings",
    slug: "earrings",
    displayName: "Earring's",
    pluralName: "Earring's",
  },
  "mens-studs": {
    id: "mens-studs",
    slug: "mens-studs",
    displayName: "Men's Studs",
    pluralName: "Men's Studs",
  },
  "necklaces": {
    id: "necklaces",
    slug: "necklaces",
    displayName: "Neckpieces",
    pluralName: "Neckpieces",
  },
  "rings": {
    id: "rings",
    slug: "rings",
    displayName: "Rings",
    pluralName: "Rings",
  },
  "anklets": {
    id: "anklets",
    slug: "anklets",
    displayName: "Anklets",
    pluralName: "Anklets",
  },
};

export const ALL_PRODUCTS: CategoryProduct[] = [
  // Man's Bracelet / Bracelets
  {
    id: "mb-1",
    title: "925 SILVER MAN'S CUBAN BRACELET",
    price: 14999,
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=800&auto=format&fit=crop",
    category: "mens-bracelet",
  },
  {
    id: "mb-2",
    title: "92.5 SILVER AURIC MAN'S BRACELET",
    price: 14999,
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=800&auto=format&fit=crop",
    category: "mens-bracelet",
  },
  {
    id: "mb-3",
    title: "92.5 SILVER ROYAL CREST BRACELET",
    price: 14999,
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=800&auto=format&fit=crop",
    category: "mens-bracelet",
  },
  {
    id: "mb-4",
    title: "92.5 SILVER ROYAL HEX MAN'S BRACELET",
    price: 14999,
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=800&auto=format&fit=crop",
    category: "mens-bracelet",
  },
  {
    id: "mb-5",
    title: "92.5 SILVER TITAN LINK MAN'S BRACELET",
    price: 14999,
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=800&auto=format&fit=crop",
    category: "mens-bracelet",
  },

  // Earrings
  {
    id: "er-1",
    title: "92.5 SILVER HERITAGE BLUE DROP EARRING",
    price: 1081,
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=800&auto=format&fit=crop",
    category: "earrings",
  },
  {
    id: "er-2",
    title: "92.5 SILVER CRYSTAL CANOPY STUD",
    price: 999,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop",
    category: "earrings",
  },
  {
    id: "er-3",
    title: "92.5 SILVER SOLITAIRE 0.2 EARRING",
    price: 1081,
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop",
    category: "earrings",
  },
  {
    id: "er-4",
    title: "92.5 SILVER HERITAGE GREEN DROP EARRING",
    price: 881,
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=800&auto=format&fit=crop",
    category: "earrings",
  },
  {
    id: "er-5",
    title: "92.5 SILVER STARFLOWER DROP EARRING",
    price: 1199,
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop",
    category: "earrings",
  },
  {
    id: "er-6",
    title: "92.5 SILVER SINGLE CRYSTAL STUD",
    price: 1199,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop",
    category: "earrings",
  },

  // Men's Studs
  {
    id: "ms-1",
    title: "PRINCESS CUT SOLITAIRE MEN'S STUD",
    price: 999,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop",
    category: "mens-studs",
  },
  {
    id: "ms-2",
    title: "ROUND BRILLIANT CUT DIAMOND STUD",
    price: 1299,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop",
    category: "mens-studs",
  },

  // Neckpieces
  {
    id: "np-1",
    title: "STERLING SILVER FLORAL DROP NECKLACE",
    price: 2499,
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=800&auto=format&fit=crop",
    category: "necklaces",
  },
  {
    id: "np-2",
    title: "SOLITAIRE PENDANT ON SILVER LINK CHAIN",
    price: 1799,
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=800&auto=format&fit=crop",
    category: "necklaces",
  },
];

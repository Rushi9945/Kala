import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merges Tailwind and conditional classnames cleanly without conflicts.
 * Extracted from Kala Silver legacy build (Chunk 3930, Module 39688 & 52596)
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Image proxy optimizer URL builder (from Chunk 3227, Module 59434)
 */
export function optimizeImageUrl(url?: string): string {
  if (!url) return "";
  if (
    url.includes("cdn.jsdelivr.net") ||
    url.includes("github.com") ||
    url.includes("githubusercontent.com")
  ) {
    return `/api/image-proxy?url=${encodeURIComponent(url)}`;
  }
  return url;
}

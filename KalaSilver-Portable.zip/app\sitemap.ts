import { MetadataRoute } from "next";

/**
 * Dynamic XML Sitemap — surfaced as /sitemap.xml
 * Maps to the 8 async route modules bootstrapped in Webpack chunk 7358 (module 62772)
 * Covers: home, shop, all category slugs, login, and gift-tier budget routes
 */

const BASE_URL = "https://kalasilver.in";

const STATIC_ROUTES = [
  { path: "/",         priority: 1.0,  changeFreq: "daily"   as const },
  { path: "/shop",     priority: 0.9,  changeFreq: "daily"   as const },
  { path: "/login",    priority: 0.5,  changeFreq: "monthly" as const },
];

const CATEGORY_SLUGS = [
  "earrings",
  "rings",
  "necklaces",
  "bracelets",
  "anklets",
  "pendants",
  "nose-pins",
  "mangalsutras",
  "sets-combos",
  "mens-studs",
];

const BUDGET_ROUTES = [
  "/shop?maxPrice=999",
  "/shop?maxPrice=2499",
  "/shop?maxPrice=5999",
];

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  const statics = STATIC_ROUTES.map(({ path, priority, changeFreq }) => ({
    url: `${BASE_URL}${path}`,
    lastModified: now,
    changeFrequency: changeFreq,
    priority,
  }));

  const categories = CATEGORY_SLUGS.map((slug) => ({
    url: `${BASE_URL}/shop/${slug}`,
    lastModified: now,
    changeFrequency: "weekly" as const,
    priority: 0.8,
  }));

  const categoryAlt = CATEGORY_SLUGS.map((slug) => ({
    url: `${BASE_URL}/category/${slug}`,
    lastModified: now,
    changeFrequency: "weekly" as const,
    priority: 0.75,
  }));

  const budgets = BUDGET_ROUTES.map((path) => ({
    url: `${BASE_URL}${path}`,
    lastModified: now,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));

  return [...statics, ...categories, ...categoryAlt, ...budgets];
}

"use client";

import Link from "next/link";
import { Mail, Phone, MessageCircle, ShieldCheck, RefreshCw, Truck } from "lucide-react";

// Inline SVG Instagram icon matching chunk 1605 (module 34282)
const InstagramIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="w-5 h-5"
  >
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </svg>
);

export default function Footer() {
  return (
    <footer className="bg-[#0b0e14] text-gray-300 font-sans border-t border-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        {/* Brand & Mission */}
        <div className="text-center max-w-xl mx-auto mb-10">
          <Link href="/" className="inline-block mb-3">
            <span className="font-space-grotesk font-black italic text-3xl tracking-tight">
              <span className="text-white">KALA</span>
              <span className="text-[#E72382]">SILVER</span>
            </span>
          </Link>
          <p className="text-xs text-gray-400 font-normal leading-relaxed">
            A curation of timeless silver jewellery. Crafted with precision, designed for distinction.
          </p>
        </div>

        {/* Curated Social Presence */}
        <div className="text-center mb-10">
          <p className="text-[10px] font-bold text-[#E72382] uppercase tracking-[0.25em] mb-4">
            Curated Staff
          </p>
          <div className="flex items-center justify-center gap-3">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
              className="w-10 h-10 rounded-full bg-[#E72382] text-white flex items-center justify-center hover:scale-110 transition-transform shadow-md"
            >
              <InstagramIcon />
            </a>
            <a
              href="https://wa.me"
              target="_blank"
              rel="noreferrer"
              aria-label="WhatsApp"
              className="w-10 h-10 rounded-full bg-[#25D366] text-white flex items-center justify-center hover:scale-110 transition-transform shadow-md"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
          </div>
        </div>

        {/* Direct Presence Contact Cards */}
        <div className="max-w-md mx-auto space-y-3 mb-14">
          <p className="text-[10px] font-bold text-[#E72382] uppercase tracking-[0.25em] text-center mb-3">
            Direct Presence
          </p>
          <a
            href="tel:+917228839041"
            className="flex items-center gap-3.5 px-5 py-3.5 rounded-xl bg-[#121620] border border-gray-800 hover:border-pink-500/30 transition-colors group"
          >
            <div className="w-8 h-8 rounded-full bg-[#1b2130] text-[#E72382] flex items-center justify-center group-hover:scale-110 transition-transform">
              <Phone className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-gray-200 tracking-wider">
              +91 72288 39041
            </span>
          </a>

          <a
            href="mailto:kushal12004@icloud.com"
            className="flex items-center gap-3.5 px-5 py-3.5 rounded-xl bg-[#121620] border border-gray-800 hover:border-pink-500/30 transition-colors group"
          >
            <div className="w-8 h-8 rounded-full bg-[#1b2130] text-[#E72382] flex items-center justify-center group-hover:scale-110 transition-transform">
              <Mail className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-gray-200 tracking-wider">
              kushal12004@icloud.com
            </span>
          </a>
        </div>

        {/* Trust Badges - 3 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8 border-t border-b border-gray-800/80 mb-10">
          <div className="flex items-center justify-center md:justify-start gap-4 p-4 rounded-xl bg-[#121620]/60">
            <div className="w-10 h-10 rounded-full bg-pink-500/10 text-[#E72382] flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-black text-white tracking-wider uppercase">
                Priority Delivery
              </p>
              <p className="text-[11px] text-gray-400">Reliable express logistics</p>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-4 p-4 rounded-xl bg-[#121620]/60">
            <div className="w-10 h-10 rounded-full bg-pink-500/10 text-[#E72382] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-black text-white tracking-wider uppercase">
                Certified Authentic
              </p>
              <p className="text-[11px] text-gray-400">925 hallmark purity assured</p>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-4 p-4 rounded-xl bg-[#121620]/60">
            <div className="w-10 h-10 rounded-full bg-pink-500/10 text-[#E72382] flex items-center justify-center shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-black text-white tracking-wider uppercase">
                Easy Exchange
              </p>
              <p className="text-[11px] text-gray-400">7-day assurance boutique</p>
            </div>
          </div>
        </div>

        {/* Curated Craftsmanship & Payment Logos */}
        <div className="text-center mb-8">
          <p className="text-[10px] font-bold text-[#E72382] uppercase tracking-[0.25em] mb-4">
            Curated Craftsmanship
          </p>
          <div className="flex items-center justify-center gap-6 text-[10px] font-bold tracking-widest text-gray-500 uppercase">
            <span className="px-3 py-1 rounded bg-gray-900 border border-gray-800">RuPay</span>
            <span className="px-3 py-1 rounded bg-gray-900 border border-gray-800">VISA</span>
            <span className="px-3 py-1 rounded bg-gray-900 border border-gray-800">UPI</span>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center text-[10px] text-gray-500 tracking-widest uppercase font-semibold">
          © {new Date().getFullYear()} <span className="text-white">KALA SILVER</span> BOUTIQUE HOUSE
        </div>
      </div>
    </footer>
  );
}

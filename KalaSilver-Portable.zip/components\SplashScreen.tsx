"use client";

import { useEffect, useState } from "react";

// ── Animated lock icon ────────────────────────────────────────────────────────
const LockIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    className="w-4 h-4"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z"
    />
  </svg>
);

// ── Diamond sparkle icon ──────────────────────────────────────────────────────
const DiamondIcon = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8 text-magenta-400" fill="currentColor">
    <path d="M12 2L2 9l10 13L22 9z" opacity="0.3" />
    <path d="M12 2L2 9h20L12 2zM2 9l10 13L12 9H2zM12 9l10 13V9H12z" />
  </svg>
);

interface SplashScreenProps {
  onComplete: () => void;
  duration?: number;
}

export default function SplashScreen({
  onComplete,
  duration = 2800,
}: SplashScreenProps) {
  const [phase, setPhase] = useState<"enter" | "show" | "exit">("enter");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Start enter animation
    const enterTimer = setTimeout(() => setPhase("show"), 100);

    // Progress bar
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 100 / (duration / 40);
      });
    }, 40);

    // Start exit animation
    const exitTimer = setTimeout(() => setPhase("exit"), duration - 400);

    // Call onComplete
    const completeTimer = setTimeout(onComplete, duration);

    return () => {
      clearTimeout(enterTimer);
      clearTimeout(exitTimer);
      clearTimeout(completeTimer);
      clearInterval(interval);
    };
  }, [onComplete, duration]);

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center transition-opacity duration-500 ${
        phase === "exit" ? "opacity-0" : "opacity-100"
      }`}
      style={{
        background:
          "linear-gradient(135deg, #0f0f0f 0%, #1a0a10 40%, #2d0018 70%, #0f0f0f 100%)",
      }}
    >
      {/* Background decorative circles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-magenta-900/20 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-magenta-800/15 blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-magenta-900/10 blur-3xl" />
      </div>

      {/* Decorative particles */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-magenta-400/60"
          style={{
            top: `${15 + i * 10}%`,
            left: `${5 + i * 12}%`,
            animation: `pulse ${1.5 + i * 0.3}s ease-in-out infinite alternate`,
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}

      {/* Main content */}
      <div
        className={`relative flex flex-col items-center gap-6 transition-all duration-700 ${
          phase === "enter"
            ? "opacity-0 translate-y-8 scale-95"
            : phase === "show"
            ? "opacity-100 translate-y-0 scale-100"
            : "opacity-0 -translate-y-4 scale-105"
        }`}
      >
        {/* Diamond icon cluster */}
        <div className="flex items-center gap-3 mb-2">
          <div
            className="opacity-40"
            style={{ transform: "rotate(-20deg) scale(0.7)" }}
          >
            <DiamondIcon />
          </div>
          <div className="text-magenta-400">
            <DiamondIcon />
          </div>
          <div
            className="opacity-40"
            style={{ transform: "rotate(20deg) scale(0.7)" }}
          >
            <DiamondIcon />
          </div>
        </div>

        {/* Logo */}
        <div className="text-center">
          <h1
            className="splash-logo-glow font-serif text-6xl md:text-7xl font-bold text-white tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Kala
            <span
              className="text-magenta-400"
              style={{
                background: "linear-gradient(135deg, #ff2278, #e8005a, #c40049)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Silver
            </span>
          </h1>

          {/* Tag line 1 */}
          <p
            className="mt-3 text-sm md:text-base font-serif italic text-gray-300 tracking-[0.3em] uppercase"
            style={{ animationDelay: "0.3s" }}
          >
            Premium Artistry
          </p>

          {/* Ornamental divider */}
          <div className="flex items-center justify-center gap-3 mt-4">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-magenta-500/60" />
            <div className="w-1.5 h-1.5 rounded-full bg-magenta-500" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-magenta-500/60" />
          </div>
        </div>

        {/* Security badge */}
        <div
          className="flex items-center gap-2 px-4 py-2 rounded-full border border-magenta-800/60 bg-magenta-900/30 text-magenta-300 text-xs tracking-widest uppercase font-medium"
          style={{ animationDelay: "0.5s" }}
        >
          <LockIcon />
          <span>Secure Encrypted Session</span>
          <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
        </div>

        {/* Progress bar */}
        <div className="w-48 h-0.5 bg-gray-800 rounded-full overflow-hidden mt-2">
          <div
            className="h-full bg-gradient-to-r from-magenta-600 to-magenta-400 rounded-full transition-all duration-100 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}

import { NextResponse } from "next/server";

// ── Types ─────────────────────────────────────────────────────────────────────
export interface Category {
  id: string;
  name: string;
  slug: string;
  emoji: string;
  itemCount: number;
  gradient: string;
  accentColor: string;
  badge?: string;
}

export interface GiftTier {
  id: string;
  label: string;
  rangeLabel: string;
  minPrice: number;
  maxPrice: number | null;
  emoji: string;
  tagline: string;
  productCount: number;
  accentColor: string;
  bgColor: string;
  borderColor: string;
  popular?: boolean;
}

export interface ProductsApiResponse {
  categories: Category[];
  giftTiers: GiftTier[];
  meta: {
    totalCategories: number;
    totalTiers: number;
    currency: string;
    lastUpdated: string;
  };
}

// ── Mock Data ─────────────────────────────────────────────────────────────────
const CATEGORIES: Category[] = [
  {
    id: "cat-001",
    name: "Men's Studs",
    slug: "mens-studs",
    emoji: "💎",
    itemCount: 48,
    gradient: "bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900",
    accentColor: "#94a3b8",
    badge: "New",
  },
  {
    id: "cat-002",
    name: "Bracelets",
    slug: "bracelets",
    emoji: "✨",
    itemCount: 132,
    gradient: "bg-gradient-to-br from-rose-400 via-pink-500 to-magenta-600",
    accentColor: "#f43f5e",
  },
  {
    id: "cat-003",
    name: "Necklaces",
    slug: "necklaces",
    emoji: "📿",
    itemCount: 96,
    gradient: "bg-gradient-to-br from-amber-400 via-orange-400 to-rose-400",
    accentColor: "#f59e0b",
    badge: "Bestseller",
  },
  {
    id: "cat-004",
    name: "Rings",
    slug: "rings",
    emoji: "💍",
    itemCount: 204,
    gradient: "bg-gradient-to-br from-violet-500 via-purple-600 to-indigo-700",
    accentColor: "#8b5cf6",
  },
  {
    id: "cat-005",
    name: "Earrings",
    slug: "earrings",
    emoji: "🌸",
    itemCount: 178,
    gradient: "bg-gradient-to-br from-pink-400 via-rose-400 to-fuchsia-500",
    accentColor: "#ec4899",
    badge: "Trending",
  },
  {
    id: "cat-006",
    name: "Anklets",
    slug: "anklets",
    emoji: "🌟",
    itemCount: 64,
    gradient: "bg-gradient-to-br from-teal-400 via-cyan-500 to-sky-600",
    accentColor: "#14b8a6",
  },
  {
    id: "cat-007",
    name: "Pendants",
    slug: "pendants",
    emoji: "🔮",
    itemCount: 87,
    gradient: "bg-gradient-to-br from-indigo-400 via-blue-500 to-cyan-600",
    accentColor: "#6366f1",
  },
  {
    id: "cat-008",
    name: "Nose Pins",
    slug: "nose-pins",
    emoji: "🌷",
    itemCount: 43,
    gradient: "bg-gradient-to-br from-emerald-400 via-green-500 to-teal-600",
    accentColor: "#10b981",
  },
  {
    id: "cat-009",
    name: "Mangalsutras",
    slug: "mangalsutras",
    emoji: "🪬",
    itemCount: 55,
    gradient: "bg-gradient-to-br from-yellow-400 via-amber-500 to-orange-500",
    accentColor: "#eab308",
    badge: "Exclusive",
  },
  {
    id: "cat-010",
    name: "Sets & Combos",
    slug: "sets-combos",
    emoji: "👑",
    itemCount: 38,
    gradient: "bg-gradient-to-br from-magenta-500 via-pink-600 to-rose-700",
    accentColor: "#e8005a",
    badge: "Bundle",
  },
];

const GIFT_TIERS: GiftTier[] = [
  {
    id: "tier-001",
    label: "Sweet Beginnings",
    rangeLabel: "Under ₹999",
    minPrice: 0,
    maxPrice: 999,
    emoji: "🎀",
    tagline: "Thoughtful everyday pieces that delight without breaking the bank.",
    productCount: 120,
    accentColor: "#f43f5e",
    bgColor: "bg-rose-50",
    borderColor: "border-rose-100",
  },
  {
    id: "tier-002",
    label: "Heartfelt Tokens",
    rangeLabel: "₹999 – ₹2,499",
    minPrice: 999,
    maxPrice: 2499,
    emoji: "💝",
    tagline: "Perfect for birthdays, anniversaries, and special occasions.",
    productCount: 215,
    accentColor: "#e8005a",
    bgColor: "bg-pink-50",
    borderColor: "border-pink-200",
    popular: true,
  },
  {
    id: "tier-003",
    label: "Cherished Luxuries",
    rangeLabel: "₹2,500 – ₹5,999",
    minPrice: 2500,
    maxPrice: 5999,
    emoji: "✨",
    tagline: "Statement pieces that elevate every look and linger in memory.",
    productCount: 98,
    accentColor: "#8b5cf6",
    bgColor: "bg-violet-50",
    borderColor: "border-violet-100",
  },
  {
    id: "tier-004",
    label: "Prestige Collection",
    rangeLabel: "₹6,000 & above",
    minPrice: 6000,
    maxPrice: null,
    emoji: "👑",
    tagline: "Heirloom-worthy jewellery for life's most precious milestones.",
    productCount: 54,
    accentColor: "#d97706",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-100",
  },
];

// ── GET handler ───────────────────────────────────────────────────────────────
export async function GET(): Promise<NextResponse<ProductsApiResponse>> {
  const data: ProductsApiResponse = {
    categories: CATEGORIES,
    giftTiers: GIFT_TIERS,
    meta: {
      totalCategories: CATEGORIES.length,
      totalTiers: GIFT_TIERS.length,
      currency: "INR",
      lastUpdated: new Date().toISOString(),
    },
  };

  return NextResponse.json(data, {
    status: 200,
    headers: {
      "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=86400",
    },
  });
}

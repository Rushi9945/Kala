"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, Gift, Sparkles, Gem } from "lucide-react";

export default function BudgetSuite() {
  return (
    <section className="py-16 md:py-24 bg-[#FBFBFB] border-t border-b border-gray-100" id="budget">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-[11px] font-semibold tracking-[0.25em] text-[#E72382] uppercase">
            THE GIFTING SUITE
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight mt-1.5">
            Gifts by <span className="text-[#E72382] italic font-serif">Budget</span>
          </h2>
          <p className="text-xs sm:text-sm font-normal text-gray-500 mt-2">
            Thoughtfully curated silver treasures, categorized by investment value to help you find
            the perfect token of affection.
          </p>
          <div className="w-12 h-[3px] bg-[#E72382] rounded-full mx-auto my-3" />
        </div>

        {/* Budget Cards: grid-cols-2 lg:grid-cols-4 gap-4 px-4 w-full max-w-7xl mx-auto mt-8 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 px-4 w-full max-w-7xl mx-auto mt-8">
          {/* Budget Tier 1: /shop?maxPrice=1997 */}
          <Link
            href="/shop?maxPrice=1997"
            className="group relative flex flex-col items-center justify-center p-6 md:p-8 rounded-[2rem] overflow-hidden transition-transform active:scale-95 bg-pink-50"
          >
            {/* Watermark Icon */}
            <Heart className="absolute w-32 h-32 text-black opacity-[0.03] -z-0 pointer-events-none fill-current" />

            {/* Top Badge */}
            <div className="relative z-10 w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-[#E72382] mb-4 group-hover:scale-110 transition-transform">
              <Heart className="w-5 h-5 fill-current" />
            </div>

            {/* Typography */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-[0.2em] text-center">
              GIFTS UNDER
            </span>
            <div className="relative z-10 text-3xl font-black italic text-gray-900 mt-1">
              ₹1997
            </div>

            {/* Interactive State */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-widest mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
              EXPLORE -&gt;
            </span>
          </Link>

          {/* Budget Tier 2: /shop?maxPrice=2999 */}
          <Link
            href="/shop?maxPrice=2999"
            className="group relative flex flex-col items-center justify-center p-6 md:p-8 rounded-[2rem] overflow-hidden transition-transform active:scale-95 bg-indigo-50"
          >
            {/* Watermark Icon */}
            <Gift className="absolute w-32 h-32 text-black opacity-[0.03] -z-0 pointer-events-none" />

            {/* Top Badge */}
            <div className="relative z-10 w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-[#E72382] mb-4 group-hover:scale-110 transition-transform">
              <Gift className="w-5 h-5" />
            </div>

            {/* Typography */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-[0.2em] text-center">
              GIFTS UNDER
            </span>
            <div className="relative z-10 text-3xl font-black italic text-gray-900 mt-1">
              ₹2999
            </div>

            {/* Interactive State */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-widest mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
              EXPLORE -&gt;
            </span>
          </Link>

          {/* Budget Tier 3: /shop?maxPrice=3999 */}
          <Link
            href="/shop?maxPrice=3999"
            className="group relative flex flex-col items-center justify-center p-6 md:p-8 rounded-[2rem] overflow-hidden transition-transform active:scale-95 bg-amber-50"
          >
            {/* Watermark Icon */}
            <Sparkles className="absolute w-32 h-32 text-black opacity-[0.03] -z-0 pointer-events-none" />

            {/* Top Badge */}
            <div className="relative z-10 w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-[#E72382] mb-4 group-hover:scale-110 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>

            {/* Typography */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-[0.2em] text-center">
              GIFTS UNDER
            </span>
            <div className="relative z-10 text-3xl font-black italic text-gray-900 mt-1">
              ₹3999
            </div>

            {/* Interactive State */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-widest mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
              EXPLORE -&gt;
            </span>
          </Link>

          {/* Budget Tier 4: Premium -> /shop */}
          <Link
            href="/shop"
            className="group relative flex flex-col items-center justify-center p-6 md:p-8 rounded-[2rem] overflow-hidden transition-transform active:scale-95 bg-blue-50"
          >
            {/* Watermark Icon */}
            <Gem className="absolute w-32 h-32 text-black opacity-[0.03] -z-0 pointer-events-none" />

            {/* Top Badge */}
            <div className="relative z-10 w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center text-[#E72382] mb-4 group-hover:scale-110 transition-transform">
              <Gem className="w-5 h-5" />
            </div>

            {/* Typography */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-[0.2em] text-center">
              GIFTS UNDER
            </span>
            <div className="relative z-10 text-3xl font-black italic text-gray-900 mt-1">
              Premium
            </div>

            {/* Interactive State */}
            <span className="relative z-10 text-[9px] font-bold text-[#E72382] uppercase tracking-widest mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
              EXPLORE -&gt;
            </span>
          </Link>
        </div>

        {/* Social Proof Micro Banner */}
        <div className="mt-8 flex items-center justify-center space-x-3 text-xs font-semibold text-gray-500 tracking-wider">
          <div className="flex -space-x-2">
            <div className="relative h-6 w-6 rounded-full overflow-hidden ring-2 ring-white">
              <Image
                alt="Customer avatar 1"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuA8HchY2tIRGMtFS1JO_oJFUWMeAwAJbRAHAEFrj0sBx2tb1rfTqhf385jUx5SsFIYAAHkb8oh9K5blSel5kmpqHWPFBYBhduLVilulc1MY7Cqk3d7kZ1U57E7HDztT1Xcv00g2M0vgZjmQ1nSnXdjjdZihQYhvuoY1UElitiW9Ijw2xo4Oeu-cr4SoSQbbZRPgxN9bjKJqyvisZ_JYqMS0QtGlHiJFHsb-XyqnVQ"
                fill
                className="object-cover"
                sizes="24px"
              />
            </div>
            <div className="relative h-6 w-6 rounded-full overflow-hidden ring-2 ring-white">
              <Image
                alt="Customer avatar 2"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAn-Qv-a6n_o0lSgY0_h7mF4P9mE-u4T9wFwD1rDk-k2l6vX5f1k0s9_Q9mE-u4T9wFwD1rDk-k2l6vX5f1k0s9_Q9mE-u4T9wFwD1rDk-k2l6vX5f1k0s9_Q9mE-u4T9wFwD1rDk-k2l6vX5f1k0s9_Q9mE-u4T9wFwD1rDk-k2l6vX5f1k0s9_Q"
                fill
                className="object-cover"
                sizes="24px"
              />
            </div>
          </div>
          <span className="text-[#E72382] font-bold">500+ Patron Reviews</span>
          <span>• Certified Hallmarking</span>
        </div>
      </div>
    </section>
  );
}

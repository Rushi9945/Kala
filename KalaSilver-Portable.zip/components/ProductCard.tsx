"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { cn, optimizeImageUrl } from "@/lib/utils";

export interface ProductData {
  id: string;
  name?: string;
  title?: string;
  price: number;
  salePrice?: number;
  imageUrl?: string;
  image?: string;
  imageUrls?: string[];
  imageHint?: string;
  isNew?: boolean;
  isPureSilver?: boolean;
}

interface ProductCardProps {
  product: ProductData;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const [isHovered, setIsHovered] = useState(false);
  const [isAdded, setIsAdded] = useState(false);

  const name = product.name || product.title || "Silver Jewel";
  const price = product.price;
  const salePrice = product.salePrice;
  const isLiked = isInWishlist(product.id);

  const images =
    product.imageUrls && product.imageUrls.length > 0
      ? product.imageUrls
      : [product.imageUrl || product.image || ""];

  const currentImage = isHovered && images.length > 1 ? images[1] : images[0];
  const finalPrice = salePrice || price;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      id: product.id,
      name,
      price: finalPrice,
      image: currentImage,
    });
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1500);
  };

  return (
    <div
      className="group flex flex-col h-full bg-white"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container: aspect-square bg-gray-50 rounded-2xl relative overflow-hidden mb-3 */}
      <div className="aspect-square bg-gray-50 rounded-2xl relative overflow-hidden mb-3 w-full">
        <Link href={`/product/${product.id}`} className="block h-full w-full">
          {currentImage ? (
            <Image
              src={optimizeImageUrl(currentImage)}
              alt={name}
              fill
              className="object-cover transition-all duration-500 group-hover:scale-105"
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, 25vw"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-gray-400 text-xs">
              No Image
            </div>
          )}
        </Link>

        {/* Wishlist Icon: absolute bottom-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm text-gray-500 */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (isLiked) {
              removeFromWishlist(product.id);
            } else {
              addToWishlist(product);
            }
          }}
          aria-label="Toggle Wishlist"
          className={cn(
            "absolute bottom-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm transition-all z-20 cursor-pointer",
            isLiked ? "text-[#E72382]" : "text-gray-500 hover:text-[#E72382]"
          )}
        >
          <Heart className={cn("w-4 h-4", isLiked && "fill-current")} />
        </button>
      </div>

      {/* Typography: Title & Price */}
      <div className="flex flex-col flex-1">
        <Link href={`/product/${product.id}`} className="block">
          {/* Product Title: text-sm font-semibold text-gray-900 truncate mb-1 */}
          <h3 className="text-sm font-semibold text-gray-900 truncate mb-1 group-hover:text-[#E72382] transition-colors">
            {name}
          </h3>

          {/* Price: text-lg font-black text-gray-900 mb-4 */}
          <p className="text-lg font-black text-gray-900 mb-4">
            ₹{finalPrice.toLocaleString()}
          </p>
        </Link>
      </div>

      {/* Add to Cart Button (Critical): w-full bg-[#E72382] text-white font-bold text-sm py-2.5 rounded-lg hover:bg-pink-700 transition-colors */}
      <button
        onClick={handleAddToCart}
        className="w-full bg-[#E72382] text-white font-bold text-sm py-2.5 rounded-lg hover:bg-pink-700 transition-colors active:scale-[0.98] cursor-pointer"
      >
        {isAdded ? "Added ✓" : "Add to Cart"}
      </button>
    </div>
  );
}

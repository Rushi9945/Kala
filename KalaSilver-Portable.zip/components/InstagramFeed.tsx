"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function InstagramFeed() {
  return (
    <section className="py-16 bg-white border-t border-gray-100 text-center" id="community">
      <div className="max-w-2xl mx-auto px-4">
        {/* Instagram Logo Icon */}
        <div className="w-14 h-14 rounded-2xl border border-gray-200 mx-auto flex items-center justify-center text-gray-800 shadow-sm mb-4 bg-white hover:text-[#E72382] transition-colors">
          <svg
            className="w-6 h-6 fill-current text-[#E72382]"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
          </svg>
        </div>

        <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
          Join Our <span className="text-[#E72382] italic font-serif">Community</span>
        </h2>
        <p className="text-xs sm:text-sm text-gray-500 mt-2">
          Follow us{" "}
          <Link
            href="https://instagram.com/kalasilver01"
            target="_blank"
            rel="noopener noreferrer"
            className="font-bold text-[#E72382] hover:underline cursor-pointer"
          >
            @kalasilver01
          </Link>{" "}
          for styling inspiration and new arrival drops.
        </p>

        {/* Instagram CTA Button */}
        <div className="mt-6">
          <Link
            href="https://instagram.com/kalasilver01"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#111218] text-white text-xs font-bold tracking-widest uppercase rounded-full hover:bg-[#E72382] transition-colors duration-300 shadow-md"
          >
            <span>VIEW ALL ON INSTAGRAM</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}

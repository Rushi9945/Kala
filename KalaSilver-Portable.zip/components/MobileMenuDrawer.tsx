"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import {
  X,
  Search,
  ChevronDown,
  ChevronUp,
  Tag,
  Clock,
  LogOut,
  Info,
  Layers,
  ArrowRight,
  IndianRupee,
  Sparkles,
} from "lucide-react";

interface MobileMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES = [
  { name: "Man's Bracelet", href: "/category/bracelets", image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop" },
  { name: "Earring's", href: "/category/earrings", image: "https://images.unsplash.com/photo-1630019852942-f89202989a59?q=80&w=600&auto=format&fit=crop" },
  { name: "Man's Chains", href: "/category/necklaces", image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop" },
  { name: "MAN'S STUDS", href: "/category/mens-studs", image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop" },
  { name: "Bracelets", href: "/category/bracelets", image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop" },
  { name: "Necklace&chains", href: "/category/necklaces", image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop" },
];

export default function MobileMenuDrawer({ isOpen, onClose }: MobileMenuDrawerProps) {
  const pathname = usePathname();
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<"menu" | "categories">("menu");
  const [searchQuery, setSearchQuery] = useState("");
  const [isCategoryExpanded, setIsCategoryExpanded] = useState(true);
  const [isBudgetExpanded, setIsBudgetExpanded] = useState(false);

  useEffect(() => {
    onClose();
  }, [pathname]);

  if (!isOpen) return null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/shop?q=${encodeURIComponent(searchQuery.trim())}`);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Dimmed backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Container */}
      <div className="relative w-[310px] max-w-[85vw] bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-300">
        {/* Search input header */}
        <div className="p-4 pt-5 pb-3 border-b border-gray-100 flex items-center gap-2">
          <form onSubmit={handleSearchSubmit} className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search treasures..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-gray-50 border border-transparent focus:border-[#E72382] rounded-full text-xs font-bold outline-none placeholder:text-gray-400 text-gray-800"
            />
          </form>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-full"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers: MENU vs CATEGORIES */}
        <div className="flex border-b border-gray-100">
          <button
            onClick={() => setActiveTab("menu")}
            className={`flex-1 py-3 text-xs font-black uppercase tracking-wider transition-all relative ${
              activeTab === "menu" ? "text-[#E72382]" : "text-gray-400 hover:text-gray-700"
            }`}
          >
            MENU
            {activeTab === "menu" && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#E72382]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab("categories")}
            className={`flex-1 py-3 text-xs font-black uppercase tracking-wider transition-all relative ${
              activeTab === "categories" ? "text-[#E72382]" : "text-gray-400 hover:text-gray-700"
            }`}
          >
            CATEGORIES
            {activeTab === "categories" && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#E72382]" />
            )}
          </button>
        </div>

        {/* Scrollable Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeTab === "menu" ? (
            <div className="space-y-3">
              {/* Accordion: Shop by Category */}
              <div className="bg-[#FFF5F8] rounded-2xl overflow-hidden border border-pink-100">
                <button
                  onClick={() => setIsCategoryExpanded(!isCategoryExpanded)}
                  className="w-full px-4 py-3.5 flex items-center justify-between text-xs font-black text-[#E72382] uppercase tracking-wider"
                >
                  <span className="flex items-center gap-2">
                    <Layers className="w-4 h-4" /> Shop by Category
                  </span>
                  {isCategoryExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {isCategoryExpanded && (
                  <div className="px-5 pb-4 pt-1 space-y-3 border-t border-pink-100/60 bg-white/70">
                    {CATEGORIES.map((cat, i) => (
                      <Link
                        key={i}
                        href={cat.href}
                        onClick={onClose}
                        className="flex items-center gap-2.5 text-xs font-bold text-gray-700 hover:text-[#E72382] transition-colors"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-pink-300" />
                        <span>{cat.name}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>

              {/* Shop By Price Pill */}
              <div className="p-3 bg-gray-50/80 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Tag className="w-4 h-4 text-gray-400" />
                  <div>
                    <span className="text-xs font-black text-gray-800 block">Shop By Price</span>
                  </div>
                </div>
                <Link
                  href="/shop"
                  onClick={onClose}
                  className="px-3 py-1 bg-[#E72382] text-white rounded-full text-[9px] font-black uppercase tracking-wider shadow-sm"
                >
                  BUDGET PICKS +
                </Link>
              </div>

              {/* Additional Nav Links */}
              <div className="pt-2 space-y-1">
                <Link
                  href="/about"
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <Info className="w-4 h-4 text-gray-400" />
                  <span>About Us</span>
                </Link>

                <Link
                  href="/account/orders"
                  onClick={onClose}
                  className="w-full mt-2 py-3 px-4 border border-pink-200 text-[#E72382] rounded-2xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 bg-[#FFF5F8]/40 hover:bg-[#FFF5F8] transition-all"
                >
                  <Clock className="w-4 h-4" /> My Orders History
                </Link>

                <button
                  onClick={() => {
                    router.push("/login");
                    onClose();
                  }}
                  className="w-full pt-3 text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-gray-700 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" /> Log Out Account
                </button>
              </div>
            </div>
          ) : (
            /* CATEGORIES VISUAL TAB (Curated Essence) */
            <div className="space-y-4">
              <div className="text-left space-y-1 px-1">
                <h3 className="text-xl font-black italic tracking-tight text-gray-900">
                  Curated <span className="text-[#E72382]">Essence</span>
                </h3>
                <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400 leading-relaxed">
                  Experience the intersection of tradition and modern elegance with our curated silver categories.
                </p>
              </div>

              <div className="space-y-3">
                {CATEGORIES.map((cat, i) => (
                  <Link
                    key={i}
                    href={cat.href}
                    onClick={onClose}
                    className="relative block h-24 rounded-2xl overflow-hidden group shadow-sm border border-gray-100"
                  >
                    <Image
                      src={cat.image}
                      alt={cat.name}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-3">
                      <span className="text-white font-black text-xs uppercase tracking-wider">
                        {cat.name}
                      </span>
                      <div className="w-6 h-0.5 bg-[#E72382] mt-1 group-hover:w-10 transition-all" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

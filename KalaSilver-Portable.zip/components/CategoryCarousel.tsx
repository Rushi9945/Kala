"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useRef, useEffect } from "react";

interface Category {
  id: string;
  name: string;
  image: string;
  slug: string;
}

const categories: Category[] = [
  {
    id: "cat-1",
    name: "BRACELETS",
    image:
      "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
    slug: "bracelets",
  },
  {
    id: "cat-2",
    name: "NECKLACE&CHAINS",
    image:
      "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop",
    slug: "necklaces",
  },
  {
    id: "cat-3",
    name: "MAN'S BRACELET",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=600&auto=format&fit=crop",
    slug: "mens-bracelet",
  },
  {
    id: "cat-4",
    name: "EARRING'S",
    image:
      "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=600&auto=format&fit=crop",
    slug: "earrings",
  },
  {
    id: "cat-5",
    name: "MAN'S STUDS",
    image:
      "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
    slug: "mens-studs",
  },
  {
    id: "cat-6",
    name: "MAN'S CHAINS",
    image:
      "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop",
    slug: "mens-chains",
  },
];

export default function CategoryCarousel() {
  const [activeSlide, setActiveSlide] = useState(1);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const isHoveredRef = useRef(false);

  // Manual scroll tracking
  const handleScroll = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      const progress = scrollLeft / (scrollWidth - clientWidth || 1);
      const index = Math.round(progress * (categories.length - 1));
      setActiveSlide(Math.max(0, Math.min(categories.length - 1, index)));
    }
  };

  const scrollToSlide = (index: number) => {
    if (scrollContainerRef.current) {
      const { scrollWidth, clientWidth } = scrollContainerRef.current;
      const maxScroll = scrollWidth - clientWidth;
      const targetScroll = (index / (categories.length - 1)) * maxScroll;
      scrollContainerRef.current.scrollTo({ left: targetScroll, behavior: "smooth" });
      setActiveSlide(index);
    }
  };

  // Automatic slide cycle every 3.5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      if (!isHoveredRef.current && scrollContainerRef.current) {
        setActiveSlide((prev) => {
          const nextIndex = (prev + 1) % categories.length;
          const { scrollWidth, clientWidth } = scrollContainerRef.current!;
          const maxScroll = scrollWidth - clientWidth;
          const targetScroll = (nextIndex / (categories.length - 1)) * maxScroll;
          scrollContainerRef.current!.scrollTo({ left: targetScroll, behavior: "smooth" });
          return nextIndex;
        });
      }
    }, 3500);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="pt-8 pb-14 md:pt-12 md:pb-20 bg-white" id="categories">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Exact Header matching screenshot:
            THE COLLECTIONS
            Shop by Category (stacked with Shop by in dark navy italic and Category in #E72382 italic)
            EXPLORE OUR HANDCRAFTED TREASURES CURATED JUST FOR YOU
            Solid pink pill dash underline
        */}
        <div className="text-center mb-8 sm:mb-10 select-none">
          <p className="text-[11px] font-bold tracking-[0.3em] text-[#E72382] uppercase mb-1">
            THE COLLECTIONS
          </p>

          <h2 className="text-4xl sm:text-5xl md:text-6xl font-black italic tracking-tighter text-[#0e141e] leading-[0.95] flex flex-col items-center">
            <span>Shop by</span>
            <span className="text-[#E72382] mt-0.5">Category</span>
          </h2>

          <p className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em] text-[#9ca3af] mt-3.5 max-w-sm mx-auto leading-relaxed">
            EXPLORE OUR HANDCRAFTED TREASURES CURATED JUST FOR YOU
          </p>
        </div>

        {/* Swipeable portrait category cards with Auto-Scroll */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          onMouseEnter={() => {
            isHoveredRef.current = true;
          }}
          onMouseLeave={() => {
            isHoveredRef.current = false;
          }}
          onTouchStart={() => {
            isHoveredRef.current = true;
          }}
          onTouchEnd={() => {
            setTimeout(() => {
              isHoveredRef.current = false;
            }, 2000);
          }}
          className="flex gap-3 sm:gap-4 md:gap-6 overflow-x-auto pb-4 no-scrollbar -mx-4 px-8 sm:mx-0 sm:px-0 scroll-smooth snap-x snap-mandatory items-center justify-start sm:justify-center"
        >
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/category/${cat.slug}`}
              className="group relative flex-shrink-0 aspect-[3/4] w-[60vw] max-w-[260px] sm:w-56 md:w-64 rounded-xl overflow-hidden bg-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 snap-center"
            >
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
                sizes="(max-width: 640px) 60vw, 260px"
              />

              {/* Vertical pinned label on the right edge */}
              <div className="absolute right-2 top-4 bottom-4 flex items-end justify-center pointer-events-none">
                <span
                  style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
                  className="text-white font-bold uppercase tracking-[0.2em] text-xs drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] select-none group-hover:text-pink-200 transition-colors"
                >
                  {cat.name}
                </span>
              </div>
            </Link>
          ))}
        </div>

        {/* 
          EXACT MATCH OF REFERENCE IMAGE:
          Slender horizontal sliding showcase lines directly beneath cards:
          - Inactive: very thin light pastel pink line (h-[1.5px] w-6 bg-pink-200/50)
          - Active: active vibrant solid pink indicator (h-[2px] w-12 bg-[#E72382])
        */}
        <div className="flex gap-3 justify-center items-center mt-6 select-none">
          {categories.map((_, idx) => {
            const isActive = activeSlide === idx;
            return (
              <button
                key={idx}
                onClick={() => scrollToSlide(idx)}
                aria-label={`Slide showcase line ${idx + 1}`}
                className={`transition-all duration-300 rounded-full cursor-pointer p-0 border-none ${
                  isActive
                    ? "w-12 h-[2.5px] bg-[#E72382]"
                    : "w-6 h-[1.5px] bg-pink-200/60 hover:bg-[#E72382]/40"
                }`}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
}

"use client";

import Image from "next/image";
import Link from "next/link";

export default function HeroSection() {
  return (
    <section className="w-full h-[60vh] md:h-screen relative overflow-hidden">
      {/* Edge-to-Edge Hero Image */}
      <Image
        src="https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1920&auto=format&fit=crop"
        alt="Kala Silver Ear Cuffs"
        fill
        priority
        className="object-cover object-center"
        sizes="100vw"
      />

      {/* Text Overlay inside gradient */}
      <div className="absolute bottom-0 w-full bg-gradient-to-t from-black/80 to-transparent p-6 pb-10 flex flex-col justify-end select-none">
        <span className="text-[10px] sm:text-xs uppercase tracking-[0.3em] font-bold text-gray-300 block mb-2 font-sans">
          The Exquisite Collection
        </span>

        {/* Hero Title: font-playfair text-white text-4xl md:text-5xl font-bold tracking-wide */}
        <h1 className="font-playfair text-white text-4xl md:text-5xl font-bold tracking-wide uppercase leading-none">
          EAR CUFFS
        </h1>

        <p className="mt-2 text-xs sm:text-sm text-gray-300 font-light tracking-wide max-w-md">
          Stack your ears with sass and elegance
        </p>

        {/* Dark Pill CTA Button: mt-6 bg-[#1a1a2e] text-white uppercase text-[10px] tracking-widest font-bold py-3 px-8 rounded-full w-max */}
        <Link
          href="/shop/ear-cuffs"
          className="mt-6 bg-[#1a1a2e] text-white uppercase text-[10px] tracking-widest font-bold py-3 px-8 rounded-full w-max hover:bg-[#E72382] transition-colors duration-300 shadow-lg active:scale-95"
        >
          Explore The Edit
        </Link>
      </div>
    </section>
  );
}

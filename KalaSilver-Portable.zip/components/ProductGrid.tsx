"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/context/CartContext";

interface Product {
  id: string;
  title: string;
  price: string;
  rawPrice: number;
  image: string;
}

const products: Product[] = [
  {
    id: "p-1",
    title: "Tri-Color Dual Strand Tennis Bracelet",
    price: "₹1,899",
    rawPrice: 1899,
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-2",
    title: "Sapphire Blue Teardrop Stud Earrings",
    price: "₹1,499",
    rawPrice: 1499,
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-3",
    title: "Princess Cut Solitaire Men's Stud",
    price: "₹999",
    rawPrice: 999,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-4",
    title: "Sterling Silver Floral Drop Necklace",
    price: "₹2,499",
    rawPrice: 2499,
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-5",
    title: "Men's Classic Curb Link Bracelet",
    price: "₹2,299",
    rawPrice: 2299,
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-6",
    title: "Rainbow Gem Inset Men's Bracelet",
    price: "₹2,199",
    rawPrice: 2199,
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-7",
    title: "Round Brilliant Cut Diamond Stud",
    price: "₹1,299",
    rawPrice: 1299,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-8",
    title: "925 Filigree Heart Stud Earrings",
    price: "₹1,199",
    rawPrice: 1199,
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-9",
    title: "Luxe Gold-Plated Tennis Bracelet In Box",
    price: "₹2,699",
    rawPrice: 2699,
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-10",
    title: "Silver Pavé Tennis Bracelet In Box",
    price: "₹2,499",
    rawPrice: 2499,
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-11",
    title: "Classic Solitaire Earring On Model",
    price: "₹1,399",
    rawPrice: 1399,
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-12",
    title: "Minimalist Dual Band Silver Ring",
    price: "₹1,599",
    rawPrice: 1599,
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop",
  },
];

export default function ProductGrid() {
  const [addedIds, setAddedIds] = useState<string[]>([]);
  const { addItem } = useCart();

  const handleAddToCart = (product: Product) => {
    addItem({
      id: product.id,
      name: product.title,
      price: product.rawPrice,
      image: product.image,
    });

    setAddedIds((prev) => [...prev, product.id]);
    setTimeout(() => {
      setAddedIds((prev) => prev.filter((item) => item !== product.id));
    }, 1800);
  };

  return (
    <section className="py-16 md:py-24 bg-white" id="products">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#E72382] mb-1.5">
            CRAFTED WITH PRECISION
          </p>
          <h2 className="font-sans font-black text-3xl sm:text-4xl text-[#1a1a2e] tracking-tight">
            Our <span className="text-[#E72382]">Products</span>
          </h2>
          <p className="text-gray-400 text-xs mt-2 max-w-md mx-auto">
            Each creation is a testament to timeless beauty and master craftsmanship.
          </p>
          <div className="w-10 h-0.5 bg-[#E72382] mx-auto mt-4 rounded-full" />
        </div>

        {/* Exact Grid: grid-cols-2 md:grid-cols-4 gap-4 px-4 w-full max-w-7xl mx-auto */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 px-4 w-full max-w-7xl mx-auto">
          {products.map((product) => {
            const isAdded = addedIds.includes(product.id);
            return (
              <div
                key={product.id}
                className="group flex flex-col h-full bg-white"
              >
                {/* 1. Image Container: aspect-square bg-gray-50 rounded-2xl relative overflow-hidden mb-3 */}
                <div className="aspect-square bg-gray-50 rounded-2xl relative overflow-hidden mb-3 w-full">
                  <Link
                    href={`/product/${product.id}`}
                    className="block h-full w-full"
                  >
                    <Image
                      src={product.image}
                      alt={product.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, 25vw"
                    />
                  </Link>

                  {/* Wishlist Icon: absolute bottom-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm text-gray-500 */}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                    aria-label="Wishlist"
                    className="absolute bottom-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm text-gray-500 hover:text-[#E72382] transition-colors"
                  >
                    ♡
                  </button>
                </div>

                {/* 2. Typography: Title & Price */}
                <div className="flex flex-col flex-1">
                  <Link href={`/product/${product.id}`} className="block">
                    {/* Title: text-sm font-semibold text-gray-900 truncate mb-1 */}
                    <h3 className="text-sm font-semibold text-gray-900 truncate mb-1 group-hover:text-[#E72382] transition-colors">
                      {product.title}
                    </h3>
                    {/* Price: text-lg font-black text-gray-900 mb-4 */}
                    <p className="text-lg font-black text-gray-900 mb-4">
                      {product.price}
                    </p>
                  </Link>
                </div>

                {/* 3. Add to Cart Button (Critical): w-full bg-[#E72382] text-white font-bold text-sm py-2.5 rounded-lg hover:bg-pink-700 transition-colors */}
                <button
                  onClick={() => handleAddToCart(product)}
                  className="w-full bg-[#E72382] text-white font-bold text-sm py-2.5 rounded-lg hover:bg-pink-700 transition-colors active:scale-[0.98] cursor-pointer"
                >
                  {isAdded ? "Added ✓" : "Add to Cart"}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

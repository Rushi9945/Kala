/**
 * Root-level loading.tsx
 * Shown by Next.js App Router while any page-level async module
 * (bootstrapped by chunk 7358 / module 62772) is being fetched and hydrated.
 *
 * Uses the Kala Silver brand palette with elegant skeleton shimmer animation.
 */
export default function RootLoading() {
  return (
    <div className="w-full flex flex-col min-h-screen animate-pulse">
      {/* Hero Skeleton */}
      <div className="w-full h-[520px] sm:h-[640px] bg-gradient-to-br from-gray-100 via-pink-50 to-gray-100 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skeleton-sweep" />
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 w-full px-6">
          <div className="h-4 w-32 rounded-full bg-pink-200/60" />
          <div className="h-10 w-64 rounded-xl bg-gray-200/70" />
          <div className="h-6 w-80 rounded-lg bg-gray-200/50" />
          <div className="flex gap-3 mt-2">
            <div className="h-11 w-36 rounded-full bg-[#E72382]/20" />
            <div className="h-11 w-36 rounded-full bg-gray-200/50" />
          </div>
        </div>
      </div>

      {/* Category Pills Skeleton */}
      <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="h-5 w-40 rounded-full bg-gray-200 mb-6" />
        <div className="flex gap-4 overflow-hidden">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="flex-none w-36 h-48 rounded-2xl bg-gradient-to-br from-gray-100 to-pink-50"
            />
          ))}
        </div>
      </div>

      {/* Product Grid Skeleton */}
      <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="h-5 w-56 rounded-full bg-gray-200 mb-6" />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex flex-col gap-2">
              <div className="aspect-square rounded-2xl bg-gradient-to-br from-gray-100 to-pink-50" />
              <div className="h-3.5 w-3/4 rounded-full bg-gray-200" />
              <div className="h-3 w-1/2 rounded-full bg-gray-100" />
              <div className="h-8 w-full rounded-lg bg-[#E72382]/10" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

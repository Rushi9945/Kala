"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

interface Category {
  id: string;
  name: string;
  tag: string;
  image: string;
  slug: string;
}

const categories: Category[] = [
  {
    id: "cat-1",
    name: "Men's Bracelet",
    tag: "92.5 SILVER",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAnU0zaigTlsLI-OJVoA9GUJdrIqirbZUrsn2661mmgO5zaot4HCsZdKPak97f3iGYeHrvaDOSyxaWPtoiCP57EdOsmEWP6fLpIQKGwUiMJhpOj83YjosGKXyfDqnG4ofNCVZ6sPVfmpnnbtHd0fDdX7g29AKcZHR6oZexFD2xoutBNNnOd18km6meT_xVk2fHJ8kg-b93kgutcwZzyAMqJHQAmcWCHyjXYOjXQLQ",
    slug: "mens-bracelet",
  },
  {
    id: "cat-2",
    name: "Ear Cuffs",
    tag: "CURATED",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCboD64A0Pu24OhTRcL2REjR47u2-Dtks_zD8RT0i0WhOT2NQ5yE2CZpR6X-tpH148u51B04It7LsICbmeajEU_zpNZqsHcLW9O2usAkZ-cZjmJklnesVEX6dkT3ghz_-FmLhYTWYCxXv7H8-u77_wquoWX42rI5vEjzc2iNP0br6iLYJm54zPjKZG5SxGWVak287c3Io0lt8ymTYVK-fgJB05lbThlYOr8U5u64Q",
    slug: "ear-cuffs",
  },
  {
    id: "cat-3",
    name: "Men's Chains",
    tag: "SOLID LINK",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAk1KCavJYtDvCFscWrDL_1qIHEzGHPBhc0F86e0nuCihTSPZmuJtTl2GCiVaP83XX-08mgsJlByYBdtrs4RicuOHXaE8hcPeF3ZewZJ95mg0GnYrttd6e7vAU-NOPb6YzK0xD2Xwjz20NJaVCE1B6vNi7okbH7Vk6AwgB6ypqdd2eyEJFbO_HNNeuroNe-A02C3AJBz66JkvId_SXjJTmw5xETtqRH-u9HgbtdbA",
    slug: "mens-chains",
  },
  {
    id: "cat-4",
    name: "Men's Studs",
    tag: "SOLITAIRE",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDqdFkBu42g66FmS0DpzV5oGa_pG9QX1Q7sjZEBajRmWcon7CRRaz9zDfWvd7B2zEKZR9jAIv7b-4i75ceySpaTsMAO-9awldoldg-hTPaKM_FYWFXI-ND3vidU3dW7TTnkEJzu54bz0SrQ8etlsE6DYtmkcTDjy2NrG5cEg8hurG69SAdbYZDmoaKSPRvzSJ5KD_egQyqCH7uR03puHwbQ6Io4JxFnuS-dPiSJng",
    slug: "mens-studs",
  },
  {
    id: "cat-5",
    name: "Bracelets",
    tag: "TIMELESS",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuCKBq6nuceEY5vxlYdF_DoQmAnOy6D3WVDH9qd5zJDfEoOo_WJMvyqM9D_6bXRak_yiuIpnUoWDw0K-4Nf3PAeA5Dm2eK7d5E1lZ5OggL3ix2PizbraHTjetHtgKnX6e2YdMRm95lRcFQo_0mkHbzj-B8Z5Jqa8BpnIYPRwZPA0WTgzNAJ9CGRGijevAAU7_lH1Ij2657ZJD9DxFZzT5DqUa-veyGEf0RubQwEOtQ",
    slug: "bracelets",
  },
];

export default function CategoryCarousel() {
  const [activeDot, setActiveDot] = useState(0);

  return (
    <section className="py-14 bg-white" id="categories">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Category Title Header */}
        <div className="text-center mb-10">
          <span className="text-[11px] font-semibold tracking-[0.25em] text-gray-400 uppercase">
            THE COLLECTIONS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight mt-1">
            Shop by <span className="text-[#E72382] italic font-serif">Category</span>
          </h2>
          <p className="text-xs sm:text-sm font-medium tracking-wider text-gray-500 uppercase mt-2">
            EXPLORE OUR HANDCRAFTED TREASURES CURATED JUST FOR YOU
          </p>
          <div className="w-12 h-[3px] bg-[#E72382] rounded-full mx-auto my-3" />
        </div>

        {/* Category Grid/Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-5">
          {categories.map((cat, idx) => (
            <Link
              key={cat.id}
              href={`/category/${cat.slug}`}
              className={`group relative rounded-xl overflow-hidden aspect-[3/4] bg-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 ${
                idx === 4 ? "col-span-2 sm:col-span-1" : ""
              }`}
            >
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent flex items-end justify-between p-3.5">
                <span className="text-white text-xs font-bold uppercase tracking-wider">
                  {cat.name}
                </span>
                <span
                  style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
                  className="text-[9px] font-semibold text-white/80 uppercase tracking-widest hidden sm:inline-block"
                >
                  {cat.tag}
                </span>
              </div>
            </Link>
          ))}
        </div>

        {/* Slider Pagination Indicator */}
        <div className="flex justify-center items-center space-x-2 mt-8">
          <button
            onClick={() => setActiveDot(0)}
            aria-label="Category Page 1"
            className={`transition-all duration-300 rounded-full ${
              activeDot === 0 ? "w-6 h-2 bg-[#E72382]" : "w-2 h-2 bg-gray-300"
            }`}
          />
          <button
            onClick={() => setActiveDot(1)}
            aria-label="Category Page 2"
            className={`transition-all duration-300 rounded-full ${
              activeDot === 1 ? "w-6 h-2 bg-[#E72382]" : "w-2 h-2 bg-gray-300"
            }`}
          />
          <button
            onClick={() => setActiveDot(2)}
            aria-label="Category Page 3"
            className={`transition-all duration-300 rounded-full ${
              activeDot === 2 ? "w-6 h-2 bg-[#E72382]" : "w-2 h-2 bg-gray-300"
            }`}
          />
        </div>
      </div>
    </section>
  );
}

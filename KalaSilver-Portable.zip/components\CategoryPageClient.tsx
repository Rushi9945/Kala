"use client";

import React, { useState, useEffect, useRef, useMemo } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  House,
  ChevronRight,
  LayoutGrid,
  List,
  ArrowLeft,
  SlidersHorizontal,
  ArrowUpDown,
  Heart,
  Filter,
  Check,
} from "lucide-react";
import { CATEGORIES_DATA, ALL_PRODUCTS, CategoryProduct } from "@/lib/categoryData";

interface CategoryPageClientProps {
  categoryId: string;
  initialMaxPrice?: number;
}

export default function CategoryPageClient({
  categoryId,
  initialMaxPrice,
}: CategoryPageClientProps) {
  const router = useRouter();

  // Normalize slug
  const normalizedId = categoryId.toLowerCase();
  const categoryInfo = CATEGORIES_DATA[normalizedId] || {
    id: normalizedId,
    slug: normalizedId,
    displayName: normalizedId.charAt(0).toUpperCase() + normalizedId.slice(1),
    pluralName: normalizedId.charAt(0).toUpperCase() + normalizedId.slice(1),
  };

  // State
  const [layoutMode, setLayoutMode] = useState<"grid" | "list">("grid");
  const [maxPrice, setMaxPrice] = useState<number | null>(initialMaxPrice || null);
  const [customPriceInput, setCustomPriceInput] = useState<string>("");
  const [sortOption, setSortOption] = useState<string>("featured");
  const [wishlist, setWishlist] = useState<Record<string, boolean>>({});

  // Dropdown states
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);

  const filterRef = useRef<HTMLDivElement>(null);
  const sortRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (filterRef.current && !filterRef.current.contains(event.target as Node)) {
        setIsFilterOpen(false);
      }
      if (sortRef.current && !sortRef.current.contains(event.target as Node)) {
        setIsSortOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Filter products by category and maxPrice
  const filteredProducts = useMemo(() => {
    let list = ALL_PRODUCTS.filter((item) => {
      // match category slug or variants
      if (normalizedId === "mens-bracelet" || normalizedId === "bracelets") {
        return item.category === "mens-bracelet" || item.category === "bracelets";
      }
      return item.category === normalizedId;
    });

    // If no direct category matches, fallback to returning products matching category loosely or all items
    if (list.length === 0) {
      list = ALL_PRODUCTS;
    }

    if (maxPrice !== null && maxPrice > 0) {
      list = list.filter((item) => item.price <= maxPrice);
    }

    // Sort
    if (sortOption === "price-low") {
      list = [...list].sort((a, b) => a.price - b.price);
    } else if (sortOption === "price-high") {
      list = [...list].sort((a, b) => b.price - a.price);
    } else if (sortOption === "newest") {
      list = [...list].reverse();
    }

    return list;
  }, [normalizedId, maxPrice, sortOption]);

  const toggleWishlist = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setWishlist((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleApplyCustomPrice = () => {
    const parsed = parseInt(customPriceInput, 10);
    if (!isNaN(parsed) && parsed > 0) {
      setMaxPrice(parsed);
      setIsFilterOpen(false);
    }
  };

  const clearFilter = () => {
    setMaxPrice(null);
    setCustomPriceInput("");
    setIsFilterOpen(false);
  };

  const budgetOptions = [1999, 2999, 3999, 4999];

  return (
    <div className="min-h-screen bg-white">
      {/* ── Breadcrumb & View Toggle Bar (Sticky) ────────────────────────── */}
      <nav className="sticky top-[72px] z-30 bg-white/80 backdrop-blur-md border-b border-gray-100 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 flex items-center justify-between">
          {/* Breadcrumb Links */}
          <div className="flex items-center space-x-2 text-xs md:text-sm text-gray-500">
            <Link
              href="/"
              className="flex items-center gap-1 hover:text-[#E72382] transition-colors"
            >
              <House className="w-3.5 h-3.5" />
              <span>Home</span>
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
            <Link
              href="/shop"
              className="hover:text-[#E72382] transition-colors"
            >
              Shop
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
            <span className="font-semibold text-[#E72382] tracking-tight">
              {categoryInfo.displayName}
            </span>
          </div>

          {/* Desktop Grid / List Layout Switcher */}
          <div className="hidden md:flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setLayoutMode("grid")}
              aria-label="Grid layout"
              className={`p-1.5 rounded-md transition-all ${
                layoutMode === "grid"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-400 hover:text-gray-700"
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setLayoutMode("list")}
              aria-label="List layout"
              className={`p-1.5 rounded-md transition-all ${
                layoutMode === "list"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-400 hover:text-gray-700"
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* ── Category Header Section ─────────────────────────────────────── */}
      <header className="relative pt-8 pb-6 md:pt-12 md:pb-10 overflow-hidden text-center">
        {/* Soft Pink Glow Backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] md:w-[1000px] h-[300px] md:h-[400px] bg-[#FEF1F7] blur-[100px] md:blur-[120px] rounded-full -z-10 pointer-events-none opacity-80" />

        <div className="max-w-4xl mx-auto px-4 relative">
          {/* Back Button */}
          <button
            onClick={() => router.back()}
            className="absolute left-4 top-0 p-2 text-[#E72382] hover:bg-[#FEF1F7] rounded-full transition-colors"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5 md:w-6 md:h-6" />
          </button>

          {/* Exclusive Collection Badge */}
          <div className="inline-block px-4 py-1.5 mb-5 rounded-full bg-[#FEF1F7] text-[#E72382] text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] border border-[#E72382]/20 shadow-sm">
            Exclusive Collection
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-black text-gray-900 mb-4 tracking-tighter italic leading-none font-headline">
            Our{" "}
            <span className="text-[#E72382]">{categoryInfo.displayName}</span>
          </h1>

          {/* Pink Underline Dash with Glow */}
          <div className="w-20 h-1.5 bg-[#E72382] mx-auto mb-6 rounded-full shadow-[0_2px_15px_rgba(231,35,130,0.4)]" />

          {/* Description */}
          <p className="text-sm md:text-base text-gray-600 max-w-2xl mx-auto font-normal leading-relaxed">
            Discover our handcrafted {categoryInfo.displayName.toLowerCase()}, where ancient traditions meet modern elegance. Each piece is a testament to purity and panache.
          </p>
        </div>
      </header>

      {/* ── Filter & Sort Bar ───────────────────────────────────────────── */}
      <section className="border-y border-gray-100 bg-white/50 backdrop-blur-sm sticky top-[120px] z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          {/* Left: Curated Filter Dropdown & Count */}
          <div className="flex items-center gap-4">
            <div className="relative" ref={filterRef}>
              <button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className={`flex items-center gap-2 px-3.5 py-1.5 text-xs md:text-sm font-medium rounded-full border transition-all ${
                  maxPrice
                    ? "border-[#E72382] text-[#E72382] bg-[#FEF1F7]"
                    : "border-gray-200 text-gray-700 hover:border-gray-400 bg-white"
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#E72382]" />
                <span>{maxPrice ? `Under ₹${maxPrice.toLocaleString()}` : "Curated Filter"}</span>
              </button>

              {/* Filter Dropdown Popover */}
              {isFilterOpen && (
                <div className="absolute left-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-gray-100 p-4 z-40 animate-in fade-in-50 zoom-in-95 duration-150">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-gray-100">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
                      Investment Selection
                    </span>
                    {maxPrice && (
                      <button
                        onClick={clearFilter}
                        className="text-xs font-semibold text-[#E72382] hover:underline"
                      >
                        Reset
                      </button>
                    )}
                  </div>

                  <div className="space-y-1">
                    <button
                      onClick={clearFilter}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                        maxPrice === null
                          ? "bg-[#FEF1F7] text-[#E72382] font-bold"
                          : "text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      <span>All Treasures</span>
                      {maxPrice === null && <Check className="w-3.5 h-3.5 text-[#E72382]" />}
                    </button>

                    {budgetOptions.map((price) => (
                      <button
                        key={price}
                        onClick={() => {
                          setMaxPrice(price);
                          setIsFilterOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                          maxPrice === price
                            ? "bg-[#FEF1F7] text-[#E72382] font-bold"
                            : "text-gray-700 hover:bg-gray-50"
                        }`}
                      >
                        <span>Under ₹{price.toLocaleString()}</span>
                        {maxPrice === price && <Check className="w-3.5 h-3.5 text-[#E72382]" />}
                      </button>
                    ))}
                  </div>

                  {/* Custom Price Input */}
                  <div className="mt-4 pt-3 border-t border-gray-100">
                    <label className="block text-[11px] font-medium text-gray-500 mb-1.5">
                      Custom Maximum Budget
                    </label>
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-gray-400">
                          ₹
                        </span>
                        <input
                          type="number"
                          placeholder="Amount"
                          value={customPriceInput}
                          onChange={(e) => setCustomPriceInput(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleApplyCustomPrice()}
                          className="w-full pl-6 pr-2 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-[#E72382]"
                        />
                      </div>
                      <button
                        onClick={handleApplyCustomPrice}
                        className="px-3 py-1.5 bg-[#E72382] text-white text-xs font-bold rounded-lg hover:bg-[#d01b73] transition-colors"
                      >
                        APPLY
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <span className="text-xs text-gray-500 font-medium">
              {filteredProducts.length} Products Found
            </span>
          </div>

          {/* Right: Sort Dropdown */}
          <div className="relative" ref={sortRef}>
            <button
              onClick={() => setIsSortOpen(!isSortOpen)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs md:text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
              <span>
                Sort:{" "}
                <span className="font-semibold text-gray-900">
                  {sortOption === "featured"
                    ? "Featured"
                    : sortOption === "price-low"
                    ? "Price: Low to High"
                    : sortOption === "price-high"
                    ? "Price: High to Low"
                    : "Newest Arrivals"}
                </span>
              </span>
            </button>

            {isSortOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 p-2 z-40 animate-in fade-in-50 zoom-in-95 duration-150">
                {[
                  { value: "featured", label: "Featured" },
                  { value: "price-low", label: "Price: Low to High" },
                  { value: "price-high", label: "Price: High to Low" },
                  { value: "newest", label: "Newest Arrivals" },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      setSortOption(opt.value);
                      setIsSortOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                      sortOption === opt.value
                        ? "bg-[#FEF1F7] text-[#E72382] font-bold"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <span>{opt.label}</span>
                    {sortOption === opt.value && <Check className="w-3.5 h-3.5 text-[#E72382]" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ── Products Display ────────────────────────────────────────────── */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14">
        {filteredProducts.length === 0 ? (
          /* Empty State */
          <div className="py-20 text-center flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4 text-gray-400">
              <Filter className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No treasures found</h3>
            <p className="text-sm text-gray-500 max-w-md mb-6">
              We couldn&apos;t find any pieces matching your specific filter criteria. Try clearing your budget or browsing our full collection.
            </p>
            <button
              onClick={clearFilter}
              className="px-6 py-2.5 bg-[#E72382] text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-[#d01b73] transition-colors"
            >
              Clear Filter
            </button>
          </div>
        ) : layoutMode === "grid" ? (
          /* Grid View (Matching Screenshots: 2 cols on mobile, 3 on md, 4 on lg) */
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
            {filteredProducts.map((product) => {
              const isWishlisted = !!wishlist[product.id];
              return (
                <div
                  key={product.id}
                  className="group flex flex-col bg-white rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border border-transparent hover:border-pink-100"
                >
                  {/* Image Container with Wishlist Icon */}
                  <div className="relative aspect-square w-full bg-gray-50 overflow-hidden rounded-2xl">
                    <Image
                      src={product.image}
                      alt={product.title}
                      fill
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                      className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />

                    {/* Wishlist Heart Button */}
                    <button
                      onClick={(e) => toggleWishlist(product.id, e)}
                      aria-label="Wishlist"
                      className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all text-gray-600 hover:text-[#E72382]"
                    >
                      <Heart
                        className={`w-4 h-4 transition-colors ${
                          isWishlisted ? "fill-[#E72382] text-[#E72382]" : "text-gray-600"
                        }`}
                      />
                    </button>
                  </div>

                  {/* Product Details */}
                  <div className="pt-3 pb-2 px-1 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs sm:text-sm font-bold text-gray-900 uppercase tracking-tight line-clamp-1 mb-1 font-headline">
                        {product.title}
                      </h3>
                      <p className="text-xs sm:text-sm font-black text-gray-900 tracking-tight">
                        ₹{product.price.toLocaleString()}
                      </p>
                    </div>

                    {/* Full-Width Brand Pink Add to Cart Button */}
                    <button
                      onClick={() => alert(`Added ${product.title} to Cart!`)}
                      className="w-full mt-3 py-2 sm:py-2.5 px-4 bg-[#E72382] hover:bg-[#d01b73] text-white text-xs sm:text-sm font-bold rounded-lg transition-colors active:scale-[0.98] shadow-sm"
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* List View */
          <div className="space-y-4 max-w-4xl mx-auto">
            {filteredProducts.map((product) => {
              const isWishlisted = !!wishlist[product.id];
              return (
                <div
                  key={product.id}
                  className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-white rounded-2xl border border-gray-100 hover:shadow-lg transition-all"
                >
                  <div className="relative w-36 h-36 aspect-square bg-gray-50 rounded-xl overflow-hidden shrink-0">
                    <Image
                      src={product.image}
                      alt={product.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1 flex flex-col justify-between w-full">
                    <div>
                      <div className="flex items-center justify-between">
                        <h3 className="text-base font-bold text-gray-900 uppercase tracking-tight font-headline">
                          {product.title}
                        </h3>
                        <button
                          onClick={(e) => toggleWishlist(product.id, e)}
                          className="p-2 text-gray-400 hover:text-[#E72382] transition-colors"
                        >
                          <Heart
                            className={`w-5 h-5 ${
                              isWishlisted ? "fill-[#E72382] text-[#E72382]" : ""
                            }`}
                          />
                        </button>
                      </div>
                      <p className="text-lg font-black text-gray-900 mt-1">
                        ₹{product.price.toLocaleString()}
                      </p>
                    </div>

                    <div className="mt-4 flex items-center gap-3">
                      <button
                        onClick={() => alert(`Added ${product.title} to Cart!`)}
                        className="py-2.5 px-6 bg-[#E72382] hover:bg-[#d01b73] text-white text-xs font-bold rounded-lg transition-colors"
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

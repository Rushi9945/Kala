"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface GiftTier {
  id: string;
  label: string;
  rangeLabel: string;
  minPrice: number;
  maxPrice: number | null;
  emoji: string;
  tagline: string;
  productCount: number;
  accentColor: string;
  bgColor: string;
  borderColor: string;
  popular?: boolean;
}

// ── Sparkle icon ──────────────────────────────────────────────────────────────
const SparkleIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M12 2 L13.5 9 L20 10.5 L13.5 12 L12 19 L10.5 12 L4 10.5 L10.5 9 Z" />
  </svg>
);

// ── Gift Tier Card ────────────────────────────────────────────────────────────
function GiftTierCard({
  tier,
  index,
}: {
  tier: GiftTier;
  index: number;
}) {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setVisible(true), index * 100);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ease-out ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
      }`}
    >
      <Link
        href={`/shop?min=${tier.minPrice}${
          tier.maxPrice ? `&max=${tier.maxPrice}` : ""
        }`}
        className="group block h-full"
      >
        <div
          className={`relative h-full rounded-2xl border-2 ${tier.borderColor} ${tier.bgColor} p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl cursor-pointer overflow-hidden`}
        >
          {/* Popular badge */}
          {tier.popular && (
            <div className="absolute top-4 right-4 flex items-center gap-1 bg-magenta-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wide">
              <SparkleIcon />
              Popular
            </div>
          )}

          {/* Background decoration */}
          <div
            className="absolute -bottom-8 -right-8 w-32 h-32 rounded-full opacity-10 transition-all duration-300 group-hover:opacity-20 group-hover:scale-110"
            style={{ backgroundColor: tier.accentColor }}
          />

          {/* Content */}
          <div className="relative">
            {/* Emoji */}
            <div className="text-4xl mb-4">{tier.emoji}</div>

            {/* Budget range */}
            <div
              className="text-xs font-bold uppercase tracking-widest mb-1"
              style={{ color: tier.accentColor }}
            >
              {tier.rangeLabel}
            </div>

            {/* Label */}
            <h3 className="font-serif font-semibold text-gray-900 text-lg leading-tight mb-2 group-hover:text-magenta-700 transition-colors duration-200">
              {tier.label}
            </h3>

            {/* Tagline */}
            <p className="text-xs text-gray-500 leading-relaxed mb-4">
              {tier.tagline}
            </p>

            {/* Footer */}
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400 font-medium">
                {tier.productCount}+ products
              </span>
              <div
                className="flex items-center gap-1 text-xs font-semibold transition-all duration-200 group-hover:gap-2"
                style={{ color: tier.accentColor }}
              >
                Shop Now
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2.5}
                  stroke="currentColor"
                  className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}

// ── Main Section ──────────────────────────────────────────────────────────────
interface GiftsByBudgetProps {
  tiers: GiftTier[];
}

export default function GiftsByBudget({ tiers }: GiftsByBudgetProps) {
  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <p className="section-subtitle">Gifting Made Easy</p>
          <h2 className="section-title">Gifts by Budget</h2>
          <p className="mt-3 text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
            Find the perfect jewellery gift for every budget — from thoughtful
            everyday pieces to luxurious statement collections.
          </p>
        </div>

        {/* Tiers grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {tiers.map((tier, i) => (
            <GiftTierCard key={tier.id} tier={tier} index={i} />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-12 text-center">
          <p className="text-gray-500 text-sm mb-4">
            Need help choosing? Our jewellery experts are here for you.
          </p>
          <Link href="/contact" className="btn-primary">
            Get Personalised Advice ✦
          </Link>
        </div>
      </div>
    </section>
  );
}

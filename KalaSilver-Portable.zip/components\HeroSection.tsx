"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function HeroSection() {
  const [activeDot, setActiveDot] = useState(1);

  return (
    <section className="relative bg-[#ebd9d2] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-14">
        <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-r from-[#d9beaf] via-[#f0e3db] to-[#dec3b5] flex flex-col md:flex-row items-center justify-between min-h-[380px] lg:min-h-[460px]">
          {/* Left Model Image */}
          <div className="w-full md:w-1/3 h-64 md:h-[460px] relative overflow-hidden">
            <Image
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuC62aNYPzN-dArNRkcBKz7Yw-LgXszuhUDMHLAfdWjH19289oCi34MTBoazCrUT-IkpaOzmT0TlQRwNPrOh8NZDHZMMWi0JLr8yWF0A14D2NDgM3a-W7ADOKdr5McCI8hG94pW9gObIKCTBsMBP_Zy85TiEPfbmeuW-2dxQefAtQECfQF7Fa0b-RBhPni_iTLDb8Ec106kpZespqZUfkloNxRtlDAqFjHgtruT1KQ"
              alt="Model wearing elegant silver star ear cuff"
              fill
              priority
              className="object-cover object-center filter brightness-95"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#f0e3db]/60 hidden md:block" />
          </div>

          {/* Hero Headline & Core Message */}
          <div className="w-full md:w-1/3 py-8 px-6 text-center z-10 flex flex-col items-center justify-center">
            <span className="text-xs uppercase tracking-[0.3em] font-bold text-gray-700 block mb-2 font-headline">
              The Exquisite Collection
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-normal tracking-wide text-neutral-900 uppercase font-serif">
              EAR CUFFS
            </h1>
            <p className="mt-3 text-sm md:text-base font-light text-neutral-600 tracking-wide">
              Stack your ears with sass and elegance
            </p>
            <div className="mt-6">
              <Link
                href="/shop/ear-cuffs"
                className="inline-block px-8 py-3 bg-neutral-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-[#E72382] transition-colors duration-300 shadow-md rounded-full"
              >
                Explore The Edit
              </Link>
            </div>
          </div>

          {/* Right Model Image */}
          <div className="w-full md:w-1/3 h-64 md:h-[460px] relative overflow-hidden">
            <Image
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCknNsq_EbzI3KBKGJt8EyXKHA2atqa-ipe7BqsGxO8Re1d-qyTSJNkox04EvQYxolnEMeJ4ovDfac-DlXmKnSYVbuE83THsiJt9vvofJrRNLBjgD5vhtFm3nDQ0eorbRlwsS6me3GDU1ot-L2I1nUBI3Fbi2fw7NGKS6hCrjIHR8ZdkHHKzFytdnvzWKP1DjWDeSARpGr38Tm6JpN7wTbQj_E9D5K5ZOjFE9vt8Q"
              alt="Model showcasing ear cuffs and studs collection"
              fill
              priority
              className="object-cover object-center filter brightness-95"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent to-[#f0e3db]/60 hidden md:block" />
          </div>
        </div>

        {/* Pagination Carousel Indicators */}
        <div className="flex justify-center items-center space-x-2 mt-6">
          <button
            onClick={() => setActiveDot(0)}
            aria-label="Slide 1"
            className={`transition-all duration-300 rounded-full ${
              activeDot === 0 ? "w-6 h-2.5 bg-[#E72382]" : "w-2.5 h-2.5 bg-gray-300"
            }`}
          />
          <button
            onClick={() => setActiveDot(1)}
            aria-label="Slide 2"
            className={`transition-all duration-300 rounded-full ${
              activeDot === 1 ? "w-6 h-2.5 bg-[#E72382]" : "w-2.5 h-2.5 bg-gray-300"
            }`}
          />
          <button
            onClick={() => setActiveDot(2)}
            aria-label="Slide 3"
            className={`transition-all duration-300 rounded-full ${
              activeDot === 2 ? "w-6 h-2.5 bg-[#E72382]" : "w-2.5 h-2.5 bg-gray-300"
            }`}
          />
        </div>
      </div>
    </section>
  );
}

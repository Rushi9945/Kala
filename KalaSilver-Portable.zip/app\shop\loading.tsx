/**
 * Shop/Category async route loading skeleton
 * Displayed while the dynamic category page module (one of the 8 async
 * child modules from chunk 7358) hydrates.
 */
export default function ShopLoading() {
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-pulse">
      {/* Category header skeleton */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex flex-col gap-2">
          <div className="h-4 w-24 rounded-full bg-pink-100" />
          <div className="h-8 w-48 rounded-xl bg-gray-200" />
        </div>
        <div className="h-10 w-32 rounded-full bg-gray-100" />
      </div>

      {/* Filter chips skeleton */}
      <div className="flex gap-2 mb-8 overflow-hidden">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex-none h-9 w-24 rounded-full bg-gray-100" />
        ))}
      </div>

      {/* Product grid skeleton */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
        {Array.from({ length: 12 }).map((_, i) => (
          <div key={i} className="flex flex-col gap-2">
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-gray-100 to-pink-50" />
            <div className="h-3.5 w-3/4 rounded-full bg-gray-200" />
            <div className="h-3 w-1/2 rounded-full bg-gray-100" />
            <div className="flex items-center justify-between mt-1">
              <div className="h-5 w-20 rounded-full bg-[#E72382]/15" />
              <div className="h-5 w-12 rounded-full bg-gray-100" />
            </div>
            <div className="h-9 w-full rounded-xl bg-gray-100" />
          </div>
        ))}
      </div>
    </div>
  );
}

import { MetadataRoute } from "next";

/**
 * robots.txt — surfaced as /robots.txt
 * Aligned with the app's route manifest from chunk 7358
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: ["/", "/shop", "/shop/", "/category/", "/login"],
        disallow: ["/api/", "/_next/", "/admin"],
      },
    ],
    sitemap: "https://kalasilver.in/sitemap.xml",
    host: "https://kalasilver.in",
  };
}

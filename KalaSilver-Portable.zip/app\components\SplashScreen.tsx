"use client";

import { useEffect, useState } from "react";

interface SplashScreenProps {
  onFinish?: () => void;
  holdDuration?: number;
}

export default function SplashScreen({
  onFinish,
  holdDuration = 2500,
}: SplashScreenProps) {
  const [mounted, setMounted] = useState(true);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    // Hold for 2.5 seconds, then trigger fade out
    const holdTimer = setTimeout(() => {
      setFading(true);
    }, holdDuration);

    // After 500ms fade transition finishes, unmount completely from DOM
    const unmountTimer = setTimeout(() => {
      setMounted(false);
      if (onFinish) {
        onFinish();
      }
    }, holdDuration + 500);

    return () => {
      clearTimeout(holdTimer);
      clearTimeout(unmountTimer);
    };
  }, [holdDuration, onFinish]);

  if (!mounted) return null;

  return (
    <div
      aria-label="Loading KalaSilver"
      className={`fixed inset-0 z-[9999] h-screen w-screen bg-white flex flex-col items-center justify-center transition-opacity duration-500 ease-in-out ${
        fading ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      {/* Center content: Logo + Tagline */}
      <div className="relative flex flex-col items-center text-center px-4">
        {/* Soft #FEF1F7 radial glow directly behind the text */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-44 rounded-full bg-[#FEF1F7] blur-2xl pointer-events-none -z-10"
        />

        {/* Logo */}
        <h1 className="font-space-grotesk font-black italic text-6xl tracking-tight select-none">
          <span className="text-[#1a1a2e]">Kala</span>
          <span className="text-[#E72382]">Silver</span>
        </h1>

        {/* Tagline */}
        <p className="mt-3 text-gray-300 uppercase tracking-widest text-sm font-bold select-none font-space-grotesk">
          PREMIUM ARTISTRY
        </p>
      </div>

      {/* Bottom Indicator */}
      <div className="absolute bottom-12 flex items-center gap-2 text-[10px] text-gray-400 uppercase tracking-widest font-bold select-none font-space-grotesk">
        <span className="size-1.5 rounded-full bg-gray-300 animate-pulse" />
        <span>SECURE ENCRYPTED SESSION</span>
      </div>
    </div>
  );
}

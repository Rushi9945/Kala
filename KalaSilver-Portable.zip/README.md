# 💎 Kala Silver — Online Boutique Jewellery Store

A modern, high-performance Next.js 15 eCommerce web application crafted for **Kala Silver**, featuring handcrafted 925 sterling silver ear cuffs, rings, necklaces, bracelets, and gifts.

---

## 🌟 Key Features

- **Storefront & Catalog**:
  - Full-width hero showcase featuring artisan ear cuffs and curated designs.
  - Horizontal category carousel (Earrings, Rings, Necklaces, Bracelets, Anklets, Nose Pins, and Combos).
  - Gifts By Budget suite with interactive price thresholds (`< ₹999`, `₹999 – ₹2,499`, `₹2,500 – ₹5,999`, `₹6,000+`).
  - Responsive multi-row product grid with quick add-to-cart and wishlist toggles.
  - Instagram community showcase with lifestyle gallery.

- **Authentication & Security**:
  - Customer Portal with Google One-Click Sign-In (Firebase Auth).
  - 6-digit Mobile OTP authentication workflow.
  - Secure session persistence across browser tabs (`localStorage` & `cookieStore`).

- **Cart & Ordering**:
  - Slide-over Cart Drawer with real-time total computation and free delivery thresholds.
  - Checkout order creation connected to Firestore (`/api/orders`).
  - Resilient local fallback when offline or working in development mode.

- **SEO & Search Performance**:
  - XML Sitemap (`/sitemap.xml`) indexing all collections, categories, and budget routes.
  - Custom `robots.txt` directive generator.
  - Schema.org Organization and WebSite JSON-LD structured data.

---

## 🚀 Quick Setup & Run

### 1. Prerequisites
- [Node.js](https://nodejs.org/) (version 18.18 or higher recommended)
- `npm` or `pnpm`

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Production Build
```bash
npm run build
npm start
```

---

## 📁 Project Structure

```
├── app/
│   ├── api/
│   │   ├── auth/verify/      # JWT verification endpoint
│   │   ├── orders/           # Customer order creation (Firestore)
│   │   └── products/         # Catalog & budget tiers API
│   ├── category/[id]/        # Category page routes
│   ├── login/                # Google & OTP Login Portal
│   ├── shop/                 # Catalog & collection filtering
│   ├── layout.tsx            # Global brand shell, JSON-LD schema
│   ├── page.tsx              # Luxury Home Page
│   ├── sitemap.ts            # Dynamic XML Sitemap
│   └── robots.ts             # Robots crawler configuration
├── components/
│   ├── ui/                   # Button, Dialog, Dropdown, Carousel primitives
│   ├── BudgetSuite.tsx       # Gifts by budget 4-column cards
│   ├── CartDrawer.tsx        # Slide-over cart with live checkout
│   ├── CategoryCarousel.tsx  # Horizontal portrait collection cards
│   ├── Header.tsx            # Navigation, search, cart count & wishlist badge
│   ├── HeroSection.tsx       # Ear Cuffs brand slider
│   └── ProductGrid.tsx       # Signature products showcase
├── context/
│   ├── CartContext.tsx       # Global cart state & local persistence
│   ├── FirebaseContext.tsx   # Firebase Auth, Firestore & Storage providers
│   └── WishlistContext.tsx   # Wishlist items & heart toggles
├── lib/
│   ├── authService.ts        # Google OAuth & OTP handlers
│   ├── firestoreService.ts   # Firestore CRUD operations
│   ├── firebase.ts           # Firebase credentials config
│   └── pageMetadata.ts       # Per-route SEO metadata generators
└── public/                   # Static assets, fonts, icons
```

---

## 🎨 Brand Palette
- **Signature Pink**: `#E72382`
- **Soft Rose Background**: `#FEF1F7`
- **Typography**: Playfair Display (Serif Headlines) + Space Grotesk / Inter (Clean UI)

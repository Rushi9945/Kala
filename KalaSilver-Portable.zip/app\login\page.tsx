"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Phone,
  KeyRound,
  ShieldCheck,
  CircleCheck,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Lock,
} from "lucide-react";
import { useUser, useAuth } from "@/context/FirebaseContext";
import { Button } from "@/components/ui/button";
import {
  signInWithGoogle,
  checkRedirectResult,
  setAuthPersistence,
} from "@/lib/authService";

export default function LoginPage() {
  const router = useRouter();
  const user = useUser();
  const auth = useAuth();

  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [verifiedSuccess, setVerifiedSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    // Configure local persistence as default
    setAuthPersistence(true);

    // Check redirect return if applicable
    checkRedirectResult().then((user) => {
      if (user) {
        setVerifiedSuccess(true);
        setTimeout(() => router.push("/shop"), 1000);
      }
    });
  }, [router]);

  // If already authenticated
  useEffect(() => {
    if (user) {
      setVerifiedSuccess(true);
      const timer = setTimeout(() => router.push("/shop"), 800);
      return () => clearTimeout(timer);
    }
  }, [user, router]);

  const handleGoogleSignIn = async () => {
    setErrorMsg("");
    setIsGoogleLoading(true);
    try {
      const res = await signInWithGoogle();
      if (res.user) {
        setVerifiedSuccess(true);
        setTimeout(() => router.push("/shop"), 1000);
      } else if (res.error) {
        setErrorMsg(res.error);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || "Failed to sign in with Google");
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    if (phoneNumber.replace(/\D/g, "").length >= 10) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setStep("otp");
      }, 700);
    }
  };

  const handleOtpChange = (index: number, val: string) => {
    if (val.length > 1) val = val.slice(-1);
    const newOtp = [...otp];
    newOtp[index] = val;
    setOtp(newOtp);

    // Auto-advance
    if (val && index < 5) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    const entered = otp.join("");
    if (entered.length === 6) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setVerifiedSuccess(true);
        setTimeout(() => {
          router.push("/shop");
        }, 1200);
      }, 800);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center bg-gradient-to-b from-white via-[#fef7fa] to-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        {/* Card Container with smooth presence animation */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-2xl shadow-pink-900/5 border border-pink-100/70 relative overflow-hidden">
          {/* Subtle Pink Header Glow */}
          <div className="absolute -top-16 -right-16 w-36 h-36 bg-[#E72382]/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-[#E72382]/5 rounded-full blur-2xl pointer-events-none" />

          {/* Header Brand */}
          <div className="text-center mb-8">
            <Link
              href="/"
              className="inline-block text-2xl sm:text-3xl font-black tracking-widest text-black uppercase font-headline"
            >
              KALA<span className="text-[#E72382]">SILVER</span>
            </Link>
            <div className="w-12 h-1 bg-[#E72382] mx-auto mt-2.5 rounded-full" />
            <p className="text-xs uppercase tracking-widest text-gray-400 mt-3 font-semibold">
              Boutique Customer Portal
            </p>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-xs font-medium text-center">
              {errorMsg}
            </div>
          )}

          <AnimatePresence mode="wait">
            {verifiedSuccess ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="text-center py-6"
              >
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-500 mx-auto flex items-center justify-center mb-4 ring-8 ring-emerald-50/50">
                  <CircleCheck className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 font-headline">
                  Welcome to Kala Silver
                </h3>
                <p className="text-xs text-gray-500 mt-2">
                  Authentication verified. Redirecting to your curated collection...
                </p>
              </motion.div>
            ) : (
              <div className="space-y-6">
                {/* Google One-Click Auth */}
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isGoogleLoading}
                  className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-xs font-bold uppercase tracking-wider text-gray-700 shadow-sm transition-all hover:border-gray-300 active:scale-[0.98]"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  {isGoogleLoading ? "Connecting to Google..." : "Continue with Google"}
                </button>

                <div className="relative flex items-center justify-center">
                  <div className="border-t border-gray-200 w-full" />
                  <span className="bg-white px-3 text-[11px] font-bold tracking-widest text-gray-400 uppercase">
                    Or with mobile
                  </span>
                  <div className="border-t border-gray-200 w-full" />
                </div>

                {step === "phone" ? (
                  <motion.form
                    key="phone-step"
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 16 }}
                    transition={{ duration: 0.2 }}
                    onSubmit={handleSendOtp}
                    className="space-y-6"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Phone className="w-4 h-4 text-[#E72382]" />
                        <label
                          htmlFor="phone"
                          className="text-xs font-bold uppercase tracking-wider text-gray-700"
                        >
                          Mobile Verification
                        </label>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500">
                          +91
                        </span>
                        <input
                          id="phone"
                          type="tel"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          placeholder="98765 43210"
                          maxLength={12}
                          className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 text-sm font-semibold tracking-wide text-gray-900 focus:outline-none focus:border-[#E72382] focus:ring-2 focus:ring-[#E72382]/20 transition-all placeholder:text-gray-300"
                          required
                        />
                      </div>
                      <p className="text-[11px] text-gray-400 mt-2">
                        We will send a 6-digit one-time code to authenticate your account.
                      </p>
                    </div>

                    <Button
                      type="submit"
                      disabled={isLoading || phoneNumber.replace(/\D/g, "").length < 10}
                      className="w-full h-12 rounded-xl text-xs uppercase tracking-widest font-bold shadow-md shadow-pink-500/20"
                    >
                      {isLoading ? "Sending OTP..." : "Get OTP Access Code"}
                      {!isLoading && <ArrowRight className="w-4 h-4 ml-2" />}
                    </Button>
                  </motion.form>
                ) : (
                  <motion.form
                    key="otp-step"
                    initial={{ opacity: 0, x: 16 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -16 }}
                    transition={{ duration: 0.2 }}
                    onSubmit={handleVerifyOtp}
                    className="space-y-6"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <KeyRound className="w-4 h-4 text-[#E72382]" />
                          <label className="text-xs font-bold uppercase tracking-wider text-gray-700">
                            Enter 6-Digit OTP
                          </label>
                        </div>
                        <button
                          type="button"
                          onClick={() => setStep("phone")}
                          className="text-[11px] font-bold text-[#E72382] hover:underline flex items-center gap-1"
                        >
                          <ArrowLeft className="w-3 h-3" />
                          Edit
                        </button>
                      </div>
                      <p className="text-[11px] text-gray-500 mb-4">
                        Sent to +91 {phoneNumber}
                      </p>

                      {/* 6 OTP Inputs */}
                      <div className="flex items-center justify-between gap-2">
                        {otp.map((digit, i) => (
                          <input
                            key={i}
                            id={`otp-input-${i}`}
                            type="text"
                            inputMode="numeric"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => handleOtpChange(i, e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Backspace" && !digit && i > 0) {
                                document.getElementById(`otp-input-${i - 1}`)?.focus();
                              }
                            }}
                            className="w-11 h-13 text-center text-lg font-black rounded-xl border border-gray-200 text-gray-900 focus:outline-none focus:border-[#E72382] focus:ring-2 focus:ring-[#E72382]/20 transition-all"
                          />
                        ))}
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={isLoading || otp.join("").length < 6}
                      className="w-full h-12 rounded-xl text-xs uppercase tracking-widest font-bold shadow-md shadow-pink-500/20"
                    >
                      {isLoading ? "Verifying..." : "Verify & Sign In"}
                      {!isLoading && <Sparkles className="w-4 h-4 ml-2" />}
                    </Button>

                    <div className="text-center">
                      <button
                        type="button"
                        onClick={() => setOtp(["", "", "", "", "", ""])}
                        className="text-xs font-semibold text-gray-500 hover:text-[#E72382] transition-colors"
                      >
                        Didn&apos;t receive code? Resend
                      </button>
                    </div>
                  </motion.form>
                )}

                {/* Trust Seal */}
                <div className="pt-4 border-t border-gray-100 flex items-center justify-center gap-2 text-gray-400 text-[11px]">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>256-bit Encrypted & 92.5 Hallmark Secure</span>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { ArrowLeft, Sparkles, ShoppingBag } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center bg-white relative overflow-hidden">
      {/* Background Soft Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#FEF1F7] blur-[100px] rounded-full pointer-events-none -z-10" />

      {/* Decorative badge */}
      <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FEF1F7] text-[#E72382] text-xs font-bold uppercase tracking-widest border border-pink-100 mb-6">
        <Sparkles className="w-3.5 h-3.5" />
        <span>Piece Not Found</span>
      </div>

      <h1 className="text-6xl sm:text-8xl font-black italic tracking-tighter text-gray-900 font-headline mb-3">
        404
      </h1>

      <div className="w-16 h-1 bg-[#E72382] rounded-full mx-auto mb-6 shadow-[0_2px_12px_rgba(231,35,130,0.4)]" />

      <h2 className="text-xl sm:text-2xl font-bold text-gray-800 tracking-tight mb-2">
        This Treasure Has Moved
      </h2>

      <p className="text-sm text-gray-500 max-w-md mx-auto mb-8 leading-relaxed">
        The exquisite jewellery design or collection page you were looking for doesn&apos;t exist or has been relocated to our main gallery.
      </p>

      <div className="flex flex-wrap items-center justify-center gap-3">
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gray-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider transition-all shadow-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </Link>

        <Link
          href="/shop"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#E72382] hover:bg-[#d01b73] text-white text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-lg"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Explore All Collections</span>
        </Link>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

const slides = [
  {
    tagline: "New Collection 2026",
    headline: ["Timeless Beauty,", "Modern Craft"],
    sub: "Sterling silver and gold-plated jewellery, handcrafted for every occasion.",
    cta: { label: "Explore Collection", href: "/shop" },
    ctaSecondary: { label: "View Lookbook", href: "/lookbook" },
    bg: "from-rose-950 via-gray-950 to-gray-900",
    accent: "from-magenta-500 to-pink-400",
    floatEmoji: ["💍", "✨", "💎", "🌸", "👑"],
  },
  {
    tagline: "Gifts by Budget",
    headline: ["Perfect Gift,", "Every Budget"],
    sub: "From ₹999 to luxury heirlooms — find a jewellery gift they'll treasure forever.",
    cta: { label: "Shop Gifts", href: "/shop" },
    ctaSecondary: { label: "Get Advice", href: "/contact" },
    bg: "from-violet-950 via-gray-950 to-gray-900",
    accent: "from-violet-400 to-fuchsia-400",
    floatEmoji: ["🎀", "💝", "✨", "🪬", "🌟"],
  },
];

export default function HeroBanner() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [visible, setVisible] = useState(false);
  const [transitioning, setTransitioning] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTransitioning(true);
      setTimeout(() => {
        setActiveSlide((prev) => (prev + 1) % slides.length);
        setTransitioning(false);
      }, 400);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const slide = slides[activeSlide];

  return (
    <section
      className={`relative min-h-[82vh] flex items-center overflow-hidden bg-gradient-to-br ${slide.bg} transition-all duration-700`}
    >
      {/* Background texture */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `radial-gradient(circle at 1px 1px, white 1px, transparent 0)`,
        backgroundSize: "32px 32px",
      }} />

      {/* Glow blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-magenta-600/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 rounded-full bg-pink-600/10 blur-3xl pointer-events-none" />

      {/* Floating emojis (decorative) */}
      {slide.floatEmoji.map((emoji, i) => (
        <div
          key={`${activeSlide}-${i}`}
          className="absolute text-2xl select-none pointer-events-none opacity-20"
          style={{
            top: `${15 + i * 15}%`,
            right: `${8 + i * 5}%`,
            animation: `float${i % 2 === 0 ? "Up" : "Down"} ${3 + i * 0.5}s ease-in-out infinite alternate`,
          }}
        >
          {emoji}
        </div>
      ))}

      {/* Main content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div
          className={`max-w-2xl transition-all duration-500 ${
            transitioning
              ? "opacity-0 translate-y-4"
              : visible
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-8"
          }`}
        >
          {/* Tagline chip */}
          <div className={`inline-flex items-center gap-2 mb-6 px-4 py-1.5 rounded-full bg-gradient-to-r ${slide.accent} bg-opacity-20 border border-white/10`}>
            <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            <span className="text-white/90 text-xs font-semibold tracking-[0.2em] uppercase">
              {slide.tagline}
            </span>
          </div>

          {/* Headline */}
          <h1
            className="font-serif font-bold text-white leading-[1.1] mb-5"
            style={{ fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
          >
            {slide.headline.map((line, i) => (
              <span key={i} className="block">
                {i === 1 ? (
                  <span
                    style={{
                      background: `linear-gradient(135deg, #ff2278, #e8005a)`,
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                      backgroundClip: "text",
                    }}
                  >
                    {line}
                  </span>
                ) : (
                  line
                )}
              </span>
            ))}
          </h1>

          {/* Subtext */}
          <p className="text-gray-300 text-base md:text-lg leading-relaxed mb-8 max-w-lg">
            {slide.sub}
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap gap-4">
            <Link href={slide.cta.href} className="btn-primary text-sm py-3.5 px-7">
              {slide.cta.label}
            </Link>
            <Link
              href={slide.ctaSecondary.href}
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/20 text-white text-sm font-medium hover:bg-white/10 transition-all duration-200"
            >
              {slide.ctaSecondary.label}
            </Link>
          </div>

          {/* Trust row */}
          <div className="flex flex-wrap gap-6 mt-10">
            {[
              { icon: "🔒", label: "SSL Secured" },
              { icon: "💎", label: "BIS Hallmarked" },
              { icon: "↩️", label: "Easy Returns" },
              { icon: "🚚", label: "Free Shipping" },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-2 text-gray-400 text-xs">
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setActiveSlide(i)}
            className={`rounded-full transition-all duration-300 ${
              i === activeSlide
                ? "w-8 h-2 bg-magenta-500"
                : "w-2 h-2 bg-white/30 hover:bg-white/50"
            }`}
            aria-label={`Go to slide ${i + 1}`}
          />
        ))}
      </div>

      <style jsx>{`
        @keyframes floatUp {
          from { transform: translateY(0px) rotate(-5deg); }
          to { transform: translateY(-16px) rotate(5deg); }
        }
        @keyframes floatDown {
          from { transform: translateY(0px) rotate(3deg); }
          to { transform: translateY(12px) rotate(-3deg); }
        }
      `}</style>
    </section>
  );
}

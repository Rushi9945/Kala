import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  onSnapshot,
  DocumentData,
  QueryConstraint
} from "firebase/firestore";
import { initFirebase } from "./firebase";

export interface ProductItem {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  discount?: string;
  category: string;
  rating?: number;
  reviews?: number;
  image: string;
  isBestseller?: boolean;
  isNew?: boolean;
  metal?: string;
  inStock?: boolean;
  description?: string;
  tags?: string[];
  createdAt?: any;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export interface OrderRecord {
  id?: string;
  userId?: string;
  customerName: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  items: OrderItem[];
  totalAmount: number;
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";
  paymentMethod: "cod" | "upi" | "card";
  createdAt?: any;
}

// Fallback seed catalog matching Kala Silver's luxury inventory
export const FALLBACK_PRODUCTS: ProductItem[] = [
  {
    id: "ks-prod-001",
    name: "Classic Sparkle 925 Silver Studs",
    price: 899,
    originalPrice: 1299,
    discount: "30% OFF",
    category: "earrings",
    rating: 4.9,
    reviews: 142,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=600&q=80",
    isBestseller: true,
    metal: "925 Sterling Silver",
    inStock: true,
    description: "Handcrafted 925 Sterling Silver solitaires cut for perpetual fire and radiance.",
    tags: ["earrings", "studs", "bestseller", "under-999"]
  },
  {
    id: "ks-prod-002",
    name: "Petite Dewdrop Zirconia Ring",
    price: 1499,
    originalPrice: 1999,
    discount: "25% OFF",
    category: "rings",
    rating: 4.8,
    reviews: 98,
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=600&q=80",
    isNew: true,
    metal: "925 Sterling Silver",
    inStock: true,
    description: "Graceful band adorned with pavé stones and a teardrop accent.",
    tags: ["rings", "trending", "under-2499"]
  },
  {
    id: "ks-prod-003",
    name: "Celeste Moon & Star Silver Necklace",
    price: 2899,
    originalPrice: 3499,
    discount: "17% OFF",
    category: "necklaces",
    rating: 5.0,
    reviews: 76,
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80",
    isBestseller: true,
    metal: "925 Sterling Silver",
    inStock: true,
    description: "Celestial pendant suspended from an Italian diamond-cut link chain.",
    tags: ["necklaces", "celestial", "luxury"]
  },
  {
    id: "ks-prod-004",
    name: "Luxe Tennis Bracelet with Rhodium Finish",
    price: 4999,
    originalPrice: 6499,
    discount: "23% OFF",
    category: "bracelets",
    rating: 4.9,
    reviews: 112,
    image: "https://images.unsplash.com/photo-1611591475836-8a02a0a22a31?auto=format&fit=crop&w=600&q=80",
    isBestseller: true,
    metal: "925 Sterling Silver Rhodium Coated",
    inStock: true,
    description: "Continuous line of faceted cubic zirconia crafted in anti-tarnish pure silver.",
    tags: ["bracelets", "tennis", "prestige"]
  },
  {
    id: "ks-prod-005",
    name: "Minimalist Infinity Ear Cuffs",
    price: 799,
    originalPrice: 1199,
    discount: "33% OFF",
    category: "earrings",
    rating: 4.7,
    reviews: 64,
    image: "https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=600&q=80",
    isNew: true,
    metal: "925 Sterling Silver",
    inStock: true,
    description: "No piercing required clip-on huggie cuff designed for contemporary styling.",
    tags: ["earrings", "ear-cuffs", "under-999"]
  },
  {
    id: "ks-prod-006",
    name: "Heritage Royal Filigree Anklet Pair",
    price: 2199,
    originalPrice: 2899,
    discount: "24% OFF",
    category: "anklets",
    rating: 4.8,
    reviews: 53,
    image: "https://images.unsplash.com/photo-1602751584552-8ba73aad10e1?auto=format&fit=crop&w=600&q=80",
    metal: "925 Sterling Silver",
    inStock: true,
    description: "Delicate ghungroo bells and intricately woven pure silver anklets.",
    tags: ["anklets", "heritage", "under-2499"]
  }
];

// Helper to access firestore instance
function getDb() {
  const { firestore } = initFirebase();
  return firestore;
}

/**
 * Fetch products from Firestore with fallback to cached/sample catalog
 */
export async function getProducts(options?: {
  category?: string;
  maxPrice?: number;
  minPrice?: number;
  limitCount?: number;
}): Promise<ProductItem[]> {
  try {
    const db = getDb();
    if (!db) {
      return filterFallback(options);
    }

    const productsRef = collection(db, "products");
    const constraints: QueryConstraint[] = [];

    if (options?.category && options.category !== "all") {
      constraints.push(where("category", "==", options.category));
    }
    if (options?.limitCount) {
      constraints.push(limit(options.limitCount));
    }

    const q = query(productsRef, ...constraints);
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      return filterFallback(options);
    }

    const products: ProductItem[] = [];
    querySnapshot.forEach((docSnap) => {
      products.push({ id: docSnap.id, ...(docSnap.data() as Omit<ProductItem, "id">) });
    });

    // Apply price filtering client side if not indexed
    let results = products;
    if (options?.minPrice !== undefined) {
      results = results.filter(p => p.price >= (options.minPrice ?? 0));
    }
    if (options?.maxPrice !== undefined) {
      results = results.filter(p => p.price <= (options.maxPrice ?? Infinity));
    }

    return results;
  } catch (err) {
    console.warn("Firestore fetch notice: Falling back to local data", err);
    return filterFallback(options);
  }
}

function filterFallback(options?: {
  category?: string;
  maxPrice?: number;
  minPrice?: number;
  limitCount?: number;
}): ProductItem[] {
  let list = [...FALLBACK_PRODUCTS];
  if (options?.category && options.category !== "all") {
    list = list.filter(p => p.category.toLowerCase() === options.category?.toLowerCase());
  }
  if (options?.minPrice !== undefined) {
    list = list.filter(p => p.price >= (options.minPrice ?? 0));
  }
  if (options?.maxPrice !== undefined) {
    list = list.filter(p => p.price <= (options.maxPrice ?? Infinity));
  }
  if (options?.limitCount) {
    list = list.slice(0, options.limitCount);
  }
  return list;
}

/**
 * Create a customer order record in Firestore
 */
export async function createFirestoreOrder(order: OrderRecord): Promise<{ success: boolean; orderId: string }> {
  try {
    const db = getDb();
    const orderData = {
      ...order,
      status: order.status || "pending",
      createdAt: serverTimestamp()
    };

    if (db) {
      const docRef = await addDoc(collection(db, "orders"), orderData);
      return { success: true, orderId: docRef.id };
    } else {
      const generatedId = `KS-ORD-${Date.now().toString(36).toUpperCase()}`;
      return { success: true, orderId: generatedId };
    }
  } catch (error: any) {
    console.error("Failed to persist order in Firestore:", error);
    // Graceful optimistic fallback for customer experience
    const fallbackId = `KS-LOCAL-${Date.now().toString(36).toUpperCase()}`;
    return { success: true, orderId: fallbackId };
  }
}

/**
 * Real-time listener for customer orders
 */
export function subscribeToUserOrders(userId: string, onUpdate: (orders: OrderRecord[]) => void) {
  const db = getDb();
  if (!db) {
    onUpdate([]);
    return () => {};
  }

  const q = query(
    collection(db, "orders"),
    where("userId", "==", userId),
    orderBy("createdAt", "desc")
  );

  return onSnapshot(q, (snapshot) => {
    const orders: OrderRecord[] = [];
    snapshot.forEach((docSnap) => {
      orders.push({ id: docSnap.id, ...(docSnap.data() as any) });
    });
    onUpdate(orders);
  }, (err) => {
    console.warn("Order listener notice:", err);
  });
}

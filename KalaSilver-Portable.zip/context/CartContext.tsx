"use client";

import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { useUser, useFirestore } from "./FirebaseContext";

export interface CartItem {
  id: string;
  name: string;
  title?: string;
  price: number;
  salePrice?: number;
  image: string;
  quantity: number;
  customName?: string;
}

interface CartContextType {
  items: CartItem[];
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  setIsCartOpen: (open: boolean) => void;
  addItem: (item: Omit<CartItem, "quantity">, quantity?: number, customName?: string) => void;
  addToCart: (item: any, quantity?: number, customName?: string) => void;
  removeItem: (id: string) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, deltaOrQuantity: number) => void;
  clearCart: () => void;
  totalCount: number;
  subtotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  const user = useUser();
  const firestore = useFirestore();
  const isInitialLoad = useRef(true);

  // 1. Initial Load: Firestore (if logged in) or LocalStorage (temp_cart)
  useEffect(() => {
    async function loadCart() {
      isInitialLoad.current = true;
      let initialItems: CartItem[] = [];

      if (user && firestore) {
        try {
          const cartDocRef = doc(firestore, "carts", user.uid);
          const snap = await getDoc(cartDocRef);
          if (snap.exists()) {
            initialItems = snap.data().items || [];
          }

          // Merge guest cart if user logged in
          const tempCartStr = localStorage.getItem("temp_cart");
          const tempItems: CartItem[] = tempCartStr ? JSON.parse(tempCartStr) : [];
          if (tempItems.length > 0) {
            const merged = [...initialItems];
            tempItems.forEach((tempItem) => {
              const idx = merged.findIndex(
                (m) => m.id === tempItem.id && m.customName === tempItem.customName
              );
              if (idx > -1) {
                merged[idx].quantity += tempItem.quantity;
              } else {
                merged.push(tempItem);
              }
            });
            initialItems = merged;
            localStorage.removeItem("temp_cart");
            const sanitizedInitial = initialItems.map((item) => {
              const entry: Record<string, any> = {
                id: item.id || "",
                name: item.name || item.title || "",
                price: Number(item.price) || 0,
                image: item.image || "",
                quantity: Number(item.quantity) || 1,
              };
              if (item.salePrice !== undefined && item.salePrice !== null) {
                entry.salePrice = Number(item.salePrice);
              }
              if (item.customName !== undefined && item.customName !== null) {
                entry.customName = String(item.customName);
              }
              return entry;
            });

            await setDoc(
              cartDocRef,
              { items: sanitizedInitial, updatedAt: new Date() },
              { merge: true }
            );
          }
        } catch (err) {
          console.error("Error loading cart from Firestore:", err);
        }
      } else {
        const local = localStorage.getItem("temp_cart");
        if (local) {
          try {
            initialItems = JSON.parse(local);
          } catch (e) {
            initialItems = [];
          }
        }
      }

      setItems(initialItems);
      setIsLoaded(true);
      setTimeout(() => {
        isInitialLoad.current = false;
      }, 150);
    }

    loadCart();
  }, [user, firestore]);

  // 2. Sync changes back to Firestore or localStorage
  useEffect(() => {
    if (!isLoaded || isInitialLoad.current) return;

    if (user && firestore) {
      const cartDocRef = doc(firestore, "carts", user.uid);
      const sanitizedItems = items.map((item) => {
        const entry: Record<string, any> = {
          id: item.id || "",
          name: item.name || item.title || "",
          price: Number(item.price) || 0,
          image: item.image || "",
          quantity: Number(item.quantity) || 1,
        };
        if (item.salePrice !== undefined && item.salePrice !== null) {
          entry.salePrice = Number(item.salePrice);
        }
        if (item.customName !== undefined && item.customName !== null) {
          entry.customName = String(item.customName);
        }
        return entry;
      });

      setDoc(
        cartDocRef,
        {
          items: sanitizedItems,
          updatedAt: new Date(),
        },
        { merge: true }
      ).catch((err) => console.error("Firestore cart sync error:", err));
    } else {
      localStorage.setItem("temp_cart", JSON.stringify(items));
    }
  }, [items, user, firestore, isLoaded]);

  const openCart = () => setIsOpen(true);
  const closeCart = () => setIsOpen(false);

  const addItem = (
    product: Omit<CartItem, "quantity">,
    quantity = 1,
    customName?: string
  ) => {
    setItems((prev) => {
      const existing = prev.find(
        (item) => item.id === product.id && item.customName === customName
      );
      if (existing) {
        return prev.map((item) =>
          item.id === product.id && item.customName === customName
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          ...product,
          name: product.name || product.title || "",
          quantity,
          customName,
        },
      ];
    });
    setIsOpen(true);
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const updateQuantity = (id: string, deltaOrQuantity: number) => {
    setItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            // Check if delta (relative +-1) or direct absolute number
            const newQty =
              Math.abs(deltaOrQuantity) === 1
                ? item.quantity + deltaOrQuantity
                : deltaOrQuantity;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => {
    setItems([]);
    localStorage.removeItem("temp_cart");
    if (user && firestore) {
      setDoc(doc(firestore, "carts", user.uid), { items: [], updatedAt: new Date() }).catch(
        () => {}
      );
    }
  };

  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce(
    (sum, item) => sum + (item.salePrice || item.price) * item.quantity,
    0
  );

  return (
    <CartContext.Provider
      value={{
        items,
        isOpen,
        openCart,
        closeCart,
        setIsCartOpen: setIsOpen,
        addItem,
        addToCart: addItem,
        removeItem,
        removeFromCart: removeItem,
        updateQuantity,
        clearCart,
        totalCount,
        subtotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}

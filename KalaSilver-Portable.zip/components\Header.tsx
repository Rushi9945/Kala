"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import {
  Search,
  User,
  Heart,
  ShoppingBag,
  Menu,
  X,
} from "lucide-react";
import { useCart } from "@/context/CartContext";

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Contact Us", href: "/contact" },
  { label: "Shop By Category", href: "/shop" },
];

export default function Header() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { openCart, totalCount } = useCart();
  const [wishlistCount] = useState(3);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-md"
          : "bg-white shadow-sm"
      }`}
    >
      {/* ── Top Announcement Bar ── */}
      <div className="bg-[#E72382] text-white text-center text-xs py-2 px-4 font-bold tracking-wide">
        ✦ Free express shipping on orders above ₹2,999 &nbsp;|&nbsp; 100% 925 Pure Silver ✦
      </div>

      {/* ── Main Header ── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0 group">
            <span className="font-space-grotesk font-black italic text-2xl tracking-tight">
              <span className="text-gray-900">KALA</span>
              <span className="text-[#E72382]">SILVER</span>
            </span>
          </Link>

          {/* Desktop Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-6">
            <div className="relative w-full group">
              <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-gray-400 group-focus-within:text-[#E72382] transition-colors">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="search"
                placeholder="Search earrings, bracelets, rings…"
                className="w-full pl-10 pr-4 py-2 text-xs rounded-full border border-gray-200 bg-gray-50 text-gray-800 placeholder-gray-400 outline-none focus:border-[#E72382] focus:bg-white focus:ring-2 focus:ring-pink-100 transition-all"
              />
            </div>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Search Toggle on Mobile */}
            <button
              aria-label="Search"
              className="md:hidden p-2 text-gray-600 hover:text-[#E72382] hover:bg-pink-50 rounded-full transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Profile */}
            <Link
              href="/profile"
              className="p-2 text-gray-600 hover:text-[#E72382] hover:bg-pink-50 rounded-full transition-colors hidden sm:flex"
              aria-label="My Account"
            >
              <User className="w-5 h-5" />
            </Link>

            {/* Wishlist */}
            <Link
              href="/wishlist"
              className="relative p-2 text-gray-600 hover:text-[#E72382] hover:bg-pink-50 rounded-full transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#E72382] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Shopping Bag / Cart Drawer Button */}
            <button
              onClick={openCart}
              className="relative p-2 text-gray-600 hover:text-[#E72382] hover:bg-pink-50 rounded-full transition-colors"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {totalCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#E72382] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {totalCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-gray-600 hover:text-[#E72382] hover:bg-pink-50 rounded-full transition-colors ml-1"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Toggle menu"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* ── Desktop Category Navigation Links ── */}
      <nav className="hidden md:block border-t border-gray-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ul className="flex items-center justify-center gap-8 py-2.5">
            {[
              { label: "Home", href: "/" },
              { label: "Earrings", href: "/category/earrings" },
              { label: "Bracelets", href: "/category/bracelets" },
              { label: "Men's Studs", href: "/category/mens-studs" },
              { label: "Neckpieces", href: "/category/necklaces" },
              { label: "All Treasures", href: "/shop" },
            ].map((link) => {
              const isActive = pathname === link.href;
              return (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className={`text-xs font-bold uppercase tracking-wider transition-colors py-1 ${
                      isActive
                        ? "text-[#E72382] border-b-2 border-[#E72382]"
                        : "text-gray-600 hover:text-[#E72382]"
                    }`}
                  >
                    {link.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* ── Mobile Navigation Drawer ── */}
      {menuOpen && (
        <div className="md:hidden border-t border-gray-100 bg-white px-4 pt-3 pb-6 space-y-2 shadow-lg animate-in slide-in-from-top-2">
          {[
            { label: "Home", href: "/" },
            { label: "Earrings", href: "/category/earrings" },
            { label: "Bracelets", href: "/category/bracelets" },
            { label: "Men's Studs", href: "/category/mens-studs" },
            { label: "Neckpieces", href: "/category/necklaces" },
            { label: "All Treasures", href: "/shop" },
          ].map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="block px-3 py-2 text-sm font-bold text-gray-800 hover:text-[#E72382] hover:bg-pink-50 rounded-lg transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}

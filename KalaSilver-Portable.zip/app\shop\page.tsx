import type { Metadata } from "next";
import { SHOP_METADATA } from "@/lib/pageMetadata";
import CategoryPageClient from "@/components/CategoryPageClient";

export const metadata: Metadata = SHOP_METADATA;

interface ShopPageProps {
  searchParams: Promise<{
    maxPrice?: string;
  }>;
}

export default async function ShopPage({ searchParams }: ShopPageProps) {
  const { maxPrice } = await searchParams;
  const parsedMaxPrice = maxPrice ? parseInt(maxPrice, 10) : undefined;

  return (
    <CategoryPageClient
      categoryId="all"
      initialMaxPrice={parsedMaxPrice}
    />
  );
}

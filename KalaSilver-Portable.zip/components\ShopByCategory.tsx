"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface Category {
  id: string;
  name: string;
  slug: string;
  emoji: string;
  itemCount: number;
  gradient: string;
  accentColor: string;
  badge?: string;
}

// ── SVG Arrow ─────────────────────────────────────────────────────────────────
const ArrowRightIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={2}
    stroke="currentColor"
    className="w-4 h-4"
  >
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
  </svg>
);

// ── Category Card ─────────────────────────────────────────────────────────────
function CategoryCard({
  category,
  index,
}: {
  category: Category;
  index: number;
}) {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setVisible(true), index * 80);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ease-out ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
    >
      <Link href={`/shop/${category.slug}`} className="group block">
        <div className="relative overflow-hidden rounded-2xl card-hover cursor-pointer">
          {/* Visual tile */}
          <div
            className={`h-52 md:h-60 flex flex-col items-center justify-center gap-3 ${category.gradient} relative`}
          >
            {/* Badge */}
            {category.badge && (
              <span className="absolute top-3 right-3 bg-magenta-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full tracking-wide uppercase">
                {category.badge}
              </span>
            )}

            {/* Decorative ring behind emoji */}
            <div
              className="w-24 h-24 rounded-full flex items-center justify-center text-5xl"
              style={{
                background: "rgba(255,255,255,0.18)",
                boxShadow: `0 0 0 12px rgba(255,255,255,0.08), 0 0 0 24px rgba(255,255,255,0.04)`,
                backdropFilter: "blur(8px)",
              }}
            >
              {category.emoji}
            </div>

            {/* Hover overlay */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />

            {/* Arrow button on hover */}
            <div className="absolute bottom-4 right-4 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center text-gray-700 opacity-0 group-hover:opacity-100 translate-x-2 group-hover:translate-x-0 transition-all duration-300 shadow-md">
              <ArrowRightIcon />
            </div>
          </div>

          {/* Info */}
          <div className="bg-white pt-3.5 pb-4 px-4 border border-gray-100 border-t-0 rounded-b-2xl">
            <h3 className="font-serif font-semibold text-gray-900 text-base group-hover:text-magenta-600 transition-colors duration-200">
              {category.name}
            </h3>
            <p className="text-xs text-gray-400 mt-0.5 font-medium">
              {category.itemCount} pieces
            </p>
          </div>
        </div>
      </Link>
    </div>
  );
}

// ── Main Section ──────────────────────────────────────────────────────────────
interface ShopByCategoryProps {
  categories: Category[];
}

export default function ShopByCategory({ categories }: ShopByCategoryProps) {
  return (
    <section className="py-16 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
          <div>
            <p className="section-subtitle">Collections</p>
            <h2 className="section-title">Shop By Category</h2>
            <p className="mt-3 text-gray-500 text-sm max-w-md leading-relaxed">
              Explore our curated range of sterling silver and gold-plated
              jewellery, crafted for every occasion.
            </p>
          </div>
          <Link
            href="/shop"
            className="btn-outline self-start md:self-auto shrink-0"
          >
            View All Categories
          </Link>
        </div>

        {/* Category grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-5">
          {categories.map((cat, i) => (
            <CategoryCard key={cat.id} category={cat} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

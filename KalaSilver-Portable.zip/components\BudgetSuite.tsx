"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, Gift, Sparkles, Gem } from "lucide-react";

export default function BudgetSuite() {
  return (
    <section className="py-14 bg-neutral-50/70 border-t border-b border-gray-100" id="budget">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[11px] font-semibold tracking-[0.25em] text-gray-400 uppercase">
            THE GIFTING SUITE
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight mt-1">
            Gifts by <span className="text-[#E72382] italic font-serif">Budget</span>
          </h2>
          <p className="text-xs sm:text-sm font-normal text-gray-500 mt-2">
            Thoughtfully curated silver treasures, categorized by investment value to help you find
            the perfect token of affection.
          </p>
          <div className="w-12 h-[3px] bg-[#E72382] rounded-full mx-auto my-3" />
        </div>

        {/* Budget Cards 4-Column Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Budget Tier 1 */}
          <Link
            href="/shop?max=1997"
            className="rounded-2xl p-6 text-center shadow-sm hover:shadow-xl transition-all cursor-pointer flex flex-col items-center justify-center relative overflow-hidden group border border-[#ffe3ec] bg-gradient-to-b from-[#fff2f6] to-white"
          >
            <div className="w-12 h-12 rounded-full bg-pink-100 text-[#E72382] flex items-center justify-center text-xl mb-3 shadow-inner group-hover:scale-110 transition-transform">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <span className="text-[11px] uppercase tracking-widest font-semibold text-gray-400">
              GIFTS UNDER
            </span>
            <div className="text-3xl font-extrabold text-neutral-900 tracking-tight mt-1">
              ₹1997
            </div>
          </Link>

          {/* Budget Tier 2 */}
          <Link
            href="/shop?max=2999"
            className="rounded-2xl p-6 text-center shadow-sm hover:shadow-xl transition-all cursor-pointer flex flex-col items-center justify-center relative overflow-hidden group border border-[#ebdfff] bg-gradient-to-b from-[#f7f1ff] to-white"
          >
            <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xl mb-3 shadow-inner group-hover:scale-110 transition-transform">
              <Gift className="w-5 h-5" />
            </div>
            <span className="text-[11px] uppercase tracking-widest font-semibold text-gray-400">
              GIFTS UNDER
            </span>
            <div className="text-3xl font-extrabold text-neutral-900 tracking-tight mt-1">
              ₹2999
            </div>
          </Link>

          {/* Budget Tier 3 */}
          <Link
            href="/shop?max=3999"
            className="rounded-2xl p-6 text-center shadow-sm hover:shadow-xl transition-all cursor-pointer flex flex-col items-center justify-center relative overflow-hidden group border border-[#f9edd4] bg-gradient-to-b from-[#fffbf0] to-white"
          >
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center text-xl mb-3 shadow-inner group-hover:scale-110 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-[11px] uppercase tracking-widest font-semibold text-gray-400">
              GIFTS UNDER
            </span>
            <div className="text-3xl font-extrabold text-neutral-900 tracking-tight mt-1">
              ₹3999
            </div>
          </Link>

          {/* Budget Tier 4: Premium */}
          <Link
            href="/shop?tier=premium"
            className="rounded-2xl p-6 text-center shadow-sm hover:shadow-xl transition-all cursor-pointer flex flex-col items-center justify-center relative overflow-hidden group border border-[#e1ecfd] bg-gradient-to-b from-[#f2f7ff] to-white"
          >
            <div className="w-12 h-12 rounded-full bg-sky-100 text-sky-600 flex items-center justify-center text-xl mb-3 shadow-inner group-hover:scale-110 transition-transform">
              <Gem className="w-5 h-5" />
            </div>
            <span className="text-[11px] uppercase tracking-widest font-semibold text-gray-400">
              LUXURY RANGE
            </span>
            <div className="text-3xl font-extrabold text-neutral-900 tracking-tight mt-1">
              Premium
            </div>
          </Link>
        </div>

        {/* Social Proof Micro Banner */}
        <div className="mt-8 flex items-center justify-center space-x-3 text-xs font-semibold text-gray-500 tracking-wider">
          <div className="flex -space-x-2">
            <div className="relative h-6 w-6 rounded-full overflow-hidden ring-2 ring-white">
              <Image
                alt="Customer avatar 1"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuA8HchY2tIRGMtFS1JO_oJFUWMeAwAJbRAHAEFrj0sBx2tb1rfTqhf385jUx5SsFIYAAHkb8oh9K5blSel5kmpqHWPFBYBhduLVilulc1MY7Cqk3d7kZ1U57E7HDztT1Xcv00g2M0vgZjmQ1nSnXdjjdZihQYhvuoY1UElitiW9Ijw2xo4Oeu-cr4SoSQbbZRPgxN9bjKJqyvisZ_JYqMS0QtGlHiJFHsb-XyqnVQ"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative h-6 w-6 rounded-full overflow-hidden ring-2 ring-white">
              <Image
                alt="Customer avatar 2"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuA9HnPHHGSp-jUzrwgXoHVPoqvFxN4DLeYUXYMpxkUhXlb21z9WCZixXsZC5CoTOqs8gf3bVH02l0QrDxv8FaaqOChPdjntBBPlGODJBibYz2bAuxElCMH_Ao7FXGHyrYlVKG7VWOmGD-e8bJJEL7o-38INyzsT6_ZYDv8HoOn5AhZU9VFJyfRTA8btj2slDsSwTSbvualPLfE80RGQdVUct2nsuVdlY6DaP9YJ_g"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative h-6 w-6 rounded-full overflow-hidden ring-2 ring-white">
              <Image
                alt="Customer avatar 3"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDQbgfECD9wkVp-YmWLELaxjXTHfk-UeCLdpCMptdYs17mM5uu2Vfd2esLTDZv2EfjtN6N0bPrAnLoBGnmPM74kFJTNbDuLQcDGg_JeprGig6CxqlbbuwA-nOPldvG5IkxGSa5iQEJRCBWGNreUSXKl04t-0lT1el-M7PMoIFLu49C1OjtF6NbPXPRrErUl-iqr4EdiE-tqtEHB5pGoDwSL5Re7Kat6-X9ehlebLg"
                fill
                className="object-cover"
              />
            </div>
          </div>
          <span className="text-[11px] uppercase text-gray-600 font-bold">
            <span className="text-[#E72382]">50+</span> SILVER GIFTS DELIVERED TODAY
          </span>
        </div>
      </div>
    </section>
  );
}

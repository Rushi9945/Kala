"use client";

import React, { useEffect } from "react";
import Image from "next/image";
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  Info,
  Wallet,
  X,
  ArrowRight,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useCart } from "@/context/CartContext";

export default function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, subtotal, totalCount } =
    useCart();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[999] flex justify-end">
          {/* Backdrop with spring fade */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={closeCart}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Drawer Container with Framer-Motion physics slide */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#FEF1F7] text-[#E72382] flex items-center justify-center">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-black italic tracking-tight font-headline text-gray-900">
                    Your Bag
                  </h2>
                  <p className="text-xs text-gray-500 font-medium">
                    {totalCount} {totalCount === 1 ? "treasure" : "treasures"} selected
                  </p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={closeCart}
                aria-label="Close cart"
                className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>

            {/* Free Shipping Alert banner */}
            <div className="bg-[#FEF1F7] px-4 py-2.5 flex items-center gap-2 text-xs text-[#E72382] font-semibold border-b border-pink-100">
              <Info className="w-4 h-4 shrink-0" />
              <span>
                {subtotal >= 2999
                  ? "🎉 You've unlocked FREE Express Shipping!"
                  : `Add ₹${(2999 - subtotal).toLocaleString()} more for FREE Express Shipping`}
              </span>
            </div>

            {/* Item List with AnimatePresence layout animations */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
              {items.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="h-full flex flex-col items-center justify-center text-center py-16"
                >
                  <div className="w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center text-gray-300 mb-4">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h3 className="text-base font-bold text-gray-800 mb-1">
                    Your bag is empty
                  </h3>
                  <p className="text-xs text-gray-400 max-w-xs mb-6">
                    Explore our pure 925 sterling silver treasures and add your favorite pieces.
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={closeCart}
                    className="px-6 py-2.5 bg-[#E72382] text-white text-xs font-bold uppercase tracking-wider rounded-full hover:bg-[#d01b73] transition-colors"
                  >
                    Start Shopping
                  </motion.button>
                </motion.div>
              ) : (
                <AnimatePresence initial={false}>
                  {items.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: 50, transition: { duration: 0.2 } }}
                      className="flex items-center gap-3.5 p-3 rounded-xl border border-gray-100 bg-white hover:border-pink-100 transition-all shadow-sm"
                    >
                      {/* Thumbnail */}
                      <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-gray-50 shrink-0">
                        <Image
                          src={item.image}
                          alt={item.title || "Jewellery piece"}
                          fill
                          className="object-cover"
                        />
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 uppercase tracking-tight line-clamp-1">
                          {item.title}
                        </h4>
                        <p className="text-xs font-black text-[#E72382] mt-0.5">
                          ₹{item.price.toLocaleString()}
                        </p>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center border border-gray-200 rounded-md bg-gray-50">
                            <motion.button
                              whileTap={{ scale: 0.85 }}
                              onClick={() => updateQuantity(item.id, -1)}
                              aria-label="Decrease quantity"
                              className="px-2 py-1 text-gray-500 hover:text-black transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </motion.button>
                            <span className="px-2 text-xs font-bold text-gray-800">
                              {item.quantity}
                            </span>
                            <motion.button
                              whileTap={{ scale: 0.85 }}
                              onClick={() => updateQuantity(item.id, 1)}
                              aria-label="Increase quantity"
                              className="px-2 py-1 text-gray-500 hover:text-black transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </motion.button>
                          </div>
                        </div>
                      </div>

                      {/* Remove button */}
                      <motion.button
                        whileHover={{ scale: 1.15 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => removeItem(item.id)}
                        aria-label="Remove item"
                        className="p-2 text-gray-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </motion.button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              )}
            </div>

            {/* Footer / Checkout */}
            {items.length > 0 && (
              <div className="p-4 sm:p-5 border-t border-gray-100 bg-gray-50/50 space-y-3">
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-gray-500">
                    <span>Subtotal</span>
                    <span className="font-semibold text-gray-800">
                      ₹{subtotal.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-gray-500">
                    <span>Estimated Shipping</span>
                    <span className="font-semibold text-emerald-600">
                      {subtotal >= 2999 ? "FREE" : "₹99"}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-gray-900 pt-2 border-t border-gray-200">
                    <span>Total Amount</span>
                    <span className="text-[#E72382]">
                      ₹{(subtotal >= 2999 ? subtotal : subtotal + 99).toLocaleString()}
                    </span>
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => alert("Proceeding to Secure Encrypted Checkout...")}
                  className="w-full py-3 px-4 bg-[#E72382] hover:bg-[#d01b73] text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
                >
                  <Wallet className="w-4 h-4" />
                  <span>Checkout Now</span>
                  <ArrowRight className="w-4 h-4" />
                </motion.button>

                <p className="text-[10px] text-center text-gray-400 font-medium">
                  🔒 256-bit Bank Grade Encrypted Payment
                </p>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

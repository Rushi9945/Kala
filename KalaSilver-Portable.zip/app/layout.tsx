import type { Metadata, Viewport } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SplashScreen from "@/app/components/SplashScreen";
import CartDrawer from "@/components/CartDrawer";
import { FirebaseProvider } from "@/context/FirebaseContext";
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";

// System fallback fonts with CSS variable bindings (offline-resilient, no network block)
const interVariable = "font-sans";
const spaceGroteskVariable = "font-space-grotesk";
const playfairDisplayVariable = "font-serif";

// ── Metadata ──────────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  title: {
    default: "KalaSilver — Ear Cuffs & Curated Silver Jewellery",
    template: "%s | KalaSilver",
  },
  description:
    "Discover KalaSilver's premium collection of sterling silver and gold-plated jewellery. Handcrafted ear cuffs, rings, necklaces, earrings, bracelets and more. Free shipping above ₹2,999.",
  keywords: [
    "silver jewellery",
    "ear cuffs",
    "gold jewellery",
    "925 sterling silver",
    "rings",
    "necklaces",
    "earrings",
    "bracelets",
    "anklets",
    "KalaSilver",
    "premium jewellery",
    "Indian jewellery",
    "handcrafted jewellery",
    "silver bracelet for women online",
    "925 silver bracelet India",
    "silver chain for women online India",
    "bridal silver jewellery set online",
  ],
  authors: [{ name: "KalaSilver" }],
  creator: "KalaSilver",
  manifest: "/manifest.webmanifest",
  metadataBase: new URL("https://kalasilver.netlify.app"),
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://kalasilver.in",
    siteName: "KalaSilver",
    title: "KalaSilver — Ear Cuffs & Curated Silver Jewellery",
    description:
      "Timeless jewellery crafted with artisan precision. Shop ear cuffs, rings, necklaces, earrings, bracelets and more.",
  },
  twitter: {
    card: "summary_large_image",
    title: "KalaSilver — Ear Cuffs & Curated Silver Jewellery",
    description: "Timeless jewellery crafted with artisan precision.",
    creator: "@kalasilver",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#E72382",
  width: "device-width",
  initialScale: 1,
};

// ── Root Layout ───────────────────────────────────────────────────────────────
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className="font-sans"
      suppressHydrationWarning
    >
      <body
        className="font-sans min-h-screen flex flex-col antialiased bg-[#FBFBFB] text-foreground relative"
      >
        {/* JSON-LD Structured Data — Organisation + WebSite schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Organization",
                  "@id": "https://kalasilver.in/#org",
                  name: "KalaSilver",
                  url: "https://kalasilver.in",
                  logo: "https://kalasilver.in/logo.png",
                  description:
                    "Premium handcrafted 925 sterling silver jewellery — ear cuffs, rings, necklaces, bracelets and more.",
                  sameAs: [
                    "https://instagram.com/kalasilver",
                    "https://twitter.com/kalasilver",
                  ],
                  contactPoint: {
                    "@type": "ContactPoint",
                    contactType: "customer service",
                    email: "support@kalasilver.in",
                  },
                },
                {
                  "@type": "WebSite",
                  "@id": "https://kalasilver.in/#website",
                  url: "https://kalasilver.in",
                  name: "KalaSilver",
                  publisher: { "@id": "https://kalasilver.in/#org" },
                  potentialAction: {
                    "@type": "SearchAction",
                    target: {
                      "@type": "EntryPoint",
                      urlTemplate:
                        "https://kalasilver.in/shop?q={search_term_string}",
                    },
                    "query-input": "required name=search_term_string",
                  },
                },
              ],
            }),
          }}
        />

        <FirebaseProvider>
          <WishlistProvider>
            <CartProvider>
              {/* Full-screen Top-layer Splash Overlay (z-[9999]) */}
              <SplashScreen />

              {/* Global Header */}
              <Header />

              {/* Global Slide-Over Cart Drawer */}
              <CartDrawer />

              {/* Main page content */}
              <main className="flex-1">{children}</main>

              {/* Global Footer */}
              <Footer />
            </CartProvider>
          </WishlistProvider>
        </FirebaseProvider>
      </body>
    </html>
  );
}

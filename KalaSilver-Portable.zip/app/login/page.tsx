"use client";

import React, { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Phone,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  KeyRound,
  Sparkles,
} from "lucide-react";
import { useUser, useAuth } from "@/context/FirebaseContext";
import { signInWithGoogle } from "@/lib/authService";

const ADMIN_PHONES = ["9265854407", "7228820041", "7383269232"];

export default function LoginPage() {
  const [step, setStep] = useState<"enter-phone" | "enter-otp">("enter-phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [toastMsg, setToastMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const auth = useAuth();
  const user = useUser();
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectPath = searchParams.get("redirect") || "/";

  // Check admin role or redirect
  useEffect(() => {
    if (user) {
      const isPhoneAdmin = user.phoneNumber && ADMIN_PHONES.some(p => user.phoneNumber?.includes(p));
      const isEmailAdmin = user.email === "admin@gmail.com";
      if (isPhoneAdmin || isEmailAdmin) {
        router.push("/admin");
      } else {
        router.push(redirectPath);
      }
    }
  }, [user, router, redirectPath]);

  const showToast = (text: string, error = false) => {
    setToastMsg({ text, error });
    setTimeout(() => setToastMsg(null), 4000);
  };

  const cleanPhoneDigits = (val: string) => val.replace(/\D/g, "").slice(-10);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNumber = cleanPhoneDigits(phone);
    if (cleanNumber.length !== 10) {
      showToast("Enter a valid 10-digit mobile number.", true);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/send-sms-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber: cleanNumber }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP");
      showToast(`OTP Sent to +91 ${cleanNumber}`);
      setStep("enter-otp");
    } catch (err: any) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      showToast("Enter the OTP from your SMS.", true);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-sms-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phoneNumber: cleanPhoneDigits(phone),
          otp,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "OTP verification failed");

      showToast("Welcome! You are now logged in.");
      const isPhoneAdmin = ADMIN_PHONES.includes(cleanPhoneDigits(phone));
      if (isPhoneAdmin) {
        router.push("/admin");
      } else {
        router.push(redirectPath);
      }
    } catch (err: any) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setOtp("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/send-sms-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber: cleanPhoneDigits(phone) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to resend OTP");
      showToast(`New code sent to +91 ${cleanPhoneDigits(phone)}`);
    } catch (err: any) {
      showToast(err.message, true);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    try {
      const res = await signInWithGoogle();
      if (res.user) {
        showToast("Signed in with Google successfully!");
        if (res.user.email === "admin@gmail.com") {
          router.push("/admin");
        } else {
          router.push(redirectPath);
        }
      } else if (res.error) {
        showToast(res.error, true);
      }
    } catch (err: any) {
      showToast(err?.message || "Google Sign-in failed", true);
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-[#FFF5F8] flex items-center justify-center p-4 overflow-hidden z-50">
      {/* Background glow effects */}
      <div className="absolute top-0 right-0 w-[240px] md:w-[500px] h-[240px] md:h-[500px] bg-pink-100/40 rounded-full blur-[60px] md:blur-[120px] -mr-32 md:-mr-64 -mt-32 md:-mt-64 animate-pulse pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[300px] md:w-[600px] h-[300px] md:h-[600px] bg-blue-50/30 rounded-full blur-[80px] md:blur-[140px] -ml-40 md:-ml-80 -mb-40 md:-mb-80 pointer-events-none" />

      {/* Floating toast notification */}
      {toastMsg && (
        <div
          className={`fixed top-6 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-full text-xs font-black shadow-xl tracking-wider uppercase transition-all duration-300 ${
            toastMsg.error
              ? "bg-rose-600 text-white shadow-rose-200"
              : "bg-[#E72382] text-white shadow-pink-200"
          }`}
        >
          {toastMsg.text}
        </div>
      )}

      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="w-full max-w-[400px] relative z-10"
      >
        <div className="bg-white/80 backdrop-blur-2xl rounded-[32px] md:rounded-[48px] p-6 md:p-12 shadow-[0_40px_100px_rgba(231,35,130,0.08)] border border-white relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-40 h-40 bg-pink-100/20 blur-3xl rounded-full" />

          <AnimatePresence mode="wait">
            {step === "enter-phone" ? (
              <motion.form
                key="phone"
                onSubmit={handleSendOtp}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.25 }}
                className="space-y-6"
              >
                <div className="space-y-1 text-center md:text-left">
                  <h2 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight italic">
                    Welcome
                  </h2>
                  <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">
                    Enter your mobile number to continue
                  </p>
                </div>

                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-1 pointer-events-none">
                    <Phone className="w-4 h-4 text-gray-400 group-focus-within:text-[#E72382] transition-colors" />
                    <div className="w-px h-4 bg-gray-200 ml-1" />
                    <span className="text-xs font-black text-gray-400 ml-1">+91</span>
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    placeholder="Mobile Number"
                    className="w-full h-14 md:h-16 pl-24 pr-5 bg-gray-50/50 border-2 border-transparent focus:border-[#E72382] focus:bg-white rounded-xl transition-all font-bold outline-none text-sm placeholder:text-gray-300"
                    maxLength={10}
                    inputMode="numeric"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 md:h-16 bg-[#E72382] hover:bg-[#d01f75] disabled:opacity-60 text-white rounded-xl font-black uppercase tracking-[0.2em] shadow-2xl shadow-pink-200 flex items-center justify-center gap-2 transition-all text-[10px]"
                >
                  {loading ? "SENDING..." : "SEND OTP"}
                  {!loading && <ArrowRight className="w-4 h-4" />}
                </button>

                {/* Google Sign-In Option */}
                <div className="pt-2">
                  <div className="flex items-center gap-3 my-2">
                    <div className="flex-1 h-px bg-gray-100" />
                    <span className="text-[9px] uppercase font-bold text-gray-400">or</span>
                    <div className="flex-1 h-px bg-gray-100" />
                  </div>
                  <button
                    type="button"
                    onClick={handleGoogleSignIn}
                    disabled={googleLoading}
                    className="w-full h-12 bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 rounded-xl font-bold text-xs flex items-center justify-center gap-3 transition-all shadow-sm"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                    {googleLoading ? "Connecting..." : "Continue with Google"}
                  </button>
                </div>
              </motion.form>
            ) : (
              <motion.form
                key="otp"
                onSubmit={handleVerifyOtp}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.25 }}
                className="space-y-6"
              >
                <div className="space-y-1 text-center md:text-left">
                  <h2 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight italic">
                    Verify OTP
                  </h2>
                  <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">
                    Code sent to +91 {cleanPhoneDigits(phone)}
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-green-50 rounded-xl px-4 py-3">
                  <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <p className="text-[11px] text-green-700 font-bold">
                    OTP sent! Check your SMS.
                  </p>
                </div>

                <div className="relative group">
                  <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-[#E72382] transition-colors" />
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    placeholder="Enter OTP"
                    className="w-full h-14 md:h-16 pl-12 pr-5 bg-gray-50/50 border-2 border-transparent focus:border-[#E72382] focus:bg-white rounded-xl transition-all font-bold outline-none text-sm placeholder:text-gray-300 tracking-[0.4em] text-center"
                    inputMode="numeric"
                    maxLength={6}
                    autoFocus
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 md:h-16 bg-[#E72382] hover:bg-[#d01f75] disabled:opacity-60 text-white rounded-xl font-black uppercase tracking-[0.2em] shadow-2xl shadow-pink-200 flex items-center justify-center gap-2 transition-all text-[10px]"
                >
                  {loading ? "VERIFYING..." : "VERIFY & LOGIN"}
                  {!loading && <ArrowRight className="w-4 h-4" />}
                </button>

                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => {
                      setStep("enter-phone");
                      setOtp("");
                    }}
                    className="text-[10px] text-gray-400 hover:text-[#E72382] font-bold transition-colors"
                  >
                    ← Change Number
                  </button>
                  <button
                    type="button"
                    onClick={handleResendOtp}
                    disabled={loading}
                    className="text-[10px] text-gray-400 hover:text-[#E72382] font-bold transition-colors disabled:opacity-40"
                  >
                    Resend OTP
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Security Badges */}
          <div className="mt-8 md:mt-10 pt-6 border-t border-gray-50 flex items-center justify-center gap-8">
            <div className="flex flex-col items-center gap-1.5 group cursor-help">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-pink-50 flex items-center justify-center group-hover:bg-[#E72382] group-hover:text-white transition-all">
                <ShieldCheck className="w-4 h-4 md:w-5 md:h-5 text-[#E72382] group-hover:text-white transition-colors" />
              </div>
              <span className="text-[6px] md:text-[8px] font-black uppercase text-gray-300 tracking-widest">
                SECURE
              </span>
            </div>
            <div className="flex flex-col items-center gap-1.5 group cursor-help">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-blue-50 flex items-center justify-center group-hover:bg-[#E72382] group-hover:text-white transition-all">
                <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5 text-blue-500 group-hover:text-white transition-colors" />
              </div>
              <span className="text-[6px] md:text-[8px] font-black uppercase text-gray-300 tracking-widest">
                VERIFIED
              </span>
            </div>
            <div className="flex flex-col items-center gap-1.5 group cursor-help">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-purple-50 flex items-center justify-center group-hover:bg-[#E72382] group-hover:text-white transition-all">
                <Sparkles className="w-4 h-4 md:w-5 md:h-5 text-purple-500 group-hover:text-white transition-colors" />
              </div>
              <span className="text-[6px] md:text-[8px] font-black uppercase text-gray-300 tracking-widest">
                OTP
              </span>
            </div>
          </div>
        </div>

        <div className="text-center mt-6 md:mt-10">
          <p className="text-[8px] md:text-[10px] font-black text-gray-300 uppercase tracking-[0.4em] leading-relaxed">
            Timeless Elegance <br />
            <span className="text-gray-400">Pure 925 Distinction</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  ShoppingBag,
  Package,
  CircleCheck,
  Clock,
  Download,
  FileText,
} from "lucide-react";
import { useUser } from "@/context/FirebaseContext";
import { getUserOrders, OrderRecord } from "@/lib/firestoreService";

// Clean sample boutique order if customer has newly created account
const DEMO_ORDERS: OrderRecord[] = [
  {
    id: "KS-925-88412",
    customerName: "Ananya Sharma",
    email: "ananya@kalasilver.in",
    phone: "+91 9265854407",
    createdAt: new Date(),
    status: "confirmed",
    totalAmount: 3898,
    subtotal: 3898,
    paymentMethod: "upi",
    paymentId: "pay_KS_20261104_9921",
    address: {
      street: "Boutique Residence, 402 Silver Crest",
      city: "Ahmedabad",
      state: "Gujarat",
      pincode: "380015",
    },
    items: [
      {
        id: "kala-001",
        name: "925 Pure Silver CZ Solitaire Ear Cuff",
        price: 1899,
        quantity: 1,
        image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "kala-002",
        name: "Artisan Oxidised Silver Filigree Ring",
        price: 1999,
        quantity: 1,
        image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop",
      },
    ],
  },
];

export default function AccountOrdersPage() {
  const router = useRouter();
  const user = useUser();

  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<OrderRecord | null>(null);

  useEffect(() => {
    if (user === null) {
      router.push("/login?redirect=/account/orders");
      return;
    }

    if (user) {
      getUserOrders(user.uid)
        .then((userOrders: OrderRecord[]) => {
          if (userOrders && userOrders.length > 0) {
            setOrders(userOrders);
          } else {
            setOrders(DEMO_ORDERS);
          }
        })
        .catch(() => {
          setOrders(DEMO_ORDERS);
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      const timer = setTimeout(() => {
        setOrders([]);
        setLoading(false);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [user, router]);

  const handlePrintInvoice = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-pink-200 border-t-[#E72382] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF5F8] pb-24 font-body">
      {/* Sticky Boutique Header */}
      <header className="bg-white/80 backdrop-blur-xl border-b border-pink-100 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 h-20 flex items-center justify-between">
          <button
            onClick={() => router.push("/")}
            className="p-3 hover:bg-pink-50 rounded-2xl transition-all group"
            title="Return Home"
          >
            <ChevronLeft className="w-6 h-6 text-gray-800 group-hover:-translate-x-1 transition-transform" />
          </button>
          <div className="text-center">
            <h1 className="text-lg md:text-xl font-black text-gray-900 uppercase tracking-widest">
              My Boutique Orders
            </h1>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
              {orders.length} {orders.length === 1 ? "Treasure" : "Treasures"} In Portfolio
            </p>
          </div>
          <div className="w-12" />
        </div>
      </header>

      {/* Main Orders Content */}
      <main className="max-w-3xl mx-auto px-4 py-8 md:py-12">
        {orders.length === 0 ? (
          /* Empty State (Exact Match to Screenshot) */
          <div className="text-center py-20 px-6 bg-white rounded-[40px] shadow-[0_20px_60px_rgba(231,35,130,0.05)] border border-pink-50">
            <div className="w-20 h-20 bg-pink-50 rounded-[28px] flex items-center justify-center mx-auto mb-6">
              <ShoppingBag className="w-10 h-10 text-[#E72382]" />
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-gray-900 mb-2">
              No orders yet
            </h2>
            <p className="text-gray-500 font-bold mb-8 text-sm">
              Start your silver collection today!
            </p>
            <button
              onClick={() => router.push("/shop")}
              className="px-8 py-4 bg-[#E72382] hover:bg-[#d01f75] text-white font-black rounded-2xl uppercase tracking-widest text-xs shadow-lg shadow-pink-200 hover:scale-105 transition-all"
            >
              Shop Collection
            </button>
          </div>
        ) : (
          /* Orders List */
          <div className="space-y-6">
            {orders.map((order, idx) => {
              const orderDate = order.createdAt instanceof Date
                ? order.createdAt
                : (order.createdAt?.toDate ? order.createdAt.toDate() : new Date());

              const formattedDate = orderDate.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
              });

              const calculatedTotal = order.items.reduce(
                (sum, item) => sum + (item.price || 0) * (item.quantity || 1),
                0
              );
              const finalAmount = order.totalAmount || order.subtotal || calculatedTotal;
              const totalPieces = order.items.reduce((acc, it) => acc + (it.quantity || 1), 0);

              return (
                <motion.div
                  key={order.id || idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 * idx }}
                  className="bg-white rounded-[40px] overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.03)] border border-pink-50"
                >
                  {/* Order Top Bar */}
                  <div className="p-6 border-b border-pink-50 flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-pink-50 rounded-2xl flex items-center justify-center shrink-0">
                        <Package className="w-6 h-6 text-[#E72382]" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                          Order ID
                        </p>
                        <p className="font-bold text-gray-900 text-sm">
                          #{order.id}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right">
                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                          Date
                        </p>
                        <p className="font-bold text-gray-900 text-sm">
                          {formattedDate}
                        </p>
                      </div>

                      <div className="bg-green-50 px-4 py-2 rounded-xl flex items-center gap-2 border border-green-100/60">
                        <CircleCheck className="w-4 h-4 text-green-500" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-green-600 italic">
                          {order.status || "confirmed"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="p-6 space-y-4">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex items-center gap-4">
                        <div className="relative w-16 h-16 bg-gray-50 rounded-2xl overflow-hidden shrink-0 border border-gray-100">
                          <Image
                            src={item.image}
                            alt={item.name}
                            fill
                            className="object-contain p-2"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-bold text-gray-900 truncate">
                            {item.name}
                          </h4>
                          <p className="text-xs text-gray-400 font-black mt-0.5">
                            QTY: {item.quantity || 1} &times; ₹{item.price.toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-black text-gray-900 italic">
                            ₹{((item.price || 0) * (item.quantity || 1)).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Logistics & Invoice Bar */}
                  <div className="p-6 bg-gray-50/50 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-pink-50">
                    <div className="flex items-center gap-2 text-gray-500">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <p className="text-xs font-bold">
                        Scheduled for priority insured shipping ({totalPieces} {totalPieces === 1 ? "piece" : "pieces"})
                      </p>
                    </div>

                    <div className="flex items-center gap-6 self-end sm:self-auto">
                      <button
                        onClick={() => setSelectedInvoice(order)}
                        className="text-[10px] font-black uppercase tracking-widest text-[#E72382] hover:underline flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" /> Invoice Summary
                      </button>

                      <div className="text-right">
                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                          Total Amount
                        </p>
                        <p className="text-xl font-black text-[#E72382] italic tracking-tighter">
                          ₹{finalAmount.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </main>

      {/* Invoice Modal Overlay */}
      <AnimatePresence>
        {selectedInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[32px] max-w-lg w-full p-6 md:p-8 shadow-2xl border border-pink-100 max-h-[90vh] overflow-y-auto space-y-6"
            >
              <div className="flex items-center justify-between border-b pb-4">
                <div>
                  <h3 className="text-xl font-black italic tracking-tight">
                    Kala<span className="text-[#E72382]">Silver</span> Official Invoice
                  </h3>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-1">
                    GST Compliant Retail Statement
                  </p>
                </div>
                <button
                  onClick={() => setSelectedInvoice(null)}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 font-bold hover:bg-gray-200"
                >
                  &times;
                </button>
              </div>

              {/* Order Meta */}
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <p className="text-gray-400 font-bold uppercase text-[9px]">Invoice Number</p>
                  <p className="font-black text-gray-800">INV-{(selectedInvoice.id || "").toUpperCase()}</p>
                </div>
                <div className="text-right">
                  <p className="text-gray-400 font-bold uppercase text-[9px]">Payment Ref</p>
                  <p className="font-black text-gray-800">{selectedInvoice.paymentId || "Prepaid Verified"}</p>
                </div>
              </div>

              {/* Line Items */}
              <div className="divide-y divide-gray-100 border-y py-2">
                {selectedInvoice.items.map((it) => (
                  <div key={it.id} className="py-2.5 flex justify-between text-xs font-bold">
                    <span>{it.name} &times; {it.quantity}</span>
                    <span>₹{((it.price || 0) * (it.quantity || 1)).toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {/* Mathematics Counting */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Gross Jewellery Total</span>
                  <span>₹{(selectedInvoice.totalAmount || selectedInvoice.subtotal || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Shipping & Handling</span>
                  <span className="text-green-600 font-bold">FREE (Complimentary)</span>
                </div>
                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Insured Packaging</span>
                  <span className="text-green-600 font-bold">Included</span>
                </div>
                <div className="flex justify-between text-base font-black text-gray-900 pt-2 border-t">
                  <span>Net Payable</span>
                  <span className="text-[#E72382] italic">₹{(selectedInvoice.totalAmount || selectedInvoice.subtotal || 0).toLocaleString()}</span>
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  onClick={handlePrintInvoice}
                  className="flex-1 py-3 bg-[#E72382] text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-md flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" /> Print / Save PDF
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

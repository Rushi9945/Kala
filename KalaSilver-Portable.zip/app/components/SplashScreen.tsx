"use client";

import { useEffect, useState } from "react";

interface SplashScreenProps {
  onFinish?: () => void;
  holdDuration?: number;
}

export default function SplashScreen({
  onFinish,
  holdDuration = 2200,
}: SplashScreenProps) {
  const [mounted, setMounted] = useState(true);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const holdTimer = setTimeout(() => {
      setFading(true);
    }, holdDuration);

    const unmountTimer = setTimeout(() => {
      setMounted(false);
      if (onFinish) {
        onFinish();
      }
    }, holdDuration + 500);

    return () => {
      clearTimeout(holdTimer);
      clearTimeout(unmountTimer);
    };
  }, [holdDuration, onFinish]);

  if (!mounted) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white transition-opacity duration-500 ease-in-out ${
        fading ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      {/* Center Logo Group */}
      <div className="flex flex-col items-center text-center select-none">
        {/* Logo Typography: Playfair Display serif, font-black, italic, text-5xl md:text-6xl */}
        <h1
          className="font-serif font-black italic text-5xl md:text-6xl tracking-tight flex items-baseline select-none"
          style={{ fontFamily: '"Playfair Display", var(--font-playfair), serif' }}
        >
          <span className="text-[#1a1a2e]">Kala</span>
          <span className="text-[#E72382]">Silver</span>
        </h1>

        {/* Wider, Softer Glow Line: h-[2px] w-48 mx-auto mt-4 bg-gradient-to-r from-transparent via-[#E72382]/40 to-transparent blur-[2px] */}
        <div className="h-[2px] w-48 mx-auto mt-4 bg-gradient-to-r from-transparent via-[#E72382]/40 to-transparent blur-[2px]" />

        {/* Tagline Typography: Space Grotesk font-headline, text-[#a1a1aa] text-[10px] font-bold uppercase tracking-[0.4em] mt-6 */}
        <p
          className="text-[#a1a1aa] text-[10px] font-bold uppercase tracking-[0.4em] mt-6 select-none"
          style={{ fontFamily: '"Space Grotesk", var(--font-space-grotesk), sans-serif' }}
        >
          PREMIUM ARTISTRY
        </p>
      </div>

      {/* Footer */}
      <div
        className="absolute bottom-10 w-full flex justify-center items-center gap-2 select-none"
        style={{ fontFamily: '"Space Grotesk", var(--font-space-grotesk), sans-serif' }}
      >
        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-pulse" />
        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">
          SECURE ENCRYPTED SESSION
        </span>
      </div>
    </div>
  );
}

"use client";

import React, { useState, useEffect, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Sparkles,
  ShoppingBag,
  TrendingUp,
  Tag,
  Sliders,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Eye,
  CheckCircle2,
  AlertCircle,
  Upload,
  ArrowRight,
  LogOut,
  ChevronRight,
  ShieldCheck,
  Search,
  IndianRupee,
  Package,
  Layers,
  Percent,
  MessageSquare,
  Check,
  X,
} from "lucide-react";
import { useUser, useAuth } from "@/context/FirebaseContext";
import { ProductItem, CustomerReviewRecord } from "@/lib/firestoreService";

const INITIAL_PRODUCTS: ProductItem[] = [
  {
    id: "kala-001",
    name: "925 Pure Silver CZ Solitaire Ear Cuff",
    price: 1899,
    originalPrice: 2499,
    category: "ear-cuffs",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
    inStock: true,
    isBestseller: true,
    isNew: true,
  },
  {
    id: "kala-002",
    name: "Artisan Oxidised Silver Filigree Ring",
    price: 2199,
    originalPrice: 2899,
    category: "rings",
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop",
    inStock: true,
    isBestseller: true,
    isNew: false,
  },
  {
    id: "kala-003",
    name: "Handcrafted Silver Charm Link Bracelet",
    price: 3499,
    originalPrice: 4299,
    category: "bracelets",
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
    inStock: true,
    isBestseller: false,
    isNew: true,
  },
];

const ADMIN_PHONES = ["9265854407", "7228820041", "7383269232"];

export default function AdminDashboardPage() {
  const router = useRouter();
  const user = useUser();
  const auth = useAuth();

  const [activeTab, setActiveTab] = useState<"overview" | "products" | "categories" | "offers" | "reviews" | "siteConfig">("overview");
  const [products, setProducts] = useState<ProductItem[]>(INITIAL_PRODUCTS);
  const [reviewsList, setReviewsList] = useState<CustomerReviewRecord[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Offers state
  const [offers, setOffers] = useState([
    {
      id: "offer-1",
      code: "KALA10",
      description: "10% off on all silver collections",
      discountType: "percentage",
      discountValue: 10,
      minOrderAmount: 1499,
      isActive: true,
    },
    {
      id: "offer-2",
      code: "SILVER500",
      description: "Flat ₹500 discount on bridal jewellery sets",
      discountType: "fixed",
      discountValue: 500,
      minOrderAmount: 4999,
      isActive: true,
    },
  ]);

  // Categories state
  const [categories, setCategories] = useState([
    { id: "ear-cuffs", name: "Ear Cuffs", count: 12, imageUrl: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop" },
    { id: "rings", name: "Rings", count: 18, imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop" },
    { id: "bracelets", name: "Bracelets", count: 9, imageUrl: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop" },
    { id: "necklaces", name: "Necklaces", count: 15, imageUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop" },
    { id: "earrings", name: "Earrings", count: 20, imageUrl: "https://images.unsplash.com/photo-1630019852942-f89202989a59?q=80&w=600&auto=format&fit=crop" },
  ]);

  // New product form modal
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({
    title: "",
    category: "ear-cuffs",
    price: 1999,
    originalPrice: 2499,
    description: "",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
    inStock: true,
    isBestSeller: false,
    isNew: true,
  });

  // New offer form
  const [newOffer, setNewOffer] = useState({
    code: "",
    description: "",
    discountType: "percentage" as "percentage" | "fixed",
    discountValue: 10,
    minOrderAmount: 999,
    isActive: true,
  });

  // Verify Admin authorization & load reviews
  useEffect(() => {
    if (user) {
      const isPhoneAdmin = user.phoneNumber && ADMIN_PHONES.some(p => user.phoneNumber?.includes(p));
      const isEmailAdmin = user.email === "admin@gmail.com";
    }
    fetchReviews();
  }, [user, router]);

  const fetchReviews = async () => {
    try {
      setReviewsLoading(true);
      const res = await fetch("/api/reviews/moderate");
      const data = await res.json();
      if (data.reviews) {
        setReviewsList(data.reviews);
      }
    } catch (e) {
      console.warn("Reviews load notice:", e);
    } finally {
      setReviewsLoading(false);
    }
  };

  const handleModerateReview = async (reviewId: string, action: "approved" | "rejected") => {
    try {
      const res = await fetch("/api/reviews/moderate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reviewId, action }),
      });
      if (res.ok) {
        setReviewsList((prev) =>
          prev.map((r) => (r.id === reviewId ? { ...r, status: action } : r))
        );
      }
    } catch (e) {
      alert("Failed to update review moderation status.");
    }
  };

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = (p.name || "").toLowerCase().includes(searchQuery.toLowerCase()) || p.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || p.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchQuery, selectedCategory]);

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.title.trim()) return;
    const created: ProductItem = {
      id: `kala-${Date.now().toString().slice(-6)}`,
      name: newProduct.title,
      category: newProduct.category,
      price: Number(newProduct.price),
      originalPrice: Number(newProduct.originalPrice),
      rating: 5.0,
      reviews: 1,
      image: newProduct.image,
      description: newProduct.description || "Pure 925 sterling silver artisan craft.",
      inStock: newProduct.inStock,
      isBestseller: newProduct.isBestSeller,
      isNew: newProduct.isNew,
    };
    setProducts([created, ...products]);
    setIsAddingProduct(false);
    setNewProduct({
      title: "",
      category: "ear-cuffs",
      price: 1999,
      originalPrice: 2499,
      description: "",
      image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
      inStock: true,
      isBestSeller: false,
      isNew: true,
    });
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm("Are you sure you want to delete this piece?")) {
      setProducts(products.filter(p => p.id !== id));
    }
  };

  const handleAddOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOffer.code.trim()) return;
    setOffers([
      ...offers,
      {
        id: `offer-${Date.now()}`,
        code: newOffer.code.toUpperCase(),
        description: newOffer.description,
        discountType: newOffer.discountType,
        discountValue: Number(newOffer.discountValue),
        minOrderAmount: Number(newOffer.minOrderAmount),
        isActive: true,
      },
    ]);
    setNewOffer({
      code: "",
      description: "",
      discountType: "percentage",
      discountValue: 10,
      minOrderAmount: 999,
      isActive: true,
    });
  };

  const toggleOffer = (id: string) => {
    setOffers(offers.map(o => o.id === id ? { ...o, isActive: !o.isActive } : o));
  };

  const deleteOffer = (id: string) => {
    setOffers(offers.filter(o => o.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]/40 pb-20">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-pink-100/60 px-4 md:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="text-2xl font-black italic tracking-tighter text-gray-900">
              Kala<span className="text-[#E72382]">Silver</span>
            </Link>
            <span className="px-2.5 py-0.5 rounded-full bg-[#E72382]/10 text-[#E72382] text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Admin Studio
            </span>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/shop"
              className="px-4 py-2 text-xs font-bold text-gray-600 hover:text-[#E72382] transition-colors"
            >
              View Storefront
            </Link>
            <button
              onClick={() => router.push("/login")}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all"
            >
              <LogOut className="w-3.5 h-3.5" /> Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 pt-8">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 border-b border-pink-100/80 mb-8">
          {[
            { id: "overview", label: "Overview", icon: TrendingUp },
            { id: "products", label: "Catalogue", icon: ShoppingBag },
            { id: "categories", label: "Categories", icon: Layers },
            { id: "offers", label: "Coupons & Offers", icon: Percent },
            { id: "reviews", label: "Patron Reviews", icon: MessageSquare },
            { id: "siteConfig", label: "Brand Settings", icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 whitespace-nowrap transition-all ${
                  isActive
                    ? "bg-[#E72382] text-white shadow-lg shadow-pink-200"
                    : "bg-white text-gray-600 hover:text-gray-900 border border-gray-100"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === "overview" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            {/* Stat Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-3xl p-6 border border-pink-50 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-[#E72382]/5 rounded-full -mr-8 -mt-8" />
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Total Products</p>
                <h3 className="text-3xl font-black text-gray-900 mt-2">{products.length}</h3>
                <span className="text-[10px] font-bold text-green-600 mt-2 inline-block">● 100% Active in Stock</span>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-pink-50 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-8 -mt-8" />
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Categories</p>
                <h3 className="text-3xl font-black text-gray-900 mt-2">{categories.length}</h3>
                <span className="text-[10px] font-bold text-blue-600 mt-2 inline-block">Curated Suites</span>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-pink-50 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full -mr-8 -mt-8" />
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Active Coupons</p>
                <h3 className="text-3xl font-black text-gray-900 mt-2">{offers.filter(o => o.isActive).length}</h3>
                <span className="text-[10px] font-bold text-purple-600 mt-2 inline-block">High conversion promo</span>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-pink-50 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-pink-500/5 rounded-full -mr-8 -mt-8" />
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Average Order Value</p>
                <h3 className="text-3xl font-black text-gray-900 mt-2">₹2,840</h3>
                <span className="text-[10px] font-bold text-emerald-600 mt-2 inline-block">Premium 925 Distinction</span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-pink-500/10 rounded-3xl p-8 border border-pink-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-xl font-black text-gray-900">Manage Your Jewellery Studio</h3>
                <p className="text-xs text-gray-500 mt-1 font-medium">Add new designs, launch festive discount codes, and optimize site assets instantly.</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => { setActiveTab("products"); setIsAddingProduct(true); }}
                  className="px-6 py-3 bg-[#E72382] hover:bg-[#d01f75] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg shadow-pink-200 flex items-center gap-2 transition-all"
                >
                  <Plus className="w-4 h-4" /> Add Product
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRODUCTS CATALOGUE */}
        {activeTab === "products" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Header / Filter Toolbar */}
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 bg-white p-4 rounded-3xl border border-pink-50">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search products by title or ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-gray-50/50 rounded-2xl text-xs font-bold outline-none border border-transparent focus:border-[#E72382] transition-all"
                />
              </div>

              <div className="flex items-center gap-3">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-4 py-3 bg-gray-50/50 rounded-2xl text-xs font-bold outline-none border border-transparent focus:border-[#E72382] transition-all"
                >
                  <option value="all">All Categories</option>
                  <option value="ear-cuffs">Ear Cuffs</option>
                  <option value="rings">Rings</option>
                  <option value="bracelets">Bracelets</option>
                  <option value="necklaces">Necklaces</option>
                  <option value="earrings">Earrings</option>
                </select>

                <button
                  onClick={() => setIsAddingProduct(true)}
                  className="px-5 py-3 bg-[#E72382] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-md shadow-pink-200 flex items-center gap-2 whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" /> Add Product
                </button>
              </div>
            </div>

            {/* Modal for Adding Product */}
            {isAddingProduct && (
              <div className="bg-white p-6 rounded-3xl border border-pink-100 shadow-xl space-y-4">
                <h4 className="text-base font-black text-gray-900">Add New Jewellery Piece</h4>
                <form onSubmit={handleAddProduct} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Title</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 925 Silver Solitaire Ear Cuff"
                      value={newProduct.title}
                      onChange={(e) => setNewProduct({ ...newProduct, title: e.target.value })}
                      className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Category</label>
                    <select
                      value={newProduct.category}
                      onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                      className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                    >
                      <option value="ear-cuffs">Ear Cuffs</option>
                      <option value="rings">Rings</option>
                      <option value="bracelets">Bracelets</option>
                      <option value="necklaces">Necklaces</option>
                      <option value="earrings">Earrings</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Selling Price (₹)</label>
                    <input
                      type="number"
                      required
                      value={newProduct.price}
                      onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                      className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Image URL</label>
                    <input
                      type="text"
                      required
                      value={newProduct.image}
                      onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
                      className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                    />
                  </div>

                  <div className="flex items-end gap-3">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-[#E72382] text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-md"
                    >
                      Save Piece
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddingProduct(false)}
                      className="px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-xs font-bold"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Products Table */}
            <div className="bg-white rounded-3xl border border-pink-50 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50/70 border-b border-gray-100">
                    <tr>
                      <th className="py-4 px-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Piece</th>
                      <th className="py-4 px-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Category</th>
                      <th className="py-4 px-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Price</th>
                      <th className="py-4 px-6 text-[10px] font-black uppercase tracking-widest text-gray-400">Stock</th>
                      <th className="py-4 px-6 text-[10px] font-black uppercase tracking-widest text-gray-400 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-pink-50/30 transition-colors">
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 relative rounded-xl overflow-hidden bg-gray-100 border border-gray-100 flex-shrink-0">
                              <Image src={p.image} alt={p.name} fill className="object-cover" />
                            </div>
                            <div>
                              <p className="text-xs font-black text-gray-900">{p.name}</p>
                              <span className="text-[10px] font-bold text-gray-400 uppercase">ID: {p.id}</span>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <span className="px-3 py-1 bg-gray-100 rounded-full text-[10px] font-black uppercase tracking-wider text-gray-600">
                            {p.category}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-black text-gray-900">₹{p.price.toLocaleString()}</span>
                            {p.originalPrice && (
                              <span className="text-[10px] text-gray-400 line-through">₹{p.originalPrice.toLocaleString()}</span>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-green-600">
                            <CheckCircle2 className="w-3 h-3" /> In Stock
                          </span>
                        </td>
                        <td className="py-4 px-6 text-right">
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-2 text-gray-400 hover:text-red-500 rounded-lg transition-colors"
                            title="Delete Piece"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CATEGORIES */}
        {activeTab === "categories" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {categories.map((c) => (
              <div key={c.id} className="bg-white rounded-3xl p-5 border border-pink-50 shadow-sm flex items-center gap-4">
                <div className="w-16 h-16 relative rounded-2xl overflow-hidden bg-gray-100 border flex-shrink-0">
                  <Image src={c.imageUrl} alt={c.name} fill className="object-cover" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-black text-gray-900">{c.name}</h4>
                  <p className="text-[10px] font-bold text-gray-400 uppercase mt-0.5">{c.count} Pieces Listed</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 4: OFFERS & COUPONS */}
        {activeTab === "offers" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Create Offer */}
            <div className="bg-white rounded-3xl p-6 border border-pink-100 shadow-sm">
              <h4 className="text-sm font-black uppercase tracking-wider text-gray-900 mb-4 flex items-center gap-2">
                <Tag className="w-4 h-4 text-[#E72382]" /> Create New Exclusive Coupon
              </h4>
              <form onSubmit={handleAddOffer} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Coupon Code</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. FESTIVE15"
                    value={newOffer.code}
                    onChange={(e) => setNewOffer({ ...newOffer, code: e.target.value.toUpperCase() })}
                    className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Discount (% or ₹)</label>
                  <input
                    type="number"
                    required
                    value={newOffer.discountValue}
                    onChange={(e) => setNewOffer({ ...newOffer, discountValue: Number(e.target.value) })}
                    className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase text-gray-400 block mb-1">Min. Order Value (₹)</label>
                  <input
                    type="number"
                    required
                    value={newOffer.minOrderAmount}
                    onChange={(e) => setNewOffer({ ...newOffer, minOrderAmount: Number(e.target.value) })}
                    className="w-full px-4 py-2.5 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-[#E72382] hover:bg-[#d01f75] text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-md"
                  >
                    Add Offer
                  </button>
                </div>
              </form>
            </div>

            {/* List of Offers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {offers.map((o) => (
                <div key={o.id} className="bg-white rounded-3xl p-5 border border-pink-50 shadow-sm flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-xl bg-pink-50 text-[#E72382] font-black text-xs tracking-wider">
                        {o.code}
                      </span>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${o.isActive ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-400"}`}>
                        {o.isActive ? "Active" : "Disabled"}
                      </span>
                    </div>
                    <p className="text-xs font-bold text-gray-700 mt-2">{o.description}</p>
                    <p className="text-[10px] text-gray-400 font-medium">Min Order: ₹{o.minOrderAmount}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleOffer(o.id)}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors"
                    >
                      {o.isActive ? "Disable" : "Enable"}
                    </button>
                    <button
                      onClick={() => deleteOffer(o.id)}
                      className="p-2 text-gray-400 hover:text-red-500 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: PATRON REVIEWS MODERATION */}
        {activeTab === "reviews" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-base font-black text-gray-900">Patron Review Moderation Suite</h4>
                <p className="text-xs text-gray-400 mt-0.5 font-medium">
                  Review authentic customer worn photos & testimonials before publishing them live to product pages.
                </p>
              </div>
              <button
                onClick={fetchReviews}
                className="px-4 py-2 bg-pink-50 text-[#E72382] hover:bg-pink-100 rounded-xl text-xs font-bold transition"
              >
                Refresh Reviews
              </button>
            </div>

            {reviewsLoading ? (
              <div className="py-16 text-center text-xs text-gray-400">Loading customer submissions...</div>
            ) : reviewsList.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 border border-gray-100 text-center">
                <MessageSquare className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <h5 className="font-serif text-base font-bold text-gray-900">No Reviews to Moderate</h5>
                <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
                  When customers submit their worn jewellery photos & reviews, they will appear here for your approval.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {reviewsList.map((rev) => (
                  <div
                    key={rev.id}
                    className="bg-white rounded-3xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-gray-900">{rev.authorName}</span>
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                            rev.status === "approved"
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : rev.status === "rejected"
                              ? "bg-rose-50 text-rose-700 border border-rose-200"
                              : "bg-amber-50 text-amber-700 border border-amber-200"
                          }`}
                        >
                          {rev.status}
                        </span>
                      </div>

                      <p className="text-[11px] font-mono text-gray-400">
                        Product Ref: <span className="text-gray-700 font-semibold">{rev.productId}</span>
                      </p>

                      {rev.photoUrl && (
                        <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-gray-50 border border-gray-100">
                          <img
                            src={rev.photoUrl}
                            alt={`Worn review by ${rev.authorName}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      <p className="text-xs text-gray-700 italic bg-gray-50/70 p-3 rounded-xl border border-gray-100">
                        &ldquo;{rev.textFeedback}&rdquo;
                      </p>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                      <button
                        onClick={() => rev.id && handleModerateReview(rev.id, "approved")}
                        disabled={rev.status === "approved"}
                        className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 transition"
                      >
                        <Check size={14} />
                        <span>Push Live</span>
                      </button>
                      <button
                        onClick={() => rev.id && handleModerateReview(rev.id, "rejected")}
                        disabled={rev.status === "rejected"}
                        className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-xl text-xs font-bold uppercase transition"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 6: BRAND & SITE CONFIG */}
        {activeTab === "siteConfig" && (
          <div className="bg-white rounded-3xl p-6 border border-pink-100 shadow-sm space-y-6 animate-in fade-in duration-300">
            <div>
              <h4 className="text-base font-black text-gray-900">Brand Identity & Messaging</h4>
              <p className="text-xs text-gray-400 mt-0.5 font-medium">Global store headers, shipping tickers, and security guarantees.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-wider text-gray-500">Store Announcement Banner</label>
                <input
                  type="text"
                  defaultValue="FREE COMPLIMENTARY SHIPPING ACROSS INDIA ON ORDERS ABOVE ₹2,999"
                  className="w-full px-4 py-3 bg-gray-50 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-wider text-gray-500">Brand Accent Color</label>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#E72382] border shadow-sm" />
                  <input
                    type="text"
                    defaultValue="#E72382"
                    readOnly
                    className="flex-1 px-4 py-3 bg-gray-50 rounded-xl text-xs font-bold outline-none border"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

import { NextResponse } from "next/server";
import { getAllReviewsAdmin, updateReviewModeration } from "@/lib/firestoreService";

// GET /api/reviews/moderate - returns all reviews for store owner
export async function GET() {
  try {
    const reviews = await getAllReviewsAdmin();
    return NextResponse.json({ reviews });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST /api/reviews/moderate - approve or decline
export async function POST(req: Request) {
  try {
    const { reviewId, action } = await req.json(); // action: "approved" | "rejected"
    if (!reviewId || !action) {
      return NextResponse.json({ error: "reviewId and action are required" }, { status: 400 });
    }

    const success = await updateReviewModeration(reviewId, action);
    return NextResponse.json({ success, action });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

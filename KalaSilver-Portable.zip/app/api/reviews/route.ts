import { NextResponse } from "next/server";
import { getProductById, getReviewsForProduct, submitCustomerReview } from "@/lib/firestoreService";

// GET /api/reviews?productId=xyz
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const productId = searchParams.get("productId");

    if (!productId) {
      return NextResponse.json({ error: "productId parameter is required" }, { status: 400 });
    }

    const reviews = await getReviewsForProduct(productId, false);
    return NextResponse.json({ reviews });
  } catch (error: any) {
    console.error("GET /api/reviews error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch reviews" }, { status: 500 });
  }
}

// POST /api/reviews
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { productId, authorName, textFeedback, photoUrl, userContact } = body;

    if (!productId || !authorName?.trim() || !textFeedback?.trim()) {
      return NextResponse.json(
        { error: "Product ID, your name, and your feedback review text are required" },
        { status: 400 }
      );
    }

    const result = await submitCustomerReview({
      productId,
      authorName: authorName.trim(),
      textFeedback: textFeedback.trim(),
      photoUrl: photoUrl || "",
      userContact: userContact || "",
      status: "pending", // Waiting for store owner approval
    });

    return NextResponse.json({
      success: true,
      reviewId: result.reviewId,
      message: "Thank you for sharing your experience! Your review and photograph have been sent to our atelier for preview.",
    });
  } catch (error: any) {
    console.error("POST /api/reviews error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to submit customer review" },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";

// Simulated in-memory store for OTP development / testing
const otpStore = new Map<string, { code: string; expires: number }>();

export async function POST(req: Request) {
  try {
    const { phoneNumber } = await req.json();
    const cleanPhone = String(phoneNumber || "").replace(/\D/g, "").slice(-10);

    if (cleanPhone.length !== 10) {
      return NextResponse.json(
        { error: "Invalid mobile number. Must be 10 digits." },
        { status: 400 }
      );
    }

    // In production, integration with SMS gateways (Twilio / Msg91 / Firebase) occurs here.
    // For fast testing and resilient development:
    const code = cleanPhone === "9265854407" || cleanPhone === "7228820041" || cleanPhone === "7383269232"
      ? "123456"
      : Math.floor(100000 + Math.random() * 900000).toString();

    otpStore.set(cleanPhone, {
      code,
      expires: Date.now() + 5 * 60 * 1000, // 5 minutes
    });

    return NextResponse.json({
      success: true,
      message: `OTP sent successfully to +91 ${cleanPhone}`,
      // For development ease if SMS provider not yet wired:
      devOtp: code,
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || "Failed to send SMS OTP" },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { phoneNumber, otp } = await req.json();
    const cleanPhone = String(phoneNumber || "").replace(/\D/g, "").slice(-10);

    if (cleanPhone.length !== 10) {
      return NextResponse.json(
        { error: "Invalid mobile number." },
        { status: 400 }
      );
    }

    if (!otp || String(otp).length < 4) {
      return NextResponse.json(
        { error: "Invalid OTP. Enter the OTP sent to your SMS." },
        { status: 400 }
      );
    }

    // Admins or test bypass
    const isAdmin = ["9265854407", "7228820041", "7383269232"].includes(cleanPhone);

    return NextResponse.json({
      success: true,
      phoneNumber: `+91${cleanPhone}`,
      isAdmin,
      customToken: `mock-token-${cleanPhone}-${Date.now()}`,
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || "OTP verification failed" },
      { status: 500 }
    );
  }
}

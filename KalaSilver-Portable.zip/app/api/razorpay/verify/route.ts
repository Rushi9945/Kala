import { NextResponse } from "next/server";
import crypto from "crypto";
import { createFirestoreOrder } from "@/lib/firestoreService";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      orderDetails,
    } = body;

    const key_secret = process.env.RAZORPAY_KEY_SECRET;

    // Signature verification if secret is configured
    if (key_secret && razorpay_signature) {
      const generated_signature = crypto
        .createHmac("sha256", key_secret)
        .update(`${razorpay_order_id}|${razorpay_payment_id}`)
        .digest("hex");

      if (generated_signature !== razorpay_signature) {
        return NextResponse.json(
          { success: false, error: "Invalid payment signature verification failed" },
          { status: 400 }
        );
      }
    }

    // Persist verified order in Firestore
    let savedOrderResult = { success: true, orderId: `KS-${Date.now()}` };
    if (orderDetails) {
      savedOrderResult = await createFirestoreOrder({
        userId: orderDetails.userId || "guest",
        customerName: orderDetails.customerName || "Valued Patron",
        email: orderDetails.email || "",
        phone: orderDetails.phone || "",
        address: orderDetails.address || {
          street: "",
          city: "",
          state: "",
          pincode: "",
        },
        items: orderDetails.items || [],
        totalAmount: Number(orderDetails.totalAmount) || 0,
        subtotal: Number(orderDetails.subtotal) || Number(orderDetails.totalAmount) || 0,
        paymentId: razorpay_payment_id || `PAY_${Date.now()}`,
        status: "confirmed",
        paymentMethod: "upi",
      });
    }

    return NextResponse.json({
      success: true,
      message: "Payment successfully verified and order reserved",
      orderId: savedOrderResult.orderId,
      paymentId: razorpay_payment_id,
    });
  } catch (error: any) {
    console.error("Payment verification route error:", error);
    return NextResponse.json(
      { success: false, error: "Server payment verification error", details: error.message },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { amount, currency = "INR", receipt } = await req.json();

    if (!amount) {
      return NextResponse.json({ error: "Amount is required" }, { status: 400 });
    }

    const key_id = process.env.RAZORPAY_KEY_ID || process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "rzp_test_placeholder";
    const key_secret = process.env.RAZORPAY_KEY_SECRET;

    // If live credentials are provided in env, make call to Razorpay Orders API
    if (key_secret && key_id && key_id !== "rzp_test_placeholder") {
      const auth = Buffer.from(`${key_id}:${key_secret}`).toString("base64");
      const res = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Basic ${auth}`,
        },
        body: JSON.stringify({
          amount: Math.round(Number(amount) * 100), // amount in paise
          currency,
          receipt: receipt || `rcpt_${Date.now()}`,
        }),
      });

      const orderData = await res.json();
      if (!res.ok) {
        console.error("Razorpay API order error:", orderData);
        return NextResponse.json(
          { error: orderData.error?.description || "Failed to create Razorpay order" },
          { status: res.status }
        );
      }
      return NextResponse.json(orderData);
    }

    // High fidelity test mode fallback for development
    const mockOrder = {
      id: `order_${Date.now().toString(36)}${Math.random().toString(36).substring(2, 7)}`,
      entity: "order",
      amount: Math.round(Number(amount) * 100),
      amount_paid: 0,
      amount_due: Math.round(Number(amount) * 100),
      currency: "INR",
      receipt: receipt || `rcpt_${Date.now()}`,
      status: "created",
      created_at: Math.floor(Date.now() / 1000),
      isMock: true,
    };

    return NextResponse.json(mockOrder);
  } catch (error: any) {
    console.error("Razorpay order creation error:", error);
    return NextResponse.json(
      { error: "Internal server error creating order", details: error.message },
      { status: 500 }
    );
  }
}

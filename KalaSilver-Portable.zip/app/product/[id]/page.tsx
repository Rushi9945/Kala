import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getProductById, getReviewsForProduct, getProducts } from "@/lib/firestoreService";
import ProductDetailClient from "./ProductDetailClient";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const product = await getProductById(id);

  if (!product) {
    return {
      title: "Product Not Found | Kala Silver",
    };
  }

  return {
    title: `${product.name} | Kala Silver`,
    description:
      product.description ||
      `Buy authentic 925 Sterling Silver ${product.name} online at Kala Silver.`,
  };
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const product = await getProductById(id);

  if (!product) {
    notFound();
  }

  // Fetch approved customer reviews
  const reviews = await getReviewsForProduct(product.id, false);

  // Fetch similar products in the same category or general collection
  const allProducts = await getProducts();
  const similarProducts = allProducts
    .filter((p) => p.id !== product.id)
    .slice(0, 8);

  return (
    <ProductDetailClient
      product={product}
      reviews={reviews}
      similarProducts={similarProducts}
    />
  );
}

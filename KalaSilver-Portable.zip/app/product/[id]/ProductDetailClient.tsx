"use client";

import React, { useState, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { ProductItem, CustomerReviewRecord } from "@/lib/firestoreService";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import {
  ArrowLeft,
  Heart,
  Share2,
  ShieldCheck,
  Truck,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Camera,
  MessageSquarePlus,
  ShoppingBag,
  Zap,
  Check,
  CheckCircle2,
  Info
} from "lucide-react";

interface ProductDetailClientProps {
  product: ProductItem;
  reviews: CustomerReviewRecord[];
  similarProducts: ProductItem[];
}

export default function ProductDetailClient({
  product,
  reviews,
  similarProducts,
}: ProductDetailClientProps) {
  const router = useRouter();
  const { addItem, addToCart } = useCart();
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();

  // Image gallery gallery states
  const allImages =
    product.imageUrls && product.imageUrls.length > 0
      ? product.imageUrls
      : [product.image];
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50 });
  const [isGiftWrap, setIsGiftWrap] = useState(false);
  const [customNameInput, setCustomNameInput] = useState("");
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [addedToast, setAddedToast] = useState(false);

  const isLiked = isInWishlist(product.id);

  // Mouse move for hover zoom
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setZoomPos({ x, y });
  };

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${product.name} | Kala Silver`,
          text: `Discover this handcrafted 925 sterling silver piece: ${product.name}`,
          url,
        });
      } catch (err) {
        // user cancelled
      }
    } else {
      await navigator.clipboard.writeText(url);
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 2000);
    }
  };

  const handleAddToCart = () => {
    addItem(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        salePrice: product.originalPrice ? product.price : undefined,
        image: allImages[0] || product.image,
      },
      1,
      customNameInput.trim() || undefined
    );
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  const handleBuyNow = () => {
    addItem(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        salePrice: product.originalPrice ? product.price : undefined,
        image: allImages[0] || product.image,
      },
      1,
      customNameInput.trim() || undefined
    );
    router.push("/checkout");
  };

  return (
    <div className="min-h-screen bg-[#FFFBF8] text-gray-800 pb-28 selection:bg-pink-100 selection:text-[#E72382]">
      {/* Top Navigation */}
      <div className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gray-500 hover:text-[#E72382] transition"
          >
            <ArrowLeft size={16} />
            <span className="hidden sm:inline">Return to Collection</span>
          </button>

          <Link href="/" className="font-serif text-lg tracking-[0.2em] font-bold text-gray-900 uppercase">
            Kala <span className="text-[#E72382]">Silver</span>
          </Link>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (isLiked) {
                  removeFromWishlist(product.id);
                } else {
                  addToWishlist({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.image,
                  });
                }
              }}
              className={`p-2 rounded-full border transition active:scale-95 ${
                isLiked
                  ? "bg-pink-50 border-[#E72382] text-[#E72382]"
                  : "border-gray-200 text-gray-600 hover:border-gray-400"
              }`}
            >
              <Heart size={16} className={isLiked ? "fill-[#E72382]" : ""} />
            </button>

            <button
              onClick={handleShare}
              className="p-2 rounded-full border border-gray-200 text-gray-600 hover:border-gray-400 transition active:scale-95"
            >
              <Share2 size={16} />
            </button>
          </div>
        </div>
      </div>

      {copiedNotification && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white text-xs px-4 py-2 rounded-full shadow-lg animate-fade-in">
          Link copied to clipboard ✓
        </div>
      )}

      {addedToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#E72382] text-white text-xs font-semibold px-5 py-2.5 rounded-full shadow-lg flex items-center gap-2 animate-bounce">
          <Check size={16} />
          <span>Added to your curated bag!</span>
        </div>
      )}

      {/* Main Product Showcase (Image Gallery & Core Info) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left Column: Image Gallery with Magnifier */}
          <div className="lg:col-span-7 flex flex-col-reverse md:flex-row gap-4">
            {/* Vertical thumbnails */}
            {allImages.length > 1 && (
              <div className="flex md:flex-col gap-3 overflow-x-auto md:overflow-y-auto max-h-[500px] no-scrollbar">
                {allImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIdx(idx)}
                    className={`relative w-16 h-16 md:w-20 md:h-20 rounded-xl overflow-hidden border-2 flex-shrink-0 transition ${
                      activeImageIdx === idx
                        ? "border-[#E72382] ring-2 ring-[#E72382]/20 shadow-sm"
                        : "border-transparent opacity-60 hover:opacity-100"
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} thumbnail ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Main Image Stage */}
            <div
              className="relative flex-1 aspect-square rounded-3xl bg-white border border-gray-100 overflow-hidden shadow-[0_4px_25px_rgba(0,0,0,0.03)] cursor-crosshair group"
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsZoomed(true)}
              onMouseLeave={() => setIsZoomed(false)}
            >
              <img
                src={allImages[activeImageIdx]}
                alt={product.name}
                style={{
                  transformOrigin: `${zoomPos.x}% ${zoomPos.y}%`,
                  transform: isZoomed ? "scale(2.2)" : "scale(1)",
                  transition: isZoomed ? "none" : "transform 0.3s ease-out",
                }}
                className="w-full h-full object-contain p-6 pointer-events-none"
              />

              {/* Tag / Quality Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-1.5 pointer-events-none">
                {product.isBestseller && (
                  <span className="bg-[#E72382] text-white text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full shadow-sm">
                    Bestseller
                  </span>
                )}
                {product.isNew && (
                  <span className="bg-gray-900 text-white text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full shadow-sm">
                    New Arrival
                  </span>
                )}
              </div>

              {/* Zoom hint button */}
              <button
                onClick={() => setIsZoomed(!isZoomed)}
                className="absolute top-4 right-4 p-2.5 rounded-full bg-white/90 backdrop-blur-md shadow-sm border border-gray-100 text-gray-700 hover:text-[#E72382] transition md:hidden"
              >
                {isZoomed ? <ZoomOut size={16} /> : <ZoomIn size={16} />}
              </button>

              {/* Pure Silver Hallmark Pill */}
              <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full border border-gray-100 text-[11px] font-semibold text-gray-800 flex items-center gap-1.5 shadow-sm">
                <Sparkles size={13} className="text-[#E72382]" />
                <span>925 Sterling Silver</span>
              </div>
            </div>
          </div>

          {/* Right Column: Title, Pricing, Actions & Systematic Info */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#E72382] mb-1">
                {product.category} Heirloom
              </p>
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900 leading-tight">
                {product.name}
              </h1>

              {/* Price Row */}
              <div className="mt-3 flex items-baseline gap-3">
                <span className="font-serif text-3xl font-bold text-gray-900">
                  ₹{product.price.toLocaleString("en-IN")}
                </span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <>
                    <span className="text-gray-400 line-through text-sm">
                      ₹{product.originalPrice.toLocaleString("en-IN")}
                    </span>
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      {product.discount || "Special Offer"}
                    </span>
                  </>
                )}
              </div>
              <p className="text-[10px] uppercase font-bold tracking-wider text-gray-400 mt-1">
                MRP Inclusive of all taxes & BIS Hallmarking Certification
              </p>
            </div>

            {/* Systematic Product Specifications Grid */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-[0_2px_15px_rgba(0,0,0,0.02)] space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-900 flex items-center gap-1.5">
                <Info size={14} className="text-[#E72382]" />
                <span>Product Specifications</span>
              </h3>
              <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 text-xs">
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase tracking-wider">Metal / Purity</span>
                  <span className="font-semibold text-gray-800">
                    {product.metal || "925 Pure Sterling Silver"}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase tracking-wider">Hallmark Stamp</span>
                  <span className="font-semibold text-emerald-700">BIS Certified 925</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase tracking-wider">Plating / Finish</span>
                  <span className="font-semibold text-gray-800">Anti-Tarnish Rhodium</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase tracking-wider">Weight / Size</span>
                  <span className="font-semibold text-gray-800">{product.weight || "Standard Artisanal"}</span>
                </div>
              </div>
            </div>

            {/* Systematic Step-by-Step Description */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-900">
                Design & Artisanal Note
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                {product.description ||
                  "Handcrafted in 925 Sterling Silver with precision facet cutting. Designed to embody effortless elegance for daily luxury as well as milestone celebrations."}
              </p>
            </div>

            {/* Small Care Guide Note */}
            <div className="bg-amber-50/70 border border-amber-200/60 rounded-2xl p-4 flex items-start gap-3">
              <Sparkles size={18} className="text-amber-700 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-amber-900 space-y-1">
                <p className="font-bold">Artisanal Silver Care Guide</p>
                <p className="text-[11px] text-amber-800/90 leading-relaxed">
                  Store in the provided anti-tarnish Kala Silver ziplock pouch away from moisture and direct perfumes. Gently wipe with a soft microfiber cloth after wear to retain eternal radiance.
                </p>
              </div>
            </div>

            {/* Gift Wrap Addon Option */}
            <label className="flex items-center gap-3 p-3.5 bg-pink-50/40 rounded-xl border border-pink-100 cursor-pointer">
              <input
                type="checkbox"
                checked={isGiftWrap}
                onChange={(e) => setIsGiftWrap(e.target.checked)}
                className="w-4 h-4 accent-[#E72382] rounded"
              />
              <span className="text-xs text-gray-700 font-medium">
                Sending as a gift? Add our signature luxury gift box & ribbon (₹50)
              </span>
            </label>

            {/* Desktop / Tablet CTA Buttons */}
            <div className="hidden sm:flex gap-3 pt-2">
              <button
                onClick={handleAddToCart}
                className="flex-1 py-3.5 px-6 rounded-xl border-2 border-[#E72382] text-[#E72382] hover:bg-pink-50 font-semibold text-xs uppercase tracking-wider transition active:scale-95 flex items-center justify-center gap-2"
              >
                <ShoppingBag size={16} />
                <span>Add to Bag</span>
              </button>
              <button
                onClick={handleBuyNow}
                className="flex-1 py-3.5 px-6 rounded-xl bg-[#E72382] hover:bg-[#d01c72] text-white font-semibold text-xs uppercase tracking-wider transition shadow-md shadow-pink-200 active:scale-95 flex items-center justify-center gap-2"
              >
                <Zap size={16} />
                <span>Buy Now</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SIMILAR PRODUCTS SCROLLABLE GALLERY */}
      {similarProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-16">
          <div className="flex items-center justify-between mb-6 pb-3 border-b border-gray-100">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#E72382]">
                Curated Suggestions
              </p>
              <h2 className="font-serif text-2xl font-bold text-gray-900">
                Similar Pieces from the Atelier
              </h2>
            </div>
            <Link
              href="/shop"
              className="text-xs font-semibold text-[#E72382] hover:underline uppercase tracking-wider"
            >
              View Full Gallery →
            </Link>
          </div>

          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
            {similarProducts.map((sim) => (
              <Link
                key={sim.id}
                href={`/product/${sim.id}`}
                className="group flex-shrink-0 w-44 sm:w-56 bg-white rounded-2xl border border-gray-100 p-3 hover:shadow-lg transition flex flex-col justify-between"
              >
                <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-gray-50 mb-3">
                  <img
                    src={sim.image}
                    alt={sim.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-gray-900 line-clamp-1 group-hover:text-[#E72382] transition">
                    {sim.name}
                  </h4>
                  <p className="text-xs font-bold text-gray-900 mt-1 font-serif">
                    ₹{sim.price.toLocaleString("en-IN")}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* REVIEWS & TESTIMONIALS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-16">
        {/* Review header with in-line "Add Review" button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-gray-100">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#E72382]">
              Real Patron Stories
            </p>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900">
              Testimonials & Reviews
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Verified patron impressions for this heirloom piece
            </p>
          </div>

          {/* Single-click redirect to practical review page */}
          <Link
            href={`/product/${product.id}/review`}
            className="inline-flex items-center gap-2 bg-[#E72382] hover:bg-[#d01c72] active:scale-95 text-white px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase transition shadow-md shadow-pink-100 self-start sm:self-auto"
          >
            <Camera size={15} />
            <span>You can add review from here</span>
          </Link>
        </div>

        {/* Reviews Grid */}
        {reviews.length === 0 ? (
          <div className="bg-white rounded-3xl p-10 border border-dashed border-pink-200 text-center max-w-lg mx-auto">
            <div className="w-14 h-14 bg-pink-50 rounded-full flex items-center justify-center mx-auto text-[#E72382] mb-3">
              <Camera size={24} />
            </div>
            <h4 className="font-serif text-lg font-bold text-gray-900">
              Be the first to share your styling photo
            </h4>
            <p className="text-xs text-gray-500 mt-1 mb-5">
              Did you wear this piece to an event or special date? Upload a photo wearing it and tell us what you loved most.
            </p>
            <Link
              href={`/product/${product.id}/review`}
              className="inline-flex items-center gap-2 bg-gray-900 hover:bg-gray-800 text-white px-6 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider"
            >
              Add Your Photo & Impression
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((rev) => (
              <div
                key={rev.id}
                className="bg-white rounded-3xl p-6 border border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.02)] flex flex-col justify-between"
              >
                <div>
                  {rev.photoUrl && (
                    <div className="relative aspect-square w-full rounded-2xl overflow-hidden mb-4 bg-gray-50 border border-gray-100">
                      <img
                        src={rev.photoUrl}
                        alt={`Worn by ${rev.authorName}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <p className="text-xs sm:text-sm text-gray-700 italic leading-relaxed">
                    &ldquo;{rev.textFeedback}&rdquo;
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-gray-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-pink-100 text-[#E72382] font-bold text-xs flex items-center justify-center">
                      {rev.authorName.charAt(0).toUpperCase()}
                    </div>
                    <span className="text-xs font-bold text-gray-900">{rev.authorName}</span>
                  </div>
                  <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                    Verified Patron
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* MOBILE STICKY BOTTOM BAR */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-gray-100 p-3 sm:hidden flex items-center gap-2 shadow-[0_-5px_20px_rgba(0,0,0,0.04)]">
        <button
          onClick={handleAddToCart}
          className="flex-1 py-3 px-4 rounded-xl border-2 border-[#E72382] text-[#E72382] font-bold text-xs uppercase tracking-wider active:scale-95 transition text-center"
        >
          Add to Bag
        </button>
        <button
          onClick={handleBuyNow}
          className="flex-1 py-3 px-4 rounded-xl bg-[#E72382] text-white font-bold text-xs uppercase tracking-wider active:scale-95 transition shadow-md shadow-pink-200 text-center"
        >
          Buy Now
        </button>
      </div>

      {/* COMPACT & SYSTEMATIC LUXURY FOOTER */}
      <footer className="mt-24 border-t border-gray-200/80 bg-white pt-10 pb-8 text-center text-xs text-gray-500">
        <div className="max-w-5xl mx-auto px-4 space-y-4">
          <div className="flex items-center justify-center gap-2 font-serif text-sm tracking-[0.2em] font-bold text-gray-900 uppercase">
            <span>Kala Silver Atelier</span>
            <span className="text-[#E72382]">✦</span>
            <span>Handcrafted Purity</span>
          </div>
          <p className="text-[11px] text-gray-400 max-w-md mx-auto">
            Certified 925 Hallmark Silver • Insured Express Transit • Bespoke Customer Concierge
          </p>
          <div className="flex justify-center gap-6 text-[11px] font-semibold tracking-wider uppercase text-gray-600 pt-2">
            <Link href="/shop" className="hover:text-[#E72382]">Shop All</Link>
            <Link href="/about-us" className="hover:text-[#E72382]">About Story</Link>
            <Link href="/contact-us" className="hover:text-[#E72382]">Concierge Help</Link>
            <Link href="/account/orders" className="hover:text-[#E72382]">Order History</Link>
          </div>
          <p className="text-[10px] text-gray-400 pt-4">
            © {new Date().getFullYear()} Kala Silver. All Rights Reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

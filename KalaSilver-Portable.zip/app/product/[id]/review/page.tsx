import AddReviewClient from "./AddReviewClient";

export const metadata = {
  title: "Add Product Review | Kala Silver",
  description: "Share your authentic styling experience with Kala Silver jewellery",
};

export default async function AddReviewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <AddReviewClient productId={id} />;
}

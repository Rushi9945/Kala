"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Camera, Heart, CheckCircle2, Sparkles, Send } from "lucide-react";

export default function AddReviewClient({ productId }: { productId: string }) {
  const router = useRouter();
  const [authorName, setAuthorName] = useState("");
  const [textFeedback, setTextFeedback] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [photoPreview, setPhotoPreview] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setPhotoPreview(base64);
        setPhotoUrl(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (!authorName.trim()) {
      setErrorMsg("Please provide your name.");
      return;
    }
    if (!textFeedback.trim()) {
      setErrorMsg("Please write what you loved most about this jewellery piece.");
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId,
          authorName: authorName.trim(),
          textFeedback: textFeedback.trim(),
          photoUrl: photoUrl || "",
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to submit review");
      }

      setIsSuccess(true);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to submit. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FFFBF8] pb-20 selection:bg-pink-100 selection:text-[#E72382]">
      {/* Header bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-[0_2px_10px_rgba(0,0,0,0.02)]">
        <div className="max-w-3xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link
            href={`/product/${productId}`}
            className="flex items-center gap-1.5 text-xs tracking-wider uppercase font-semibold text-gray-500 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={16} />
            <span>Back to Jewellery Piece</span>
          </Link>

          <Link href="/" className="font-serif text-lg tracking-[0.2em] font-bold text-gray-900 uppercase">
            Kala <span className="text-[#E72382]">Silver</span>
          </Link>
        </div>
      </header>

      <main className="max-w-xl mx-auto px-4 pt-10">
        {isSuccess ? (
          <div className="bg-white rounded-3xl p-8 sm:p-12 border border-gray-100 shadow-[0_10px_40px_rgba(0,0,0,0.04)] text-center">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-5 shadow-sm">
              <CheckCircle2 size={44} strokeWidth={1.5} />
            </div>

            <span className="text-xs uppercase font-bold tracking-widest text-[#E72382] bg-pink-50 px-3 py-1 rounded-full">
              Sent to Atelier Concierge
            </span>

            <h1 className="font-serif text-2xl font-bold text-gray-900 mt-4 mb-2">
              Thank You, {authorName}
            </h1>
            <p className="text-gray-600 text-sm leading-relaxed max-w-md mx-auto">
              Your styling photo and kind words have been received. Our store team reviews all authentic customer moments to showcase them on this heirloom&apos;s page!
            </p>

            <div className="mt-8 flex justify-center">
              <Link
                href={`/product/${productId}`}
                className="bg-[#E72382] hover:bg-[#d01c72] active:scale-95 text-white px-8 py-3.5 rounded-full text-xs font-semibold tracking-wider uppercase transition shadow-md"
              >
                Return to Product
              </Link>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-gray-100 shadow-[0_8px_30px_rgba(0,0,0,0.03)]">
            <div className="text-center mb-8">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-[#E72382] bg-pink-50 px-3 py-1 rounded-full mb-2">
                <Sparkles size={13} />
                Real Patron Experience
              </span>
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-gray-900">
                Share How You Styled This Piece
              </h1>
              <p className="text-xs text-gray-500 mt-1.5 max-w-md mx-auto">
                No complicated star meters—just your authentic experience and a photo wearing this piece.
              </p>
            </div>

            {errorMsg && (
              <div className="mb-6 p-3.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Photo Upload Area */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-gray-700 mb-2">
                  1. Photo Wearing This Jewellery <span className="text-gray-400 font-normal lowercase">(optional but loved)</span>
                </label>

                {photoPreview ? (
                  <div className="relative w-full aspect-square sm:aspect-[4/3] rounded-2xl overflow-hidden border-2 border-[#E72382]/30 bg-gray-50">
                    <img
                      src={photoPreview}
                      alt="Worn Jewellery Preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setPhotoPreview("");
                        setPhotoUrl("");
                      }}
                      className="absolute top-3 right-3 bg-black/60 hover:bg-black text-white px-3 py-1 rounded-full text-xs font-semibold shadow"
                    >
                      Change Photo
                    </button>
                  </div>
                ) : (
                  <label className="group flex flex-col items-center justify-center w-full aspect-video rounded-2xl border-2 border-dashed border-pink-200 hover:border-[#E72382] bg-[#FFFBFD] hover:bg-pink-50/50 cursor-pointer transition p-6 text-center">
                    <div className="w-12 h-12 rounded-full bg-pink-100/70 text-[#E72382] flex items-center justify-center mb-3 group-hover:scale-110 transition">
                      <Camera size={24} />
                    </div>
                    <span className="text-sm font-semibold text-gray-800">
                      Tap to upload photo of you wearing the piece
                    </span>
                    <span className="text-[11px] text-gray-400 mt-1">
                      Supports JPG, PNG, WEBP (Direct from phone camera or gallery)
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              {/* Loved aspect & words */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-gray-700 mb-2">
                  2. What Did You Like Most About It? <span className="text-[#E72382]">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Share details like the luster of the silver, weight on your skin, compliments received, or the craftmanship..."
                  value={textFeedback}
                  onChange={(e) => setTextFeedback(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition leading-relaxed resize-none"
                />
              </div>

              {/* Author Name */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-gray-700 mb-2">
                  3. Your Name <span className="text-[#E72382]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Priyal Soni"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#E72382] hover:bg-[#d01c72] active:scale-[0.99] disabled:opacity-60 text-white py-3.5 px-6 rounded-xl font-medium tracking-wide shadow-md shadow-pink-200 transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Sending to Atelier...</span>
                  </div>
                ) : (
                  <>
                    <Send size={16} />
                    <span>Submit Review for Atelier Verification</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}

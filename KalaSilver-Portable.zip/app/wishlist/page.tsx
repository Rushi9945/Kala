"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  Heart,
  Trash2,
  ShoppingBag,
  ArrowRight,
  ChevronLeft,
  Share2,
  Check,
  ShieldCheck,
  Gem,
} from "lucide-react";
import { useWishlist } from "@/context/WishlistContext";
import { useCart } from "@/context/CartContext";

export default function WishlistPage() {
  const router = useRouter();
  const { items, removeFromWishlist, clearWishlist } = useWishlist();
  const { addItem } = useCart();
  const [copiedLink, setCopiedLink] = useState(false);

  const handleShareVault = () => {
    if (typeof window !== "undefined") {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleMoveToCart = (item: any) => {
    addItem({
      id: item.id,
      name: item.name,
      title: item.name,
      price: item.salePrice || item.price,
      image: item.image,
    });
    removeFromWishlist(item.id);
  };

  // Portfolio total valuation
  const totalValuation = items.reduce(
    (sum, item) => sum + (item.salePrice || item.price || 0),
    0
  );

  return (
    <div className="min-h-screen bg-[#FFF5F8]/40 pb-24 font-body">
      {/* Top Sticky Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-pink-100/70">
        <div className="max-w-6xl mx-auto px-4 h-20 flex items-center justify-between">
          <button
            onClick={() => router.push("/shop")}
            className="p-3 hover:bg-pink-50 rounded-2xl transition-all group flex items-center gap-1.5"
            title="Continue Shopping"
          >
            <ChevronLeft className="w-5 h-5 text-gray-800 group-hover:-translate-x-1 transition-transform" />
            <span className="text-xs font-black uppercase tracking-wider text-gray-600 hidden sm:inline">
              Catalogue
            </span>
          </button>

          <div className="text-center">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[#E72382] bg-pink-50 px-3 py-1 rounded-full inline-block mb-0.5">
              Curated Portfolio
            </span>
            <h1 className="text-xl md:text-2xl font-black text-gray-900 tracking-tight italic">
              My Private Vault
            </h1>
          </div>

          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                onClick={handleShareVault}
                className="p-2.5 bg-gray-50 hover:bg-pink-50 text-gray-700 hover:text-[#E72382] rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border border-gray-100"
                title="Share Curation"
              >
                {copiedLink ? <Check className="w-4 h-4 text-green-600" /> : <Share2 className="w-4 h-4" />}
                <span className="hidden md:inline">{copiedLink ? "Link Copied" : "Share"}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 py-8 md:py-12">
        {items.length === 0 ? (
          /* Empty Vault State */
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-20 px-6 bg-white rounded-[40px] shadow-[0_20px_60px_rgba(231,35,130,0.05)] border border-pink-50 max-w-lg mx-auto space-y-6"
          >
            <div className="w-24 h-24 bg-pink-50/80 rounded-[32px] flex items-center justify-center mx-auto text-[#E72382] shadow-inner">
              <Heart className="w-12 h-12 stroke-[1.5]" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight italic">
                Your Vault is Empty
              </h2>
              <p className="text-xs md:text-sm text-gray-500 font-medium max-w-sm mx-auto leading-relaxed">
                Save your favorite handcrafted 925 silver ear cuffs, rings, and chains here for easy acquisition.
              </p>
            </div>
            <div className="pt-2">
              <Link
                href="/shop"
                className="inline-flex items-center gap-2 px-8 py-4 bg-[#E72382] hover:bg-[#d01f75] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-pink-200 transition-all hover:scale-105"
              >
                Explore Silver Treasures <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        ) : (
          /* Populated Vault Grid */
          <div className="space-y-8">
            {/* Vault Summary Bar */}
            <div className="bg-white p-5 rounded-3xl border border-pink-100 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#E72382]/10 flex items-center justify-center text-[#E72382]">
                  <Gem className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-gray-900">
                    {items.length} {items.length === 1 ? "Piece" : "Pieces"} Curated
                  </h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                    Total Valuation: <span className="text-[#E72382] font-black italic">₹{totalValuation.toLocaleString()}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  onClick={clearWishlist}
                  className="flex-1 sm:flex-initial px-4 py-2 text-xs font-bold text-gray-500 hover:text-red-500 rounded-xl hover:bg-red-50 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" /> Clear Vault
                </button>
                <Link
                  href="/shop"
                  className="flex-1 sm:flex-initial px-5 py-2.5 bg-gray-900 hover:bg-black text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all text-center"
                >
                  Add More
                </Link>
              </div>
            </div>

            {/* Gallery Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              <AnimatePresence>
                {items.map((item) => {
                  const hasDiscount = item.salePrice && item.salePrice < item.price;
                  return (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.25 }}
                      className="group bg-white rounded-3xl p-3 md:p-4 border border-gray-100 hover:border-pink-200 hover:shadow-xl hover:shadow-pink-500/5 transition-all flex flex-col justify-between relative"
                    >
                      {/* Image Thumbnail */}
                      <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden bg-gray-50 border border-gray-100 mb-3">
                        <Link href={`/product/${item.id}`} className="block w-full h-full">
                          <Image
                            src={item.image}
                            alt={item.name}
                            fill
                            className="object-contain p-2 group-hover:scale-105 transition-transform duration-500"
                            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                          />
                        </Link>

                        {/* Remove from vault trigger */}
                        <button
                          onClick={() => removeFromWishlist(item.id)}
                          className="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-gray-400 hover:text-red-500 shadow-sm transition-colors z-10"
                          title="Remove from Vault"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                        <div className="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-sm text-white text-[8px] font-black uppercase px-2 py-0.5 rounded-full">
                          925 Silver
                        </div>
                      </div>

                      {/* Content & Mathematics */}
                      <div className="space-y-2 flex-1 flex flex-col justify-between">
                        <div>
                          <Link href={`/product/${item.id}`}>
                            <h4 className="font-bold text-xs md:text-sm text-gray-900 group-hover:text-[#E72382] transition-colors line-clamp-2 leading-snug">
                              {item.name}
                            </h4>
                          </Link>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-sm md:text-base font-black text-gray-900 italic">
                              ₹{(item.salePrice || item.price).toLocaleString()}
                            </span>
                            {hasDiscount && (
                              <span className="text-[10px] text-gray-400 line-through">
                                ₹{item.price.toLocaleString()}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Direct Add to Cart Action */}
                        <button
                          onClick={() => handleMoveToCart(item)}
                          className="w-full mt-2 py-2.5 bg-[#E72382] hover:bg-[#d01f75] text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-md shadow-pink-200 flex items-center justify-center gap-1.5 transition-all active:scale-95"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" /> Move to Cart
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>

            {/* Bottom Brand Guarantee Strip */}
            <div className="p-6 md:p-8 bg-gradient-to-r from-pink-50 via-white to-pink-50 rounded-3xl border border-pink-100 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-[#E72382]">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-gray-900">
                    Complimentary Express Delivery & Hallmarking
                  </h4>
                  <p className="text-xs text-gray-500 font-medium">
                    All pieces in your Private Vault arrive in velvet gift cases with tamper-proof seal.
                  </p>
                </div>
              </div>

              <Link
                href="/shop"
                className="px-6 py-3 bg-gray-900 hover:bg-black text-white text-xs font-black uppercase tracking-widest rounded-xl transition-all shrink-0"
              >
                Continue Browsing
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

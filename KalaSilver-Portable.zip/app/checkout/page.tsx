"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Script from "next/script";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useCart } from "@/context/CartContext";
import { useUser } from "@/context/FirebaseContext";
import {
  ShieldCheck,
  Lock,
  ArrowLeft,
  Truck,
  CreditCard,
  CheckCircle2,
  Sparkles,
  MapPin,
  ChevronRight,
  Package,
  Phone,
  User,
  Building,
  AlertCircle,
  HelpCircle,
  Receipt,
  RotateCcw
} from "lucide-react";

declare global {
  interface Window {
    Razorpay: any;
  }
}

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
  "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
  "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Delhi", "Jammu and Kashmir", "Ladakh"
];

const MAJOR_CITIES: Record<string, string[]> = {
  Gujarat: ["Vadodara", "Ahmedabad", "Surat", "Rajkot", "Bhavnagar", "Jamnagar", "Gandhinagar", "Anand"],
  Maharashtra: ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Navi Mumbai"],
  Delhi: ["New Delhi", "North Delhi", "South Delhi", "West Delhi", "East Delhi"],
  Karnataka: ["Bengaluru", "Mysuru", "Hubballi", "Mangaluru", "Belagavi"],
  Rajasthan: ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner", "Ajmer"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem"],
  "Uttar Pradesh": ["Lucknow", "Noida", "Kanpur", "Varanasi", "Agra", "Prayagraj"],
};

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, clearCart } = useCart();
  const user = useUser();

  // Wizard state: 1 = Shipping, 2 = Payment Review, 3 = Confirmed Celebration
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderConfirmedData, setOrderConfirmedData] = useState<any>(null);

  // Address Form state
  const [formData, setFormData] = useState({
    fullName: "",
    mobile: "",
    email: "",
    addressLine: "",
    city: "",
    state: "Gujarat",
    pincode: "",
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [stateSuggestions, setStateSuggestions] = useState<string[]>([]);
  const [citySuggestions, setCitySuggestions] = useState<string[]>([]);

  // Delivery & Calculation constants
  const deliveryFee = subtotal > 1999 ? 0 : 99;
  const hallmarkCertFee = 0; // Complimentary hallmarking certificate
  const totalPayable = subtotal + deliveryFee;

  // Sync state from sessionStorage or user profile
  useEffect(() => {
    try {
      const savedStep = sessionStorage.getItem("ks_checkout_step");
      if (savedStep && (savedStep === "1" || savedStep === "2")) {
        setCurrentStep(Number(savedStep) as 1 | 2);
      }
      const savedAddress = sessionStorage.getItem("ks_checkout_address");
      if (savedAddress) {
        setFormData(JSON.parse(savedAddress));
      } else if (user) {
        setFormData((prev) => ({
          ...prev,
          fullName: user.displayName || "",
          email: user.email || "",
          mobile: user.phoneNumber?.replace("+91", "") || "",
        }));
      }
    } catch (e) {
      console.warn("Storage sync notice:", e);
    }
  }, [user]);

  // Handle form change
  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (formErrors[field]) {
      setFormErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }

    if (field === "state") {
      const filtered = INDIAN_STATES.filter((s) =>
        s.toLowerCase().includes(value.toLowerCase())
      );
      setStateSuggestions(filtered.slice(0, 5));
    }

    if (field === "city") {
      const stateCities = MAJOR_CITIES[formData.state] || [];
      const filtered = stateCities.filter((c) =>
        c.toLowerCase().includes(value.toLowerCase())
      );
      setCitySuggestions(filtered.slice(0, 5));
    }
  };

  // Validation
  const validateShippingForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.fullName.trim() || formData.fullName.length < 3) {
      errors.fullName = "Please enter legal recipient name";
    }
    const cleanMobile = formData.mobile.replace(/\D/g, "");
    if (!cleanMobile || cleanMobile.length !== 10) {
      errors.mobile = "Valid 10-digit mobile number required (+91)";
    }
    if (!formData.addressLine.trim() || formData.addressLine.length < 5) {
      errors.addressLine = "Detailed house, building & street name required";
    }
    if (!formData.city.trim()) {
      errors.city = "City / Town is required";
    }
    if (!formData.state.trim()) {
      errors.state = "State is required";
    }
    const cleanPin = formData.pincode.replace(/\D/g, "");
    if (!cleanPin || cleanPin.length !== 6) {
      errors.pincode = "Valid 6-digit postal pincode required";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateShippingForm()) {
      window.scrollTo({ top: 180, behavior: "smooth" });
      return;
    }
    sessionStorage.setItem("ks_checkout_address", JSON.stringify(formData));
    sessionStorage.setItem("ks_checkout_step", "2");
    setCurrentStep(2);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Razorpay Payment Handler
  const handleInitiateRazorpay = async () => {
    try {
      setIsProcessing(true);

      // 1. Create order on backend
      const res = await fetch("/api/razorpay/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: totalPayable,
          receipt: `rcpt_${Date.now()}`,
        }),
      });

      const orderData = await res.json();
      if (!res.ok) {
        throw new Error(orderData.error || "Unable to initiate payment");
      }

      const keyId =
        process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "rzp_live_SCyPbJdNgvKHG8";

      // If Razorpay SDK is loaded on window
      if (typeof window !== "undefined" && window.Razorpay) {
        const options = {
          key: keyId,
          amount: orderData.amount,
          currency: orderData.currency || "INR",
          name: "Kala Silver",
          description: "Artisanal 925 Sterling Silver Jewellery",
          image: "/images/logo.png",
          order_id: orderData.id,
          prefill: {
            name: formData.fullName,
            email: formData.email || "patron@kalasilver.com",
            contact: `+91${formData.mobile}`,
          },
          theme: {
            color: "#E72382",
          },
          handler: async function (response: any) {
            await verifyAndCompleteOrder(response, orderData.id);
          },
          modal: {
            ondismiss: function () {
              setIsProcessing(false);
            },
          },
        };

        const rzp = new window.Razorpay(options);
        rzp.open();
      } else {
        // Fallback simulate instant verification in mock/local mode
        setTimeout(async () => {
          await verifyAndCompleteOrder(
            {
              razorpay_payment_id: `pay_mock_${Date.now()}`,
              razorpay_order_id: orderData.id,
              razorpay_signature: "mock_signature_kala_silver",
            },
            orderData.id
          );
        }, 1200);
      }
    } catch (err: any) {
      console.error("Payment initiation failed:", err);
      alert(err.message || "Payment service temporarily unavailable. Please try again.");
      setIsProcessing(false);
    }
  };

  const verifyAndCompleteOrder = async (rzpPayload: any, orderId: string) => {
    try {
      const orderPayload = {
        userId: user?.uid || "guest",
        customerName: formData.fullName,
        email: formData.email || "patron@kalasilver.com",
        phone: formData.mobile,
        address: {
          street: formData.addressLine,
          city: formData.city,
          state: formData.state,
          pincode: formData.pincode,
        },
        items: items.map((i) => ({
          id: i.id,
          name: i.name,
          price: i.salePrice || i.price,
          quantity: i.quantity,
          image: i.image,
        })),
        totalAmount: totalPayable,
        subtotal: subtotal,
      };

      const verifyRes = await fetch("/api/razorpay/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...rzpPayload,
          orderDetails: orderPayload,
        }),
      });

      const verifyData = await verifyRes.json();
      if (verifyData.success) {
        setOrderConfirmedData({
          orderId: verifyData.orderId || orderId,
          paymentId: rzpPayload.razorpay_payment_id,
          amount: totalPayable,
          customerName: formData.fullName,
          address: formData,
          items: [...items],
        });

        clearCart();
        sessionStorage.removeItem("ks_checkout_step");
        sessionStorage.removeItem("ks_checkout_address");
        setCurrentStep(3);
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        alert("Payment signature verification failed. Please contact support.");
      }
    } catch (e: any) {
      console.error("Order completion failed:", e);
      alert("Error confirming order. Kindly contact concierge support with your payment ID.");
    } finally {
      setIsProcessing(false);
    }
  };

  // If bag is empty and not on confirmed step, invite to shop
  if (items.length === 0 && currentStep !== 3) {
    return (
      <div className="min-h-screen bg-[#FFFBF8] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-pink-50 rounded-full flex items-center justify-center mb-5 text-[#E72382] shadow-sm">
          <Package size={36} strokeWidth={1.5} />
        </div>
        <h1 className="font-serif text-3xl font-bold text-gray-900 tracking-tight mb-2">
          Your Curated Bag is Empty
        </h1>
        <p className="text-gray-500 max-w-md text-sm mb-8 leading-relaxed">
          Select timeless 925 Sterling Silver heirlooms from our collection to begin secure bespoke checkout.
        </p>
        <Link
          href="/shop"
          className="inline-flex items-center gap-2 bg-[#E72382] hover:bg-[#d01c72] text-white px-8 py-3.5 rounded-full font-medium tracking-wide shadow-md transition-all active:scale-95"
        >
          Explore Collection
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFFBF8] text-gray-800 pb-20 selection:bg-pink-100 selection:text-[#E72382]">
      {/* Razorpay Checkout Script */}
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        strategy="lazyOnload"
      />

      {/* Luxury Checkout Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-[0_2px_10px_rgba(0,0,0,0.02)]">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link
            href={currentStep === 2 ? "#" : "/cart"}
            onClick={(e) => {
              if (currentStep === 2) {
                e.preventDefault();
                setCurrentStep(1);
              }
            }}
            className="flex items-center gap-1.5 text-xs tracking-wider uppercase font-semibold text-gray-500 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={16} />
            <span>{currentStep === 2 ? "Back to Address" : "Return to Bag"}</span>
          </Link>

          <Link href="/" className="flex items-center gap-2">
            <span className="font-serif text-xl tracking-[0.25em] font-bold text-gray-900 uppercase">
              Kala <span className="text-[#E72382]">Silver</span>
            </span>
          </Link>

          <div className="flex items-center gap-1 text-[11px] font-medium tracking-wider uppercase text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            <Lock size={12} />
            <span className="hidden sm:inline">256-Bit</span> Encrypted
          </div>
        </div>

        {/* 3-Step Wizard Indicator */}
        <div className="max-w-md mx-auto px-6 py-2.5 flex items-center justify-between text-xs font-semibold tracking-wider uppercase">
          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                currentStep >= 1
                  ? "bg-[#E72382] text-white shadow-sm"
                  : "bg-gray-100 text-gray-400"
              }`}
            >
              1
            </div>
            <span className={currentStep === 1 ? "text-[#E72382]" : "text-gray-400"}>
              Delivery
            </span>
          </div>

          <div className={`h-[1px] flex-1 mx-3 ${currentStep >= 2 ? "bg-[#E72382]" : "bg-gray-200"}`} />

          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                currentStep >= 2
                  ? "bg-[#E72382] text-white shadow-sm"
                  : "bg-gray-100 text-gray-400"
              }`}
            >
              2
            </div>
            <span className={currentStep === 2 ? "text-[#E72382]" : "text-gray-400"}>
              Payment
            </span>
          </div>

          <div className={`h-[1px] flex-1 mx-3 ${currentStep === 3 ? "bg-[#E72382]" : "bg-gray-200"}`} />

          <div className="flex items-center gap-2">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                currentStep === 3
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "bg-gray-100 text-gray-400"
              }`}
            >
              3
            </div>
            <span className={currentStep === 3 ? "text-emerald-700" : "text-gray-400"}>
              Confirm
            </span>
          </div>
        </div>
      </header>

      {/* Main Checkout Container */}
      <main className="max-w-5xl mx-auto px-4 pt-8">
        {/* STEP 1: DELIVERY ADDRESS */}
        {currentStep === 1 && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.03)]">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                <div>
                  <h2 className="font-serif text-2xl font-bold text-gray-900">
                    Bespoke Delivery Address
                  </h2>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Insured nationwide doorstep transit with signature delivery
                  </p>
                </div>
                <div className="w-10 h-10 rounded-full bg-pink-50 text-[#E72382] flex items-center justify-center">
                  <MapPin size={20} />
                </div>
              </div>

              <form onSubmit={handleProceedToPayment} className="space-y-4">
                {/* Full Legal Name */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                    Recipient Full Name <span className="text-[#E72382]">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3 text-gray-400" size={17} />
                    <input
                      type="text"
                      placeholder="e.g. Kushal Soni"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange("fullName", e.target.value)}
                      className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition ${
                        formErrors.fullName ? "border-rose-400 bg-rose-50/20" : "border-gray-200"
                      }`}
                    />
                  </div>
                  {formErrors.fullName && (
                    <p className="text-xs text-rose-500 mt-1">{formErrors.fullName}</p>
                  )}
                </div>

                {/* Mobile & Email Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                      Contact Mobile <span className="text-[#E72382]">*</span>
                    </label>
                    <div className="relative flex">
                      <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-gray-200 bg-gray-50 text-xs font-semibold text-gray-600">
                        +91
                      </span>
                      <input
                        type="tel"
                        maxLength={10}
                        placeholder="98765 43210"
                        value={formData.mobile}
                        onChange={(e) =>
                          handleInputChange("mobile", e.target.value.replace(/\D/g, ""))
                        }
                        className={`w-full px-3.5 py-2.5 rounded-r-xl border text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition ${
                          formErrors.mobile ? "border-rose-400 bg-rose-50/20" : "border-gray-200"
                        }`}
                      />
                    </div>
                    {formErrors.mobile && (
                      <p className="text-xs text-rose-500 mt-1">{formErrors.mobile}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                      Email Address <span className="text-gray-400 text-[10px] font-normal">(For invoice & tracking)</span>
                    </label>
                    <input
                      type="email"
                      placeholder="patron@example.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition"
                    />
                  </div>
                </div>

                {/* Address Line */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                    Flat / House No., Landmark & Street Address <span className="text-[#E72382]">*</span>
                  </label>
                  <div className="relative">
                    <Building className="absolute left-3.5 top-3 text-gray-400" size={17} />
                    <input
                      type="text"
                      placeholder="e.g. 402 Silver Crest, Alkapuri Road, Opp. Temple"
                      value={formData.addressLine}
                      onChange={(e) => handleInputChange("addressLine", e.target.value)}
                      className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition ${
                        formErrors.addressLine ? "border-rose-400 bg-rose-50/20" : "border-gray-200"
                      }`}
                    />
                  </div>
                  {formErrors.addressLine && (
                    <p className="text-xs text-rose-500 mt-1">{formErrors.addressLine}</p>
                  )}
                </div>

                {/* State, City, Pincode Trio */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* State with suggestion */}
                  <div className="relative">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                      State <span className="text-[#E72382]">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Gujarat"
                      value={formData.state}
                      onChange={(e) => handleInputChange("state", e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition ${
                        formErrors.state ? "border-rose-400 bg-rose-50/20" : "border-gray-200"
                      }`}
                    />
                    {stateSuggestions.length > 0 && (
                      <div className="absolute z-20 top-full mt-1 left-0 w-full bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden">
                        {stateSuggestions.map((s) => (
                          <button
                            type="button"
                            key={s}
                            onClick={() => {
                              handleInputChange("state", s);
                              setStateSuggestions([]);
                            }}
                            className="w-full text-left px-3 py-2 text-xs hover:bg-pink-50 transition text-gray-800"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    )}
                    {formErrors.state && (
                      <p className="text-xs text-rose-500 mt-1">{formErrors.state}</p>
                    )}
                  </div>

                  {/* City */}
                  <div className="relative">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                      City / Town <span className="text-[#E72382]">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Vadodara"
                      value={formData.city}
                      onChange={(e) => handleInputChange("city", e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition ${
                        formErrors.city ? "border-rose-400 bg-rose-50/20" : "border-gray-200"
                      }`}
                    />
                    {citySuggestions.length > 0 && (
                      <div className="absolute z-20 top-full mt-1 left-0 w-full bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden">
                        {citySuggestions.map((c) => (
                          <button
                            type="button"
                            key={c}
                            onClick={() => {
                              handleInputChange("city", c);
                              setCitySuggestions([]);
                            }}
                            className="w-full text-left px-3 py-2 text-xs hover:bg-pink-50 transition text-gray-800"
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    )}
                    {formErrors.city && (
                      <p className="text-xs text-rose-500 mt-1">{formErrors.city}</p>
                    )}
                  </div>

                  {/* Pincode */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1.5">
                      Pincode <span className="text-[#E72382]">*</span>
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="390001"
                      value={formData.pincode}
                      onChange={(e) =>
                        handleInputChange("pincode", e.target.value.replace(/\D/g, ""))
                      }
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#E72382]/20 focus:border-[#E72382] transition ${
                        formErrors.pincode ? "border-rose-400 bg-rose-50/20" : "border-gray-200"
                      }`}
                    />
                    {formErrors.pincode && (
                      <p className="text-xs text-rose-500 mt-1">{formErrors.pincode}</p>
                    )}
                  </div>
                </div>

                {/* Trust Badges */}
                <div className="pt-4 grid grid-cols-2 gap-3 text-xs text-gray-600 border-t border-gray-100">
                  <div className="flex items-center gap-2">
                    <Truck size={16} className="text-[#E72382]" />
                    <span>Dispatched in 24-48 Hours</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={16} className="text-emerald-600" />
                    <span>Tamper-Proof Luxury Box</span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-[#E72382] hover:bg-[#d01c72] active:scale-[0.99] text-white py-3.5 px-6 rounded-xl font-medium tracking-wide shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Proceed to Payment Review</span>
                    <ChevronRight size={18} />
                  </button>
                </div>
              </form>
            </div>

            {/* Sidebar Summary */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.03)]">
                <h3 className="font-serif text-lg font-bold text-gray-900 mb-4 pb-3 border-b border-gray-100">
                  Curated Bag Summary ({items.length})
                </h3>

                <div className="divide-y divide-gray-100 max-h-72 overflow-y-auto pr-1">
                  {items.map((item) => (
                    <div key={item.id} className="py-3 flex items-center gap-3">
                      <div className="relative w-14 h-14 bg-gray-50 rounded-lg overflow-hidden flex-shrink-0 border border-gray-100">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-gray-800 truncate">
                          {item.name}
                        </p>
                        <p className="text-[11px] text-gray-400 mt-0.5">
                          Qty: {item.quantity} × ₹{(item.salePrice || item.price).toLocaleString("en-IN")}
                        </p>
                      </div>
                      <span className="text-xs font-bold text-gray-900">
                        ₹{((item.salePrice || item.price) * item.quantity).toLocaleString("en-IN")}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-4 pt-4 border-t border-gray-100 space-y-2 text-xs">
                  <div className="flex justify-between text-gray-600">
                    <span>Bag Subtotal</span>
                    <span>₹{subtotal.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Authenticity Certificate</span>
                    <span className="text-emerald-600 font-semibold uppercase">Complimentary</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Priority Express Shipping</span>
                    <span>{deliveryFee === 0 ? "FREE" : `₹${deliveryFee}`}</span>
                  </div>
                  <div className="pt-2 border-t border-gray-100 flex justify-between items-baseline font-bold text-base text-gray-900">
                    <span>Total Investment</span>
                    <span className="text-[#E72382] font-serif">₹{totalPayable.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </div>

              {/* Hallmarking & BIS Card */}
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/60 rounded-2xl p-4 flex items-start gap-3">
                <Sparkles size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900">
                  <p className="font-semibold">BIS 925 Hallmark Guaranteed</p>
                  <p className="text-[11px] text-amber-800/80 mt-0.5">
                    Every piece bears the official 925 purity stamp and arrives in our bespoke protective anti-tarnish jewelry pouch.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: PAYMENT REVIEW & GATEWAY */}
        {currentStep === 2 && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.03)] space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div>
                  <h2 className="font-serif text-2xl font-bold text-gray-900">
                    Payment & Verification
                  </h2>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Select your preferred encrypted banking or UPI channel
                  </p>
                </div>
                <div className="w-10 h-10 rounded-full bg-pink-50 text-[#E72382] flex items-center justify-center">
                  <CreditCard size={20} />
                </div>
              </div>

              {/* Selected Destination Capsule */}
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200/70 flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <MapPin size={14} className="text-[#E72382]" />
                    <span>Deliver to: {formData.fullName} (+91 {formData.mobile})</span>
                  </div>
                  <p className="text-xs text-gray-600 pl-5 leading-relaxed">
                    {formData.addressLine}, {formData.city}, {formData.state} - {formData.pincode}
                  </p>
                </div>
                <button
                  onClick={() => setCurrentStep(1)}
                  className="text-xs text-[#E72382] font-semibold hover:underline flex-shrink-0 ml-3"
                >
                  Edit
                </button>
              </div>

              {/* Payment Methods */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600">
                  Select Payment Gateway
                </label>

                {/* Razorpay Online Option */}
                <div className="p-4 rounded-xl border-2 border-[#E72382] bg-pink-50/20 relative cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded-full border-4 border-[#E72382] bg-white" />
                      <div>
                        <p className="text-sm font-bold text-gray-900">
                          Razorpay Secure Banking (UPI, Cards, NetBanking)
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Instant payment via GPay, PhonePe, Paytm, RuPay, Visa, Mastercard
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] uppercase font-bold tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                      Instant Confirmation
                    </span>
                  </div>

                  {/* Payment partner marquee logo mock */}
                  <div className="mt-3 pt-3 border-t border-pink-100 flex flex-wrap items-center gap-3 text-[11px] font-semibold text-gray-500">
                    <span className="bg-white px-2 py-1 rounded border border-gray-200">UPI</span>
                    <span className="bg-white px-2 py-1 rounded border border-gray-200">Google Pay</span>
                    <span className="bg-white px-2 py-1 rounded border border-gray-200">PhonePe</span>
                    <span className="bg-white px-2 py-1 rounded border border-gray-200">Paytm</span>
                    <span className="bg-white px-2 py-1 rounded border border-gray-200">Credit / Debit Cards</span>
                    <span className="bg-white px-2 py-1 rounded border border-gray-200">NetBanking</span>
                  </div>
                </div>

                {/* COD Disabled notice as per Kala Silver policy */}
                <div className="p-4 rounded-xl border border-gray-200 bg-gray-50/70 opacity-80">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded-full border border-gray-300 bg-gray-200" />
                      <div>
                        <p className="text-sm font-semibold text-gray-700">
                          Cash on Delivery (COD)
                        </p>
                        <p className="text-xs text-gray-400 mt-0.5">
                          Temporarily restricted for high-value hallmarked silver bullion transit
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] uppercase font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                      Prepaid Only
                    </span>
                  </div>
                </div>
              </div>

              {/* Pay Button */}
              <div className="pt-2">
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleInitiateRazorpay}
                  className="w-full bg-[#E72382] hover:bg-[#d01c72] active:scale-[0.99] disabled:opacity-60 text-white py-4 px-6 rounded-xl font-medium tracking-wide shadow-lg shadow-pink-200 transition-all flex items-center justify-center gap-2"
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Initiating Secure Banking...</span>
                    </div>
                  ) : (
                    <>
                      <Lock size={17} />
                      <span>Pay ₹{totalPayable.toLocaleString("en-IN")} via Razorpay</span>
                    </>
                  )}
                </button>
                <p className="text-center text-[11px] text-gray-400 mt-2.5">
                  Your credentials and banking details are 100% tokenized with RBI approved gateways.
                </p>
              </div>
            </div>

            {/* Sidebar Summary Review */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.03)]">
                <h3 className="font-serif text-lg font-bold text-gray-900 mb-3 pb-3 border-b border-gray-100 flex items-center justify-between">
                  <span>Order Overview</span>
                  <span className="text-xs font-normal text-gray-400">{items.length} Heirloom(s)</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between text-gray-600">
                    <span>Products Subtotal</span>
                    <span>₹{subtotal.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Shipping Fee</span>
                    <span>{deliveryFee === 0 ? "FREE" : `₹${deliveryFee}`}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>GST & Transit Insurance</span>
                    <span>Included</span>
                  </div>
                  <div className="pt-3 border-t border-gray-100 flex justify-between items-baseline font-bold text-base text-gray-900">
                    <span>Payable Now</span>
                    <span className="text-[#E72382] font-serif text-xl">
                      ₹{totalPayable.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>
              </div>

              {/* Guarantees Box */}
              <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.03)] space-y-3 text-xs text-gray-600">
                <div className="flex items-center gap-2.5">
                  <RotateCcw size={16} className="text-[#E72382]" />
                  <span>7-Day Return & Replacement Assurance</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <ShieldCheck size={16} className="text-emerald-600" />
                  <span>Complimentary Lifetime Polish & Purity Check</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Receipt size={16} className="text-indigo-600" />
                  <span>Official GST Tax Invoice Generated Instantly</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: ORDER CONFIRMED CELEBRATION */}
        {currentStep === 3 && orderConfirmedData && (
          <div className="max-w-2xl mx-auto bg-white rounded-3xl p-8 sm:p-12 border border-gray-100 shadow-[0_10px_40px_rgba(0,0,0,0.04)] text-center">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-5 shadow-sm">
              <CheckCircle2 size={44} strokeWidth={1.5} />
            </div>

            <span className="text-xs uppercase font-bold tracking-widest text-[#E72382] bg-pink-50 px-3 py-1 rounded-full">
              Order Confirmed & Payment Verified
            </span>

            <h1 className="font-serif text-3xl font-bold text-gray-900 mt-4 mb-2">
              Thank You, {orderConfirmedData.customerName}
            </h1>
            <p className="text-gray-500 text-sm max-w-md mx-auto leading-relaxed">
              Your bespoke jewellery piece is being prepared by our master artisans with certified 925 hallmark purity.
            </p>

            {/* Order Ref Card */}
            <div className="mt-8 p-5 bg-[#FFFBF8] border border-gray-200 rounded-2xl text-left space-y-3">
              <div className="flex items-center justify-between text-xs pb-3 border-b border-gray-200">
                <div>
                  <span className="text-gray-400 uppercase tracking-wider block text-[10px]">Order Reference</span>
                  <span className="font-mono font-bold text-gray-900 text-sm">
                    {orderConfirmedData.orderId}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-gray-400 uppercase tracking-wider block text-[10px]">Payment ID</span>
                  <span className="font-mono font-medium text-gray-700 text-xs">
                    {orderConfirmedData.paymentId}
                  </span>
                </div>
              </div>

              <div className="text-xs text-gray-600 space-y-1">
                <p className="font-semibold text-gray-800">Delivery Destination:</p>
                <p>
                  {orderConfirmedData.address.addressLine}, {orderConfirmedData.address.city},{" "}
                  {orderConfirmedData.address.state} - {orderConfirmedData.address.pincode}
                </p>
                <p className="text-gray-400 text-[11px] pt-1">
                  Phone: +91 {orderConfirmedData.address.mobile}
                </p>
              </div>

              <div className="pt-3 border-t border-gray-200 flex justify-between items-center text-sm font-bold text-gray-900">
                <span>Total Paid</span>
                <span className="text-[#E72382] font-serif text-base">
                  ₹{orderConfirmedData.amount.toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                href="/account/orders"
                className="bg-[#E72382] hover:bg-[#d01c72] active:scale-95 text-white px-7 py-3 rounded-full text-xs font-semibold tracking-wider uppercase transition shadow-md"
              >
                View in Orders Boutique
              </Link>
              <Link
                href="/"
                className="bg-gray-100 hover:bg-gray-200 active:scale-95 text-gray-800 px-7 py-3 rounded-full text-xs font-semibold tracking-wider uppercase transition"
              >
                Continue Exploring
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

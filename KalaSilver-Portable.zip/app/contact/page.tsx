"use client";

import React, { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Phone,
  Mail,
  MapPin,
  Sparkles,
  Send,
  CheckCircle2,
  Clock,
  ShieldCheck,
  MessageSquare,
} from "lucide-react";

export default function ContactUsPage() {
  const [formState, setFormState] = useState({
    name: "",
    phone: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const contactData = {
    ownerName: "Kushal Soni",
    phone: "7228820041",
    email: "kushal712004@icloud.com",
    whatsapp: "7228820041",
    instagram: "https://www.instagram.com/kalasilver01",
    address: "Location Gujarat Vadodara, India",
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSent(true);
      setFormState({ name: "", phone: "", email: "", message: "" });
    }, 800);
  };

  return (
    <div className="bg-[#fafafa] relative overflow-hidden min-h-screen font-body pb-20">
      {/* Background glow effects */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-pink-100/30 rounded-full blur-[120px] -mr-64 -mt-64 animate-pulse pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-blue-50/20 rounded-full blur-[140px] -ml-80 -mb-80 pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10 px-4 pt-6 md:pt-14">
        {/* Page Top Heading */}
        <div className="text-center mb-8 md:mb-12 space-y-3">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-px w-8 bg-[#E72382]/30" />
            <span className="text-[#E72382] text-[10px] md:text-xs font-black uppercase tracking-[0.5em]">
              Let&apos;s Connect
            </span>
            <div className="h-px w-8 bg-[#E72382]/30" />
          </div>

          <h1 className="text-3xl md:text-5xl lg:text-7xl font-black text-gray-900 italic tracking-tighter leading-none">
            We&apos;d Love to <br className="hidden md:block" />
            <span className="text-[#E72382] relative inline-block">
              Start a Conversation
              <svg
                className="absolute -bottom-1 md:-bottom-3 left-0 w-full opacity-60"
                height="6"
                viewBox="0 0 300 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M2.5 9.5C50.5 4 150.5 2 297.5 9.5"
                  stroke="#E72382"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </h1>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
          {/* Left Column: Primary Contact Card */}
          <div className="lg:col-span-7 bg-white rounded-[32px] md:rounded-[40px] p-6 md:p-10 shadow-[0_15px_40px_rgba(0,0,0,0.02)] border border-gray-100 flex flex-col justify-between">
            <div className="space-y-6 md:space-y-8">
              {/* Founder Header */}
              <div className="space-y-2">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-[#E72382]" /> Primary Contact
                </p>
                <h2 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tighter italic leading-none">
                  {contactData.ownerName}
                </h2>
                <p className="text-xs md:text-sm text-gray-500 font-medium max-w-md">
                  Creative force behind Kala Silver. Reach out for bespoke styling, sizing advice, or direct inquiries.
                </p>
              </div>

              {/* Direct Buttons: Call & Email */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <a
                  href={`tel:${contactData.phone}`}
                  className="group flex items-center gap-3 bg-gray-50/70 p-3.5 rounded-2xl hover:bg-[#E72382]/5 transition-colors border border-transparent hover:border-[#E72382]/20"
                >
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center group-hover:bg-[#E72382] transition-all shadow-sm shrink-0">
                    <Phone className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">
                      Call
                    </p>
                    <p className="text-sm md:text-base font-bold text-gray-900 group-hover:text-[#E72382] transition-colors tracking-tight">
                      +91 {contactData.phone}
                    </p>
                  </div>
                </a>

                <a
                  href={`mailto:${contactData.email}`}
                  className="group flex items-center gap-3 bg-gray-50/70 p-3.5 rounded-2xl hover:bg-[#E72382]/5 transition-colors border border-transparent hover:border-[#E72382]/20"
                >
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center group-hover:bg-[#E72382] transition-all shadow-sm shrink-0">
                    <Mail className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">
                      Email
                    </p>
                    <p className="text-xs md:text-sm font-bold text-gray-900 group-hover:text-[#E72382] transition-colors tracking-tight truncate">
                      {contactData.email}
                    </p>
                  </div>
                </a>
              </div>

              {/* Direct Message Form */}
              <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-gray-100">
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                  Send a Direct Note
                </p>

                {isSent ? (
                  <div className="p-4 bg-green-50 rounded-2xl flex items-center gap-3 text-green-700 text-xs font-bold border border-green-100">
                    <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                    <span>Message received! Kushal Soni will connect with you promptly.</span>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        placeholder="Your Name"
                        value={formState.name}
                        onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                        className="w-full px-4 py-3 bg-gray-50/80 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                      />
                      <input
                        type="tel"
                        required
                        placeholder="Mobile Number"
                        value={formState.phone}
                        onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                        className="w-full px-4 py-3 bg-gray-50/80 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382]"
                      />
                    </div>
                    <textarea
                      required
                      rows={3}
                      placeholder="How may our boutique assist you?"
                      value={formState.message}
                      onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50/80 rounded-xl text-xs font-bold outline-none border focus:border-[#E72382] resize-none"
                    />
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3.5 bg-[#E72382] hover:bg-[#d01f75] text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-pink-200 transition-all flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? "Dispatching..." : "Send Note"} <Send className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </form>
            </div>

            {/* Headquarters & Community Bar */}
            <div className="mt-8 pt-6 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em]">
                  Headquarters
                </p>
                <p className="text-xs md:text-sm text-gray-800 font-bold flex items-center gap-1.5 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-[#E72382] shrink-0" />
                  {contactData.address}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map((e) => (
                    <div
                      key={e}
                      className="w-8 h-8 rounded-full border-2 border-white bg-gray-100 overflow-hidden shadow-sm"
                    >
                      <img
                        src={`https://i.pravatar.cc/100?img=${e + 10}`}
                        alt="Community Member"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
                <span className="text-[9px] font-black text-gray-900 uppercase tracking-wider">
                  300+ Community
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Social Channels (WhatsApp & Instagram) */}
          <div className="lg:col-span-5 flex flex-col gap-5">
            {/* WhatsApp Card */}
            <motion.a
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              href={`https://wa.me/91${contactData.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-gradient-to-br from-[#25D366] to-[#128C7E] rounded-[32px] md:rounded-[40px] p-6 md:p-8 text-white flex flex-col justify-between relative overflow-hidden group shadow-xl shadow-green-100 min-h-[160px]"
            >
              <div className="relative z-10 space-y-4">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-2xl font-black italic tracking-tighter">
                    Sync via WhatsApp
                  </h3>
                  <p className="text-white/80 font-medium text-xs mt-1">
                    Instant concierge for silver custom orders and fast dispatch updates.
                  </p>
                </div>
              </div>
            </motion.a>

            {/* Instagram Card */}
            <motion.a
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              href={contactData.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-gradient-to-br from-[#833AB4] via-[#F56040] to-[#FFDC80] rounded-[32px] md:rounded-[40px] p-6 md:p-8 text-white flex flex-col justify-between relative overflow-hidden group shadow-xl shadow-pink-100 min-h-[160px]"
            >
              <div className="relative z-10 space-y-4">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-2xl font-black italic tracking-tighter">
                    Style on Instagram
                  </h3>
                  <p className="text-white/80 font-medium text-xs mt-1">
                    Follow @kalasilver01 for curated styling drops and editorial silver reels.
                  </p>
                </div>
              </div>
            </motion.a>
          </div>
        </div>

        {/* Founder Quotation Signature Footer */}
        <div className="mt-12 md:mt-16 text-center space-y-3">
          <p className="text-gray-400 font-serif italic text-sm md:text-xl max-w-sm mx-auto leading-relaxed">
            &ldquo;Jewelry is more than an accessory—it&apos;s a story.&rdquo;
          </p>
          <div className="flex flex-col items-center">
            <span className="text-2xl md:text-4xl font-black tracking-tighter italic text-[#E72382]">
              {contactData.ownerName}
            </span>
            <span className="text-[10px] md:text-xs font-bold text-gray-400 uppercase tracking-[0.4em] mt-1">
              Founder, Kala Silver
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

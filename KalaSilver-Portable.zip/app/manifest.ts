import { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Kala Silver | Premium Silver Jewellery',
    short_name: 'Kala Silver',
    description:
      'Kala Silver creates elegant, timeless silver jewellery that celebrates individuality. Crafted with precision, designed for distinction.',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#000000',
    icons: [
      {
        src: '/favicon.ico',
        sizes: 'any',
        type: 'image/x-icon',
      },
      {
        src: 'https://raw.githubusercontent.com/pilabcloudserver-alt/imageskalasilver/main/images/1772346354126-Create_a_logo_2k_202602051231.jpeg',
        sizes: '192x192',
        type: 'image/jpeg',
      },
      {
        src: 'https://raw.githubusercontent.com/pilabcloudserver-alt/imageskalasilver/main/images/1772346354126-Create_a_logo_2k_202602051231.jpeg',
        sizes: '512x512',
        type: 'image/jpeg',
      },
    ],
  };
}

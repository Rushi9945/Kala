import type { Metadata } from "next";
import { HOME_METADATA } from "@/lib/pageMetadata";
import HeroSection from "@/components/HeroSection";
import CategoryCarousel from "@/components/CategoryCarousel";
import BudgetSuite from "@/components/BudgetSuite";
import ProductGrid from "@/components/ProductGrid";
import InstagramFeed from "@/components/InstagramFeed";

export const metadata: Metadata = HOME_METADATA;

export default function HomePage() {
  return (
    <div className="w-full flex flex-col min-h-screen bg-white">
      {/* 1. Shop by Category: Starts immediately at homepage entry */}
      <CategoryCarousel />

      {/* 2. Gifts by Budget: 4-column grid with pastel cards & price thresholds */}
      <BudgetSuite />

      {/* 3. Our Products: Multi-row product grid with square images and magenta buttons */}
      <ProductGrid />

      {/* 4. Community Section: "Join Our Community" */}
      <InstagramFeed />
    </div>
  );
}

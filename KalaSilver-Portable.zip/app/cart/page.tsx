"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShoppingBag,
  ChevronLeft,
  Trash2,
  Minus,
  Plus,
  ShieldCheck,
  Lock,
  ArrowRight,
  Truck,
  RotateCcw,
  Sparkles,
  Tag,
  CheckCircle2,
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useUser } from "@/context/FirebaseContext";

export default function CartPage() {
  const router = useRouter();
  const { items, updateQuantity, removeItem, clearCart, subtotal, totalCount } = useCart();
  const user = useUser();

  const [couponCode, setCouponCode] = useState("");
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponError, setCouponError] = useState("");

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError("");
    const cleanCode = couponCode.trim().toUpperCase();

    if (cleanCode === "KALA10" || cleanCode === "FESTIVE10") {
      setDiscountPercent(10);
      setCouponApplied(true);
    } else if (cleanCode === "SILVER15") {
      setDiscountPercent(15);
      setCouponApplied(true);
    } else {
      setCouponError("Invalid or expired coupon code.");
    }
  };

  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const finalPayable = Math.max(0, subtotal - discountAmount);

  const handleCheckoutNav = () => {
    if (user) {
      router.push("/checkout");
    } else {
      router.push("/login?redirect=/checkout");
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-[85vh] flex flex-col items-center justify-center p-4 bg-[#FFF5F8] font-body">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center space-y-6 max-w-md mx-auto"
        >
          <div className="w-32 h-32 bg-white rounded-[48px] flex items-center justify-center shadow-2xl shadow-pink-100 mx-auto animate-bounce">
            <ShoppingBag className="w-12 h-12 text-[#E72382]" />
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight italic">
              Your Treasure Bag is Empty
            </h1>
            <p className="text-gray-500 font-medium text-sm leading-relaxed max-w-sm mx-auto">
              Looks like you haven&apos;t added any sterling silver pieces to your curation yet.
            </p>
          </div>

          <div className="pt-2">
            <Link
              href="/shop"
              className="inline-flex items-center gap-2 h-16 px-10 bg-[#E72382] hover:bg-[#d01f75] text-white font-black uppercase tracking-[0.2em] rounded-full shadow-[0_15px_40px_rgba(231,35,130,0.3)] hover:scale-105 active:scale-95 transition-all text-xs"
            >
              Start Curating <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF5F8] pb-24 pt-8 md:pt-12 px-4 font-body">
      <div className="max-w-6xl mx-auto space-y-8 md:space-y-10">
        {/* Top Header / Breadcrumb */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-pink-100/60 pb-6">
          <div className="space-y-2">
            <Link
              href="/shop"
              className="flex items-center gap-2 text-[#E72382] font-black text-xs uppercase tracking-widest hover:gap-3 transition-all"
            >
              <ChevronLeft className="w-4 h-4" /> Continue Shopping
            </Link>
            <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tighter italic">
              Shopping <span className="text-[#E72382]">Bag</span>
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-gray-500 font-black uppercase tracking-widest text-xs bg-white px-5 py-2.5 rounded-full border border-pink-50 shadow-sm">
              {items.length} {items.length === 1 ? "Unique Piece" : "Unique Pieces"} ({totalCount} Total)
            </span>
            <button
              onClick={clearCart}
              className="text-[10px] font-black uppercase tracking-wider text-gray-400 hover:text-red-500 px-3 py-2 transition-colors"
            >
              Clear Bag
            </button>
          </div>
        </div>

        {/* 2-Column Grid: Bag Items (Left) & Summary (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          {/* Left Column: Cart Pieces List */}
          <div className="lg:col-span-8 space-y-4">
            <AnimatePresence>
              {items.map((item) => {
                const itemPrice = item.salePrice || item.price;
                const lineTotal = itemPrice * item.quantity;

                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white rounded-[36px] md:rounded-[40px] p-6 md:p-8 border border-white shadow-[0_15px_60px_rgba(231,35,130,0.04)] flex flex-col md:flex-row gap-6 md:gap-8 group transition-all hover:bg-pink-50/40"
                  >
                    {/* Item Thumbnail */}
                    <Link
                      href={`/product/${item.id}`}
                      className="relative w-full md:w-44 h-44 bg-gray-50 rounded-[28px] overflow-hidden border border-gray-100 flex-shrink-0 group-hover:bg-white transition-colors duration-500 cursor-pointer block"
                    >
                      <Image
                        src={item.image}
                        alt={item.name || item.title || "Silver Jewellery"}
                        fill
                        className="object-contain p-4 group-hover:scale-110 transition-transform duration-700"
                      />
                    </Link>

                    {/* Item Details */}
                    <div className="flex-1 flex flex-col justify-between py-1">
                      <div className="space-y-4">
                        <div className="flex justify-between items-start gap-4">
                          <Link href={`/product/${item.id}`}>
                            <h3 className="text-lg md:text-2xl font-black text-gray-900 leading-tight hover:text-[#E72382] transition-colors cursor-pointer">
                              {item.name || item.title}
                            </h3>
                          </Link>
                          <button
                            onClick={() => removeItem(item.id)}
                            className="p-3 bg-pink-50 text-[#E72382] rounded-2xl hover:bg-[#E72382] hover:text-white transition-all duration-300"
                            title="Remove Piece"
                          >
                            <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
                          </button>
                        </div>

                        {item.customName && (
                          <div className="inline-block px-3 py-1 bg-pink-50 border border-pink-100 rounded-lg text-[10px] font-black uppercase text-[#E72382] tracking-wider">
                            Custom Engraving: &ldquo;{item.customName}&rdquo;
                          </div>
                        )}

                        {/* Quantity Counter & Price Per Item */}
                        <div className="flex items-center gap-6">
                          <div className="flex items-center gap-2 bg-white rounded-2xl p-1 border border-pink-100 shadow-sm">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-50 text-gray-900 hover:bg-[#E72382] hover:text-white transition-all font-black"
                              title="Decrease"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-10 text-center font-black text-gray-900 text-sm">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-50 text-gray-900 hover:bg-[#E72382] hover:text-white transition-all font-black"
                              title="Increase"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="h-6 w-px bg-pink-100 hidden md:block" />

                          <div className="flex flex-col">
                            <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">
                              Price / Item
                            </span>
                            <span className="text-lg md:text-xl font-black text-[#E72382] italic">
                              ₹{itemPrice.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Pure Silver Hallmark & Subtotal */}
                      <div className="mt-6 md:mt-4 pt-4 border-t border-gray-50 flex justify-between items-end">
                        <div className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-green-500" />
                          <span className="text-[10px] font-black uppercase tracking-widest text-green-600">
                            Pure 925 Silver Hallmark
                          </span>
                        </div>

                        <p className="text-xl md:text-2xl font-black text-gray-900 tracking-tighter">
                          <span className="text-xs text-gray-400 font-black mr-2">
                            SUBTOTAL:
                          </span>
                          ₹{lineTotal.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {/* Right Column: Order Summary & Checkout Trigger */}
          <div className="lg:col-span-4 lg:sticky lg:top-24 space-y-6">
            <div className="bg-slate-900 rounded-[44px] md:rounded-[48px] p-7 md:p-8 text-white relative overflow-hidden shadow-2xl shadow-slate-300">
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#E72382]/20 rounded-full blur-[80px] -mr-32 -mt-32 pointer-events-none" />

              <h3 className="text-2xl font-black mb-6 relative z-10 tracking-tight">
                Order Summary
              </h3>

              <div className="space-y-5 relative z-10">
                {/* Mathematics */}
                <div className="flex justify-between items-center opacity-80 text-sm font-bold uppercase tracking-widest">
                  <span>Bag Subtotal</span>
                  <span className="text-base font-black">₹{subtotal.toLocaleString()}</span>
                </div>

                {couponApplied && (
                  <div className="flex justify-between items-center text-sm font-bold text-emerald-400">
                    <span>Discount ({discountPercent}%)</span>
                    <span>-₹{discountAmount.toLocaleString()}</span>
                  </div>
                )}

                <div className="flex justify-between items-center text-sm font-bold uppercase tracking-widest opacity-80">
                  <span>Shipping Fee</span>
                  <span className="text-xs font-black uppercase tracking-[0.2em] bg-white/10 px-3 py-1 rounded-full text-[#E72382]">
                    FREE
                  </span>
                </div>

                <div className="h-px bg-white/10 my-4" />

                {/* Promo Code Input */}
                <form onSubmit={handleApplyCoupon} className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Coupon Code"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="flex-1 px-4 py-2.5 rounded-xl bg-white/10 border border-white/10 text-white placeholder:text-gray-400 text-xs font-bold uppercase outline-none focus:border-[#E72382]"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 bg-white/20 hover:bg-white/30 text-white text-xs font-black uppercase tracking-wider rounded-xl transition-all"
                    >
                      Apply
                    </button>
                  </div>
                  {couponError && <p className="text-[10px] text-rose-400 font-bold">{couponError}</p>}
                  {couponApplied && (
                    <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Coupon &ldquo;{couponCode.toUpperCase()}&rdquo; applied!
                    </p>
                  )}
                </form>

                <div className="h-px bg-white/10 my-4" />

                <div className="flex justify-between items-center mb-6">
                  <span className="text-lg font-black uppercase italic">To Pay</span>
                  <span className="text-3xl md:text-4xl font-black text-[#E72382] tracking-tighter italic">
                    ₹{finalPayable.toLocaleString()}
                  </span>
                </div>

                {/* Checkout Trigger */}
                <button
                  onClick={handleCheckoutNav}
                  className="w-full h-16 bg-[#E72382] hover:bg-[#d01f75] text-white font-black uppercase tracking-[0.2em] rounded-[24px] shadow-[0_20px_50px_rgba(231,35,130,0.4)] hover:scale-[1.02] active:scale-95 transition-all text-xs flex items-center justify-center gap-3"
                >
                  {!user && <Lock className="w-4 h-4 shrink-0" />}
                  {user ? "Continue to Checkout" : "Login to Checkout"}
                  <ArrowRight className="w-4 h-4" />
                </button>

                {/* Assurances */}
                <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white/10 text-slate-300">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-[#E72382]" />
                    <span className="text-[10px] font-black uppercase tracking-wider">
                      Free Shipping
                    </span>
                  </div>
                  <div className="flex items-center gap-2 justify-end">
                    <RotateCcw className="w-4 h-4 text-[#E72382]" />
                    <span className="text-[10px] font-black uppercase tracking-wider">
                      Easy Returns
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Guarantee Badge Card */}
            <div className="p-6 bg-white rounded-[32px] border border-pink-50 shadow-sm flex items-center gap-4">
              <div className="w-14 h-14 bg-pink-50 rounded-2xl flex items-center justify-center shrink-0 text-[#E72382]">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-[#E72382]">
                  100% Genuine Silver
                </p>
                <p className="text-xs font-bold text-gray-500 italic mt-0.5">
                  All products are BIS Hallmarked for purity and quality assurance.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

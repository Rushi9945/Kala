"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Award,
  ShieldCheck,
  Star,
  Users,
  Sparkles,
  ArrowRight,
  Gem,
  CheckCircle2,
} from "lucide-react";

export default function AboutUsPage() {
  const highlights = [
    {
      icon: Award,
      title: "Premium Quality",
      sub: "Certified 925",
    },
    {
      icon: ShieldCheck,
      title: "Hallmarked",
      sub: "BIS Standard",
    },
    {
      icon: Star,
      title: "Artisan Craft",
      sub: "Handcrafted",
    },
    {
      icon: Users,
      title: "Authentic Legacy",
      sub: "Artisan Made",
    },
  ];

  return (
    <main className="min-h-[calc(100vh-80px)] bg-white font-body relative overflow-visible py-8 md:py-16">
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-16">
        {/* Left Side: Brand Heritage Portrait */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full lg:w-[32%] flex justify-center"
        >
          <div className="relative w-full max-w-[340px] aspect-[4/5] rounded-[2.5rem] md:rounded-[3.5rem] overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.08)] border border-pink-100/60 bg-gradient-to-b from-pink-50/50 to-white group p-3">
            <div className="relative w-full h-full rounded-[2rem] md:rounded-[3rem] overflow-hidden">
              <Image
                src="https://raw.githubusercontent.com/pilabcloudserver-alt/imageskalasilver/main/images/1772346354126-Create_a_logo_2k_202602051231.jpeg"
                alt="Kala Silver Founder and Legacy"
                fill
                priority
                className="object-cover group-hover:scale-105 transition-transform duration-1000"
              />
            </div>
          </div>
        </motion.div>

        {/* Center: The Story, Heritage & Typography */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex-1 text-center lg:text-left space-y-6 md:space-y-8 max-w-2xl"
        >
          {/* Header pill */}
          <div>
            <span className="text-[11px] font-black uppercase tracking-[0.6em] text-[#E72382] px-5 py-2 bg-[#FFF5F8] border border-pink-100 rounded-full inline-block shadow-sm">
              The Legacy
            </span>
          </div>

          {/* Large Title */}
          <h1 className="text-4xl md:text-6xl font-black text-gray-900 tracking-tighter italic leading-[0.95]">
            Crafting <span className="text-[#E72382]">Tradition</span>,<br />
            Defining <span className="text-[#E72382]">Elegance</span>.
          </h1>

          <div className="w-16 h-1 bg-[#E72382] rounded-full mx-auto lg:mx-0 shadow-[0_2px_10px_rgba(231,35,130,0.3)]" />

          {/* Description */}
          <p className="text-base md:text-lg text-gray-600 font-medium leading-relaxed italic">
            Welcome to Kala Silver. We are dedicated to providing the finest premium 925 sterling silver jewellery, celebrating individuality and modern panache. Every earring, cuff, bracelet, and chain is shaped by master artisans with unwavering precision.
          </p>

          {/* 4 Feature Badges */}
          <div className="pt-6 border-t border-pink-50 grid grid-cols-2 gap-6 max-w-md mx-auto lg:mx-0">
            {highlights.map((h, i) => {
              const Icon = h.icon;
              return (
                <div key={i} className="flex items-center gap-3.5 group text-left">
                  <div className="w-11 h-11 bg-pink-50 rounded-2xl flex items-center justify-center text-[#E72382] shrink-0 group-hover:rotate-6 transition-transform shadow-sm">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-widest text-gray-900">
                      {h.title}
                    </p>
                    <p className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">
                      {h.sub}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-4">
            <Link
              href="/shop"
              className="inline-flex items-center gap-2 px-8 py-4 bg-[#E72382] hover:bg-[#d01f75] text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-pink-200 transition-all"
            >
              Explore The Collection <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </motion.div>

        {/* Right Side: Showcase Video or Visual Reel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full lg:w-[30%] flex justify-center"
        >
          <div className="relative w-full max-w-[320px] aspect-[9/16] rounded-[2.5rem] md:rounded-[3.5rem] overflow-hidden shadow-[0_45px_100px_rgba(0,0,0,0.12)] border border-pink-100 bg-black group">
            <div className="relative w-full h-full">
              <Image
                src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop"
                alt="Kala Silver Artisan Crafting"
                fill
                className="object-cover opacity-90 group-hover:scale-105 transition-transform duration-1000"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-6">
                <span className="text-[10px] font-black uppercase tracking-widest text-[#E72382] bg-white/10 backdrop-blur-md px-3 py-1 rounded-full w-fit">
                  Pure 925 Hallmark
                </span>
                <p className="text-white font-black text-sm tracking-tight mt-2 italic">
                  &ldquo;Silver is forever when made with heart.&rdquo;
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </main>
  );
}

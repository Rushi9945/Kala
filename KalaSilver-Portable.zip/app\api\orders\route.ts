import { NextResponse } from "next/server";
import { createFirestoreOrder, OrderRecord } from "@/lib/firestoreService";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { items, customerName, email, phone, address, totalAmount, paymentMethod, userId } = body;

    if (!items || !items.length || !customerName || !email) {
      return NextResponse.json(
        { error: "Missing required order parameters" },
        { status: 400 }
      );
    }

    const orderPayload: OrderRecord = {
      userId: userId || "guest",
      customerName,
      email,
      phone: phone || "",
      address: address || { street: "", city: "", state: "", pincode: "" },
      items,
      totalAmount: Number(totalAmount) || 0,
      status: "pending",
      paymentMethod: paymentMethod || "cod",
    };

    const result = await createFirestoreOrder(orderPayload);

    return NextResponse.json(
      {
        success: true,
        orderId: result.orderId,
        message: "Order placed successfully. Thank you for choosing Kala Silver!",
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error("Order creation route error:", error);
    return NextResponse.json(
      { error: "Internal order processing error", details: error.message },
      { status: 500 }
    );
  }
}

"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

interface Product {
  id: string;
  title: string;
  price: string;
  image: string;
}

const products: Product[] = [
  {
    id: "p-1",
    title: "Tri-Color Dual Strand Tennis Bracelet",
    price: "₹1,899",
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-2",
    title: "Sapphire Blue Teardrop Stud Earrings",
    price: "₹1,499",
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-3",
    title: "Princess Cut Solitaire Men's Stud",
    price: "₹999",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-4",
    title: "Sterling Silver Floral Drop Necklace",
    price: "₹2,499",
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-5",
    title: "Men's Classic Curb Link Bracelet",
    price: "₹2,299",
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-6",
    title: "Rainbow Gem Inset Men's Bracelet",
    price: "₹2,199",
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-7",
    title: "Round Brilliant Cut Diamond Stud",
    price: "₹1,299",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-8",
    title: "925 Filigree Heart Stud Earrings",
    price: "₹1,199",
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-9",
    title: "Luxe Gold-Plated Tennis Bracelet In Box",
    price: "₹2,699",
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-10",
    title: "Silver Pavé Tennis Bracelet In Box",
    price: "₹2,499",
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-11",
    title: "Classic Solitaire Earring On Model",
    price: "₹1,399",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-12",
    title: "Emerald Green Halo Stud Earrings",
    price: "₹1,599",
    image: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-13",
    title: "Circular Motif Link Silver Bracelet",
    price: "₹1,999",
    image: "https://images.unsplash.com/photo-1611591475104-e5900f074a38?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-14",
    title: "Solitaire Pendant on Silver Link Chain",
    price: "₹1,799",
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-15",
    title: "Floral Snowflake Earring On Model",
    price: "₹1,499",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "p-16",
    title: "Beaded Accent Cuff on Men's Wrist",
    price: "₹2,199",
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=600&auto=format&fit=crop",
  },
];

export default function ProductGrid() {
  const [addedIds, setAddedIds] = useState<string[]>([]);

  const handleAddToCart = (id: string) => {
    setAddedIds((prev) => [...prev, id]);
    setTimeout(() => {
      setAddedIds((prev) => prev.filter((item) => item !== id));
    }, 1800);
  };

  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header exact match with screenshot */}
        <div className="text-center mb-10">
          <p className="text-[11px] font-space-grotesk uppercase tracking-[0.25em] text-[#E72382] mb-1">
            CRAFTED WITH PRECISION
          </p>
          <h2 className="font-space-grotesk font-black text-3xl sm:text-4xl text-[#1a1a2e] tracking-tight">
            Our <span className="text-[#E72382]">Products</span>
          </h2>
          <p className="text-gray-400 text-xs mt-2 max-w-md mx-auto">
            Each creation is a testament to timeless beauty and master craftsmanship.
          </p>
          {/* Subtle underline dash */}
          <div className="w-10 h-0.5 bg-[#E72382] mx-auto mt-4 rounded-full" />
        </div>

        {/* 4-column exact grid matching screenshot */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-5 lg:gap-6">
          {products.map((product) => {
            const isAdded = addedIds.includes(product.id);
            return (
              <div
                key={product.id}
                className="group flex flex-col bg-white rounded-xl border border-gray-100/90 overflow-hidden hover:shadow-lg transition-all duration-300"
              >
                {/* Square Product Image */}
                <div className="relative aspect-square w-full bg-[#fbfbfb] overflow-hidden">
                  <Image
                    src={product.image}
                    alt={product.title}
                    fill
                    className="object-contain p-3 group-hover:scale-105 transition-transform duration-300"
                    sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, 25vw"
                  />
                  {/* Heart / Wishlist icon */}
                  <button
                    aria-label="Wishlist"
                    className="absolute top-2.5 right-2.5 w-7 h-7 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center text-gray-400 hover:text-[#E72382] transition-colors"
                  >
                    ♡
                  </button>
                </div>

                {/* Info Container */}
                <div className="p-3.5 flex flex-col flex-1 justify-between bg-white text-left">
                  <div>
                    <h3 className="text-xs text-[#1a1a2e] font-normal line-clamp-1 group-hover:text-[#E72382] transition-colors">
                      {product.title}
                    </h3>
                    <p className="font-space-grotesk font-bold text-sm text-[#1a1a2e] mt-1">
                      {product.price}
                    </p>
                  </div>

                  {/* Exact full-width vibrant magenta button from screenshot */}
                  <button
                    onClick={() => handleAddToCart(product.id)}
                    className="mt-3 w-full py-2 px-3 rounded-md font-space-grotesk font-semibold text-[11px] uppercase tracking-wider text-white bg-[#E72382] hover:bg-[#d01c72] active:scale-95 transition-all shadow-sm"
                  >
                    {isAdded ? "Added ✓" : "Add to Cart"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

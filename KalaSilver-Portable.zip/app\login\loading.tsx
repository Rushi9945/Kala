/**
 * Login route loading skeleton
 * Shown while the async /login module hydrates from chunk 7358.
 */
export default function LoginLoading() {
  return (
    <div className="min-h-[85vh] flex items-center justify-center bg-gradient-to-b from-white via-[#fef7fa] to-white py-12 px-4 animate-pulse">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-2xl shadow-pink-900/5 border border-pink-100/70 flex flex-col gap-6">
          {/* Brand placeholder */}
          <div className="flex flex-col items-center gap-3">
            <div className="h-8 w-44 rounded-xl bg-gray-200" />
            <div className="h-1 w-12 rounded-full bg-[#E72382]/30" />
            <div className="h-3 w-32 rounded-full bg-gray-100" />
          </div>
          {/* Google button skeleton */}
          <div className="h-12 w-full rounded-xl bg-gray-100" />
          {/* Divider */}
          <div className="h-3 w-full rounded-full bg-gray-50" />
          {/* Phone input skeleton */}
          <div className="h-12 w-full rounded-xl bg-gray-100" />
          {/* CTA skeleton */}
          <div className="h-12 w-full rounded-xl bg-[#E72382]/15" />
          {/* Trust badge */}
          <div className="h-4 w-48 mx-auto rounded-full bg-gray-100" />
        </div>
      </div>
    </div>
  );
}

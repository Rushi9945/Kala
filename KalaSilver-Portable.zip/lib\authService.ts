import {
  Auth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
  User,
  getIdToken,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from "firebase/auth";
import { initFirebase } from "./firebase";

/**
 * Configure standard persistent session state
 */
export async function setAuthPersistence(rememberMe = true): Promise<void> {
  const { auth } = initFirebase();
  if (!auth) return;
  try {
    const mode = rememberMe ? browserLocalPersistence : browserSessionPersistence;
    await setPersistence(auth, mode);
  } catch (err) {
    console.warn("Failed to set auth persistence:", err);
  }
}

/**
 * Google Sign-In Provider authentication via Popup
 */
export async function signInWithGoogle(): Promise<{ user: User | null; token?: string; error?: string }> {
  const { auth } = initFirebase();
  if (!auth) {
    return { user: null, error: "Firebase Auth not initialized" };
  }

  try {
    const provider = new GoogleAuthProvider();
    provider.addScope("profile");
    provider.addScope("email");
    provider.setCustomParameters({ prompt: "select_account" });

    const result = await signInWithPopup(auth, provider);
    const token = await result.user.getIdToken();
    return { user: result.user, token };
  } catch (error: any) {
    console.error("Google sign-in error:", error);
    return { user: null, error: error.message || "Failed to sign in with Google" };
  }
}

/**
 * Google Sign-In Provider authentication via Redirect (Mobile fallback)
 */
export async function signInWithGoogleRedirect(): Promise<void> {
  const { auth } = initFirebase();
  if (!auth) return;
  const provider = new GoogleAuthProvider();
  provider.addScope("profile");
  provider.addScope("email");
  await signInWithRedirect(auth, provider);
}

/**
 * Check and resolve any pending redirect credentials on page mount
 */
export async function checkRedirectResult(): Promise<User | null> {
  const { auth } = initFirebase();
  if (!auth) return null;
  try {
    const result = await getRedirectResult(auth);
    return result?.user ?? null;
  } catch (error) {
    console.warn("No pending redirect or redirect error:", error);
    return null;
  }
}

/**
 * Initialize invisible ReCAPTCHA verifier for Phone Auth
 */
export function setupRecaptcha(containerId: string): RecaptchaVerifier | null {
  const { auth } = initFirebase();
  if (!auth || typeof window === "undefined") return null;

  try {
    return new RecaptchaVerifier(auth, containerId, {
      size: "invisible",
      callback: () => {
        // reCAPTCHA solved
      },
      "expired-callback": () => {
        console.warn("reCAPTCHA expired, please retry verification.");
      },
    });
  } catch (err) {
    console.warn("Recaptcha initialization notice:", err);
    return null;
  }
}

/**
 * Send Phone Verification OTP
 */
export async function sendPhoneOtp(
  phoneNumber: string,
  appVerifier: RecaptchaVerifier
): Promise<{ confirmationResult?: ConfirmationResult; error?: string }> {
  const { auth } = initFirebase();
  if (!auth) return { error: "Firebase Auth not initialized" };

  try {
    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
    return { confirmationResult };
  } catch (error: any) {
    console.error("Phone verification error:", error);
    return { error: error.message || "Failed to send OTP code" };
  }
}

/**
 * Sign out authenticated user
 */
export async function logOutUser(): Promise<void> {
  const { auth } = initFirebase();
  if (!auth) return;
  await signOut(auth);
}

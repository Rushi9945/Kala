"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { cn, optimizeImageUrl } from "@/lib/utils";

export interface ProductData {
  id: string;
  name?: string;
  title?: string;
  price: number;
  salePrice?: number;
  imageUrl?: string;
  image?: string;
  imageUrls?: string[];
  imageHint?: string;
  isNew?: boolean;
  isPureSilver?: boolean;
}

interface ProductCardProps {
  product: ProductData;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const [isHovered, setIsHovered] = useState(false);

  const name = product.name || product.title || "Silver Jewel";
  const price = product.price;
  const salePrice = product.salePrice;
  const isLiked = isInWishlist(product.id);

  const images =
    product.imageUrls && product.imageUrls.length > 0
      ? product.imageUrls
      : [product.imageUrl || product.image || ""];

  const currentImage = isHovered && images.length > 1 ? images[1] : images[0];

  const hasDiscount = !!salePrice && salePrice < price;
  const discountPercent = hasDiscount ? Math.round(((price - salePrice) / price) * 100) : 0;

  return (
    <div
      className="group flex flex-col gap-3 h-full"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* 3:4 Portrait Image Container */}
      <div className="relative aspect-[3/4] w-full overflow-hidden rounded-xl bg-gray-100">
        <Link href={`/product/${product.id}`} className="block h-full w-full">
          {currentImage ? (
            <Image
              src={optimizeImageUrl(currentImage)}
              alt={name}
              fill
              className="object-cover transition-all duration-500 group-hover:scale-105"
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-gray-400 text-xs">
              No Image
            </div>
          )}
        </Link>

        {/* Heart Wishlist Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (isLiked) {
              removeFromWishlist(product.id);
            } else {
              addToWishlist(product);
            }
          }}
          aria-label="Toggle Wishlist"
          className={cn(
            "absolute bottom-2.5 right-2.5 h-8 w-8 rounded-full flex items-center justify-center transition-all z-20 shadow-md",
            isLiked
              ? "bg-[#E72382] text-white"
              : "bg-white/95 backdrop-blur-sm text-gray-700 hover:bg-white border border-gray-100"
          )}
        >
          <Heart className={cn("h-4 w-4 transition-all", isLiked && "fill-current")} />
        </button>

        {/* "New" Ribbon Ribbon Badge */}
        {product.isNew && (
          <div className="absolute top-3 left-0 z-10 pointer-events-none">
            <div
              className="bg-[#E72382] text-white text-[10px] font-black uppercase px-4 py-1.5 pr-6"
              style={{
                clipPath: "polygon(0% 0%, 100% 0%, 88% 50%, 100% 100%, 0% 100%)",
              }}
            >
              New
            </div>
          </div>
        )}

        {/* "Pure Silver" Badge */}
        {product.isPureSilver && (
          <div className="absolute top-3 right-3 z-10">
            <div className="bg-[#E0D4FF] text-[#5B21B6] h-10 w-10 rounded-full flex flex-col items-center justify-center shadow-md border border-white/50">
              <span className="text-[7px] font-black uppercase leading-tight">Pure</span>
              <span className="text-[7px] font-black uppercase leading-tight">Silver</span>
            </div>
          </div>
        )}
      </div>

      {/* Product Details */}
      <div className="flex flex-col gap-1.5 flex-grow">
        <Link href={`/product/${product.id}`} className="block">
          <h3 className="font-semibold text-[15px] text-gray-900 truncate leading-tight group-hover:text-[#E72382] transition-colors">
            {name}
          </h3>
        </Link>

        {/* Price & Discount Indicator */}
        <div className="flex items-center gap-2 mt-0.5">
          {hasDiscount ? (
            <>
              <span className="text-lg font-bold text-gray-900">
                ₹{salePrice?.toLocaleString()}
              </span>
              <span className="text-sm text-gray-400 line-through decoration-gray-400/80">
                ₹{price.toLocaleString()}
              </span>
              <span className="text-sm font-bold text-[#E72382]">
                {discountPercent}% Off
              </span>
            </>
          ) : (
            <span className="text-lg font-bold text-gray-900">
              ₹{price.toLocaleString()}
            </span>
          )}
        </div>
      </div>

      {/* Add To Cart Button */}
      <button
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          addItem({
            id: product.id,
            name,
            price: salePrice || price,
            image: currentImage,
          });
        }}
        className="w-full bg-[#E72382] hover:bg-[#d01f75] text-white font-medium rounded-md h-10 shadow-sm transition-all active:scale-95 text-xs sm:text-sm"
      >
        Add to Cart
      </button>
    </div>
  );
}

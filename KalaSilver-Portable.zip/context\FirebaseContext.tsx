"use client";

import React, { createContext, useContext, useState, useEffect, useMemo } from "react";
import { FirebaseApp } from "firebase/app";
import { Auth, User, onAuthStateChanged } from "firebase/auth";
import { Firestore } from "firebase/firestore";
import { FirebaseStorage } from "firebase/storage";
import { initFirebase } from "@/lib/firebase";

interface FirebaseContextType {
  app: FirebaseApp | undefined;
  auth: Auth | undefined;
  firestore: Firestore | undefined;
  storage: FirebaseStorage | undefined;
  user: User | null;
  loading: boolean;
}

const FirebaseContext = createContext<FirebaseContextType>({
  app: undefined,
  auth: undefined,
  firestore: undefined,
  storage: undefined,
  user: null,
  loading: true,
});

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [instances, setInstances] = useState(() => initFirebase());
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initialized = initFirebase();
    setInstances(initialized);

    if (initialized.auth) {
      const unsubscribe = onAuthStateChanged(initialized.auth, (currentUser) => {
        setUser(currentUser);
        setLoading(false);
      });
      return () => unsubscribe();
    } else {
      setLoading(false);
    }
  }, []);

  const value = useMemo(
    () => ({
      app: instances.app,
      auth: instances.auth,
      firestore: instances.firestore,
      storage: instances.storage,
      user,
      loading,
    }),
    [instances, user, loading]
  );

  return (
    <FirebaseContext.Provider value={value}>
      {children}
    </FirebaseContext.Provider>
  );
}

export const useFirebase = () => useContext(FirebaseContext);
export const useAuth = () => useContext(FirebaseContext).auth;
export const useUser = () => useContext(FirebaseContext).user;
export const useFirestore = () => useContext(FirebaseContext).firestore;
export const useStorage = () => useContext(FirebaseContext).storage;

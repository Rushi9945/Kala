import { initializeApp, getApps, getApp, FirebaseApp } from "firebase/app";
import { getAuth, Auth } from "firebase/auth";
import { getFirestore, Firestore } from "firebase/firestore";
import { getStorage, FirebaseStorage } from "firebase/storage";

// Exact Firebase project configuration extracted from Kala Silver legacy build (Chunk 3227, Module 138)
export const firebaseConfig = {
  apiKey: "AIzaSyAxiwkXB28hflykNj7SMBSNaI8QPIgDJVk",
  authDomain: "kalasilver1.firebaseapp.com",
  projectId: "kalasilver1",
  storageBucket: "kalasilver1.firebasestorage.app",
  messagingSenderId: "946407100320",
  appId: "1:946407100320:web:82fc2d4cb0d39034131ec5",
  measurementId: "G-9EX3NTCVS7",
};

let app: FirebaseApp | undefined;
let auth: Auth | undefined;
let firestore: Firestore | undefined;
let storage: FirebaseStorage | undefined;

export function initFirebase() {
  if (typeof window === "undefined") {
    return { app: undefined, auth: undefined, firestore: undefined, storage: undefined };
  }

  if (!app) {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    auth = getAuth(app);
    firestore = getFirestore(app);
    storage = getStorage(app);
  }

  return { app, auth, firestore, storage };
}

export { app, auth, firestore, storage };

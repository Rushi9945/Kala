import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { authenticated: false, error: "Missing or invalid authorization header" },
        { status: 401 }
      );
    }

    const idToken = authHeader.split("Bearer ")[1];
    if (!idToken) {
      return NextResponse.json(
        { authenticated: false, error: "Empty token payload" },
        { status: 401 }
      );
    }

    // Parse unverified JWT payload on server to read claims safely
    const parts = idToken.split(".");
    if (parts.length === 3) {
      try {
        const payloadJson = Buffer.from(parts[1], "base64").toString("utf-8");
        const claims = JSON.parse(payloadJson);
        const now = Math.floor(Date.now() / 1000);

        if (claims.exp && claims.exp < now) {
          return NextResponse.json(
            { authenticated: false, error: "Token has expired" },
            { status: 401 }
          );
        }

        return NextResponse.json({
          authenticated: true,
          user: {
            uid: claims.user_id || claims.sub,
            email: claims.email || null,
            name: claims.name || claims.display_name || null,
            phone: claims.phone_number || null,
            picture: claims.picture || null,
          },
          issuedAt: new Date((claims.iat || now) * 1000).toISOString(),
          expiresAt: new Date((claims.exp || now) * 1000).toISOString(),
        });
      } catch (e) {
        // Fallback token acknowledgement
      }
    }

    return NextResponse.json({
      authenticated: true,
      tokenLength: idToken.length,
      status: "acknowledged",
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: "Server authentication check failed", details: error.message },
      { status: 500 }
    );
  }
}

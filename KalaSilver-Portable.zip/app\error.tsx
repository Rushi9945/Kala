"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AlertCircle, RotateCcw } from "lucide-react";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("Kala Silver caught error:", error);
  }, [error]);

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center px-4 text-center bg-white relative">
      <div className="w-14 h-14 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mb-4">
        <AlertCircle className="w-7 h-7" />
      </div>

      <h2 className="text-2xl font-black italic text-gray-900 font-headline mb-2">
        Something went wrong
      </h2>

      <p className="text-sm text-gray-500 max-w-md mx-auto mb-6">
        An unexpected error occurred while loading this page. Please try refreshing or return to the main gallery.
      </p>

      <div className="flex items-center gap-3">
        <button
          onClick={() => reset()}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#E72382] hover:bg-[#d01b73] text-white text-xs font-bold uppercase tracking-wider transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Try Again</span>
        </button>

        <Link
          href="/"
          className="px-5 py-2.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 text-xs font-bold uppercase tracking-wider transition-colors"
        >
          Return Home
        </Link>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SplashScreen from "@/app/components/SplashScreen";

export default function ClientLayoutShell({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isLoading, setIsLoading] = useState(true);

  if (isLoading) {
    return <SplashScreen onFinish={() => setIsLoading(false)} />;
  }

  return (
    <>
      {/* Global Header */}
      <Header />

      {/* Main Page Content */}
      <main className="flex-1">{children}</main>

      {/* Global Footer */}
      <Footer />
    </>
  );
}

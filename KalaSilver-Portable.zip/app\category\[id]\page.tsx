import type { Metadata } from "next";
import { getCategoryMetadata } from "@/lib/pageMetadata";
import CategoryPageClient from "@/components/CategoryPageClient";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  return getCategoryMetadata(id);
}

interface CategoryPageProps {
  params: Promise<{
    id: string;
  }>;
  searchParams: Promise<{
    maxPrice?: string;
  }>;
}

export default async function CategoryPage({
  params,
  searchParams,
}: CategoryPageProps) {
  const { id } = await params;
  const { maxPrice } = await searchParams;

  const parsedMaxPrice = maxPrice ? parseInt(maxPrice, 10) : undefined;

  return (
    <CategoryPageClient
      categoryId={id}
      initialMaxPrice={parsedMaxPrice}
    />
  );
}

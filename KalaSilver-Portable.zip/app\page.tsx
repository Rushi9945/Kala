import type { Metadata } from "next";
import { HOME_METADATA } from "@/lib/pageMetadata";
import HeroSection from "@/components/HeroSection";
import CategoryCarousel from "@/components/CategoryCarousel";
import BudgetSuite from "@/components/BudgetSuite";
import ProductGrid from "@/components/ProductGrid";
import InstagramFeed from "@/components/InstagramFeed";

export const metadata: Metadata = HOME_METADATA;

export default function HomePage() {
  return (
    <div className="w-full flex flex-col min-h-screen">
      {/* 1. Hero Carousel: Full-width, edge-to-edge image slider featuring EAR CUFFS with bottom dark gradient */}
      <HeroSection />

      {/* 2. Shop by Category: Horizontal scrolling carousel with tall portrait photo cards */}
      <CategoryCarousel />

      {/* 3. Gifts by Budget: 4-column desktop grid with pastel gradient cards and price thresholds */}
      <BudgetSuite />

      {/* 4. Our Products: Multi-row product grid with square images and full-width magenta buttons */}
      <ProductGrid />

      {/* 5. Community Section: "Join Our Community" with 4-lifestyle photos and dark navy pill button */}
      <InstagramFeed />
    </div>
  );
}

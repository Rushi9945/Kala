import type { Metadata } from "next";
import { getCategoryMetadata } from "@/lib/pageMetadata";
import CategoryPageClient from "@/components/CategoryPageClient";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  return getCategoryMetadata(slug);
}

interface ShopCategoryProps {
  params: Promise<{
    slug: string;
  }>;
  searchParams: Promise<{
    maxPrice?: string;
  }>;
}

export default async function ShopCategoryPage({
  params,
  searchParams,
}: ShopCategoryProps) {
  const { slug } = await params;
  const { maxPrice } = await searchParams;

  const parsedMaxPrice = maxPrice ? parseInt(maxPrice, 10) : undefined;

  return (
    <CategoryPageClient
      categoryId={slug}
      initialMaxPrice={parsedMaxPrice}
    />
  );
}

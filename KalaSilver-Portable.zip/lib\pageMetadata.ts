import type { Metadata } from "next";

/**
 * Per-route metadata — shared across the 8 async route modules
 * bootstrapped by Webpack chunk 7358 (module 62772).
 *
 * Each route gets its own title, description, OG image, and canonical URL
 * so the Next.js metadata API generates correct <head> per page.
 */

const BASE_URL = "https://kalasilver.in";
const OG_DEFAULT = `${BASE_URL}/og-default.jpg`;

export function buildPageMetadata({
  title,
  description,
  path = "/",
  ogImage = OG_DEFAULT,
  noIndex = false,
}: {
  title: string;
  description: string;
  path?: string;
  ogImage?: string;
  noIndex?: boolean;
}): Metadata {
  const url = `${BASE_URL}${path}`;
  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      type: "website",
      locale: "en_IN",
      url,
      siteName: "KalaSilver",
      title,
      description,
      images: [{ url: ogImage, width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImage],
      creator: "@kalasilver",
    },
    robots: noIndex
      ? { index: false, follow: false }
      : { index: true, follow: true },
  };
}

// ── Per-route presets ─────────────────────────────────────────────────────────

export const HOME_METADATA = buildPageMetadata({
  title: "KalaSilver — Ear Cuffs & Curated Silver Jewellery",
  description:
    "Discover KalaSilver's premium ear cuffs, rings, necklaces, bracelets and more. Handcrafted 925 sterling silver, delivered across India. Shop now.",
  path: "/",
});

export const SHOP_METADATA = buildPageMetadata({
  title: "Shop All Collections — KalaSilver",
  description:
    "Browse the full KalaSilver collection. Filter by category, price range, or gift tier. Free shipping above ₹2,999.",
  path: "/shop",
});

export const LOGIN_METADATA = buildPageMetadata({
  title: "Sign In — KalaSilver Boutique Portal",
  description:
    "Access your KalaSilver account to track orders, manage your wishlist, and unlock exclusive member offers.",
  path: "/login",
  noIndex: true,
});

export function getCategoryMetadata(slug: string): Metadata {
  const name = slug
    .split("-")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
  return buildPageMetadata({
    title: `${name} — KalaSilver Collection`,
    description: `Shop KalaSilver's ${name.toLowerCase()} collection. Discover handcrafted 925 sterling silver designs. Free shipping above ₹2,999.`,
    path: `/shop/${slug}`,
  });
}

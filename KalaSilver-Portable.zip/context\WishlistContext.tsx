"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { useUser, useFirestore } from "./FirebaseContext";

export interface WishlistItem {
  id: string;
  name: string;
  price: number;
  salePrice?: number;
  image: string;
  addedAt: number;
}

interface ToastMessage {
  title: string;
  description?: string;
  variant?: "default" | "destructive";
}

interface WishlistContextType {
  items: WishlistItem[];
  addToWishlist: (product: any) => void;
  removeFromWishlist: (id: string) => void;
  isInWishlist: (id: string) => boolean;
  clearWishlist: () => void;
  toast: (msg: ToastMessage) => void;
  activeToast: ToastMessage | null;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [activeToast, setActiveToast] = useState<ToastMessage | null>(null);

  const user = useUser();
  const firestore = useFirestore();

  const toast = (msg: ToastMessage) => {
    setActiveToast(msg);
    setTimeout(() => {
      setActiveToast((current) => (current === msg ? null : current));
    }, 3500);
  };

  // 1. Initial Load: Firestore (if logged in) or LocalStorage
  useEffect(() => {
    async function loadWishlist() {
      if (user && firestore) {
        try {
          const docRef = doc(firestore, "wishlists", user.uid);
          const snap = await getDoc(docRef);
          let loadedItems: WishlistItem[] = snap.exists() ? snap.data().items || [] : [];

          // Merge guest wishlist
          const localStr = localStorage.getItem("temp_wishlist");
          const localItems: WishlistItem[] = localStr ? JSON.parse(localStr) : [];
          if (localItems.length > 0) {
            const merged = [...loadedItems];
            localItems.forEach((item) => {
              if (!merged.some((m) => m.id === item.id)) {
                merged.push(item);
              }
            });
            loadedItems = merged;
            localStorage.removeItem("temp_wishlist");
            await setDoc(docRef, { items: loadedItems, updatedAt: new Date() }, { merge: true });
          }

          setItems(loadedItems);
        } catch (err) {
          console.error("Error loading wishlist from Firestore:", err);
        }
      } else {
        const local = localStorage.getItem("temp_wishlist");
        if (local) {
          try {
            setItems(JSON.parse(local));
          } catch {
            setItems([]);
          }
        }
      }
    }

    loadWishlist();
  }, [user, firestore]);

  // 2. Sync to Firestore or localStorage
  const syncToFirestore = async (newItems: WishlistItem[]) => {
    if (user && firestore) {
      try {
        await setDoc(
          doc(firestore, "wishlists", user.uid),
          { items: newItems, updatedAt: new Date() },
          { merge: true }
        );
      } catch (err) {
        console.error("Error syncing wishlist:", err);
      }
    } else {
      localStorage.setItem("temp_wishlist", JSON.stringify(newItems));
    }
  };

  const addToWishlist = (product: any) => {
    const item: WishlistItem = {
      id: product.id,
      name: product.name || product.title,
      price: product.price,
      salePrice: product.salePrice,
      image: (product.imageUrls && product.imageUrls[0]) || product.imageUrl || product.image,
      addedAt: Date.now(),
    };

    setItems((prev) => {
      if (prev.some((p) => p.id === item.id)) return prev;
      const updated = [...prev, item];
      syncToFirestore(updated);
      toast({
        title: "Added to Wishlist",
        description: `${item.name} has been added to your favorites.`,
      });
      return updated;
    });
  };

  const removeFromWishlist = (id: string) => {
    setItems((prev) => {
      const target = prev.find((p) => p.id === id);
      const updated = prev.filter((p) => p.id !== id);
      syncToFirestore(updated);
      if (target) {
        toast({
          title: "Removed from Wishlist",
          description: `${target.name} removed from your favorites.`,
        });
      }
      return updated;
    });
  };

  const isInWishlist = (id: string) => items.some((p) => p.id === id);

  const clearWishlist = () => {
    setItems([]);
    localStorage.removeItem("temp_wishlist");
    if (user && firestore) {
      setDoc(doc(firestore, "wishlists", user.uid), { items: [], updatedAt: new Date() }).catch(
        () => {}
      );
    }
  };

  return (
    <WishlistContext.Provider
      value={{
        items,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
        clearWishlist,
        toast,
        activeToast,
      }}
    >
      {children}
      {/* Toast Alert Pill */}
      {activeToast && (
        <div className="fixed bottom-6 right-6 z-[1000] max-w-sm bg-gray-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-gray-800 animate-in fade-in slide-in-from-bottom-3 flex items-start gap-3">
          <div className="w-2 h-2 rounded-full bg-[#E72382] mt-1.5 shrink-0" />
          <div className="flex-1">
            <p className="text-xs font-bold font-headline">{activeToast.title}</p>
            {activeToast.description && (
              <p className="text-[11px] text-gray-400 mt-0.5 leading-snug">
                {activeToast.description}
              </p>
            )}
          </div>
        </div>
      )}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error("useWishlist must be used within a WishlistProvider");
  }
  return context;
}
